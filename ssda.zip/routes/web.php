<?php

use App\Models\Slider;
use App\Models\Gallery;
use App\Models\MenuItem;
use App\Models\MenuCategory;
use Illuminate\Http\Request;
use App\Http\Controllers\Mocan;
use App\Services\WooCommerceService;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Artisan;
use App\Http\Controllers\SaleController;
use App\Http\Controllers\TaskController;
use App\Http\Controllers\TestController;
use App\Http\Controllers\ImageController;
use App\Http\Controllers\IndexController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\SliderController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\GalleryController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\SectionController;
use App\Http\Controllers\YetkiliController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\MenuItemController;
use App\Http\Controllers\OperationController;
use App\Http\Controllers\OperationsController;
use App\Http\Controllers\TeklifFormuController;
use App\Http\Controllers\WooCommerceController;
use App\Http\Controllers\MenuCategoryController;
use App\Http\Controllers\TrendyolProductController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\CheckoutController;
use App\Http\Controllers\Admin\OrderController as AdminOrderController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


// Clear Cache
Route::get('cc', function () {

    Artisan::call('optimize');

    Artisan::call('optimize:clear');
    echo "Optimize cleared<br>";

    Artisan::call('cache:clear');
    echo "Cache cleared<br>";

    Artisan::call('view:clear');
    echo "View cleared<br>";

    Artisan::call('config:cache');
    echo "Config cleared<br>";

    Artisan::call('route:cache');
    echo "Config cleared<br>";

    dd("Cache is cleared");
});
Artisan::command('logs:clear', function () {
    array_map('unlink', array_filter((array) glob(storage_path('logs/*.log'))));
    $this->comment('Logs have been cleared!');
})->describe('Clear log files');

Route::get('/storage', function () {
    Artisan::call('storage:link');
});

Route::middleware(['auth'])->group(function () {
    Route::resource('categories', CategoryController::class)->except(['show']); // Show rotası kullanılmayacak.

    // Ürün Rotaları
    Route::resource('products', ProductController::class)->except(['show']); // Show rotası kullanılmayacak.
    // Menü Kategori Rotaları
    Route::resource('menu-categories', MenuCategoryController::class)->except(['show']);

    // Menü Öğesi Rotaları
    Route::resource('menu-items', MenuItemController::class)->except(['show']);
});


Route::get('/teklif-formu', [TeklifFormuController::class, 'teklifFormuGoster'])->name('teklif.formu');
Route::post('/teklif-formu', [TeklifFormuController::class, 'teklifFormunuKaydet'])->name('teklif.formu.kaydet');
Route::get('/teklif-formu/basarili', [TeklifFormuController::class, 'teklifFormuBasarili'])->name('teklif.formu.basarili');

Route::post('/siparis/standart', [OrderController::class, 'storeStandardOrder'])->name('order.store.standard');
Route::post('/siparis/sonradan-gel', [OrderController::class, 'storeComeLaterOrder'])->name('order.store.come_later');
Route::get('/siparis/basarili', [OrderController::class, 'success'])->name('order.success');

Route::resource('gallery', GalleryController::class); // Yönetim paneli için auth middleware'i ekleyebilirsiniz.
Route::post('/gallery/sort', [GalleryController::class, 'sort'])->name('gallery.sort')->middleware('auth');

Route::resource('sliders', SliderController::class)->names('sliders');
Route::get('/dashboard', [IndexController::class, 'index'])->name('admin.index')->middleware('auth');
// Yönetim Paneli Rotaları (Örnek - auth middleware ile güvenliği sağlayabilirsiniz)
Route::middleware(['auth'])->prefix('admin')->group(function () {


    Route::get('/teklif-formlari', [TeklifFormuController::class, 'yönetimPaneli'])->name('admin.teklif.formlari');
    Route::get('/teklif-formlari/{id}', [TeklifFormuController::class, 'teklifFormuDetay'])->name('admin.teklif.formlari.detay');

    // İsteğe bağlı: Silme rotası
    // Route::delete('/teklif-formlari/{id}', [TeklifFormuController::class, 'teklifFormuSil'])->name('admin.teklif.formlari.sil');
});

Route::get('/', function () {
    $galleries = Gallery::orderBy('order')->get();
    $sliders = Slider::all();
    $menuCategories = MenuCategory::orderBy('sort_order')->get();
    $menuItems = MenuItem::with('category')->latest()->paginate(12); // paginate() kullanın


    return view('welcome', compact('galleries', 'sliders', 'menuCategories', 'menuItems'));
})->name('anasayfa');
Route::get('/get-menu-items', [IndexController::class, 'getMenuItemsByCategory'])->name('get.menu.items'); // Asenkron menü öğesi getirme rotası

Route::post('/contact', [ContactController::class, 'store'])->name('contact.store');

Route::middleware(['auth', 'admin'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/contact', [ContactController::class, 'index'])->name('contact.index');
    Route::get('/contact/{message}', [ContactController::class, 'show'])->name('contact.show');
    Route::delete('/contact/{message}', [ContactController::class, 'destroy'])->name('contact.destroy');
});
Route::get('test', function () {
    return view('test');
})->name('test');



// Menü Görüntüleme Rotası (Ön Yüz için)
Route::get('/menu', [MenuItemController::class, 'showMenu'])->name('menu.show');
Route::get('/menu/category/{slug}', [MenuItemController::class, 'category'])->name('menu.category');
Route::get('/hesabim', [MenuItemController::class, 'showMenu'])->name('hesabim');

// Cart routes
Route::get('/cart', [CartController::class, 'index'])->name('cart.index');
Route::post('/cart/add', [CartController::class, 'add'])->name('cart.add');
Route::post('/cart/update', [CartController::class, 'update'])->name('cart.update');
Route::post('/cart/remove', [CartController::class, 'remove'])->name('cart.remove');
Route::post('/cart/clear', [CartController::class, 'clear'])->name('cart.clear');

// Checkout routes
Route::get('/checkout', [CheckoutController::class, 'index'])->name('checkout.index');
Route::post('/checkout', [CheckoutController::class, 'processCheckout'])->name('checkout.process');

// Order routes
Route::get('/orders', [OrderController::class, 'index'])->name('orders.index')->middleware('auth');
Route::get('/orders/{order_code}', [OrderController::class, 'show'])->name('orders.show');
Route::get('/orders/{order_code}/verify', [OrderController::class, 'verify'])->name('orders.verify');
Route::post('/orders/{order_code}/verify', [OrderController::class, 'processVerify'])->name('orders.process-verify');
Route::get('/orders/{order_code}/confirmation', [OrderController::class, 'confirmation'])->name('orders.confirmation');

// Admin routes
Route::prefix('admin')->name('admin.')->middleware(['auth'])->group(function () {
    Route::get('/orders', [AdminOrderController::class, 'index'])->name('orders.index');
    Route::get('/orders/{id}', [AdminOrderController::class, 'show'])->name('orders.show');
    Route::post('/orders/{id}/status', [AdminOrderController::class, 'updateStatus'])->name('orders.update-status');
    Route::get('/orders/check-new', [AdminOrderController::class, 'checkNew'])->name('orders.check-new');
});
Auth::routes();


// Route::get('/check-auth', function () {
//     return response()->json(['authenticated' => Auth::check()]);
// });
