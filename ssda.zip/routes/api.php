<?php

use Illuminate\Http\Request;
use App\Services\WooCommerceService;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\WooCommerceController;
use App\Http\Controllers\OtherProductController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

// Route::post('/cart/add', [CartController::class, 'addToCart']);
// Route::get('/cart/count', [CartController::class, 'getCartCount']); // Sepet sayısını getiren örnek endpoint
// Route::post('/order/store', [OrderController::class, 'store']);
