<?php
return [
    'store_url' => env('WOOCOMMERCE_STORE_URL'),
    'consumer_key' => env('WOOCOMMERCE_CONSUMER_KEY'),
    'consumer_secret' => env('WOOCOMMERCE_CONSUMER_SECRET'),
    'mocan_store_url' => env('WOOCOMMERCE_MOCAN_STORE_URL'),
    'mocan_consumer_key' => env('WOOCOMMERCE_MOCAN_CONSUMER_KEY'),
    'mocan_consumer_secret' => env('WOOCOMMERCE_MOCAN_CONSUMER_SECRET'),
];
