{{-- resources/views/partials/menu_item.blade.php --}}
<div class="menu-item">
    <div class="item-image" style="background-image: url('{{ $menuItem->image ? asset('storage/' . $menuItem->image) : 'https://loremflickr.com/320/240/food' }}');">
        @if($menuItem->label)
            <span class="item-badge">{{ $menuItem->label }}</span>
        @endif
    </div>
    <div class="item-content">
        <div class="item-title">
            <span>{{ $menuItem->name }}</span>
            @if($menuItem->price)
                <span class="item-price">{{ number_format($menuItem->price, 2) }} ₺</span>
            @endif
        </div>
        <p class="item-description">{{ $menuItem->description }}</p>
        <div class="item-features">
            @if($menuItem->extra_condition)
                <span class="feature"><i class="ri-information-line"></i> {{ $menuItem->extra_condition }}</span> {{-- Remix Icon: Bilgi ikonu --}}
            @endif
            @if($menuItem->preparation_time)
                <span class="feature"><i class="ri-clock-line"></i> {{ $menuItem->preparation_time }} dk</span> {{-- Remix Icon: Saat ikonu --}}
            @endif
            @if($menuItem->rating)
                <span class="feature"><i class="ri-star-fill"></i> {{ $menuItem->rating }}</span> {{-- Remix Icon: Yıldız ikonu --}}
            @endif
        </div>
    </div>
    <span class="item-category" style="display: none;">{{ optional($menuItem->category)->name ?? 'Tüm Menü' }}</span>

    <div class="item-actions mt-2"> {{-- Sepete ekle bölümü için eklendi --}}
        <div class="flex justify-between items-center">
            <div>
                <input type="number" id="quantity-{{ $menuItem->id }}" class="quantity-input w-16 border border-gray-300 rounded px-2 py-1 text-center" value="1" min="1">
            </div>
            <div>
                <button
                    class="add-to-cart bg-orange-500 hover:bg-orange-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                    data-id="{{ $menuItem->id }}">
                    Sepete Ekle
                </button>
            </div>
        </div>
        {{-- Eğer extra itemler varsa veya özel not alanı eklemek isterseniz buraya ekleyebilirsiniz --}}
        {{-- Örnek extra item checkboxları (şu an bu örnekte extra_items veya special instructions alanları menü item yapısında yok, gerekirse eklenebilir) --}}
        {{--
        @if ($menuItem->extraItems)
            <div class="extra-items mt-2">
                <h6>Ekstralar:</h6>
                @foreach($menuItem->extraItems as $extraItem)
                    <div class="flex items-center">
                        <input type="checkbox" class="extra-item-checkbox" id="extra-item-{{ $extraItem->id }}" value="{{ $extraItem->id }}">
                        <label for="extra-item-{{ $extraItem->id }}" class="ml-2">{{ $extraItem->name }} (+{{ number_format($extraItem->price, 2) }} ₺)</label>
                    </div>
                @endforeach
            </div>
        @endif
        <div class="special-instructions mt-2">
            <textarea id="special-instructions-{{ $menuItem->id }}" class="border border-gray-300 rounded px-2 py-1 w-full" placeholder="Özel Notlar (isteğe bağlı)"></textarea>
        </div>
         --}}
    </div>
</div>
