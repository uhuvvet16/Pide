<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Ürün Barkod Okuma</title>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .barcode-container {
            text-align: center;
            margin-top: 20px;
        }
        .barcode {
            margin-bottom: 10px;
        }
    </style>
</head>
<body class="bg-gray-100 p-8">
    <form action="{{ route('compress.image') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <input type="file" name="image" accept="image/*">
        <button type="submit">Compress Image</button>
    </form>
 <hr>
    <div class="barcode-container">
        <h1>Barkod</h1>
        <div class="barcode">
            <img src="data:image/png;base64,{{ base64_encode($barcodeImage) }}" alt="EAN-13 Barkod">
        </div>
        <div>
            <strong>Kod: {{ $code }}</strong>
        </div>
    </div>
    <br><br>
    <div class="max-w-2xl mx-auto bg-white p-6 shadow-md rounded-lg">
        <h1 class="text-2xl font-bold mb-4">Ürün Barkod Okuma</h1>

        <!-- Barkod Giriş -->
        <input type="text" id="barcodeInput" name="barcode"
        placeholder="Barkod okutun..."
        class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
        autofocus>


        <!-- Ürün Tablosu -->
        <table class="min-w-full mt-6 bg-white border border-gray-200 rounded-lg">
            <thead class="bg-gray-100">
                <tr>
                    <th class="px-4 py-2 text-left text-gray-600">Ürün Adı</th>
                    <th class="px-4 py-2 text-left text-gray-600">Barkod</th>
                    <th class="px-4 py-2 text-left text-gray-600">Fiyat</th>
                    {{-- <th class="px-4 py-2 text-left text-gray-600">Stok</th> --}}
                </tr>
            </thead>
            <tbody id="productTable" class="divide-y divide-gray-200">
                <!-- Dinamik Ürünler Buraya Eklenecek -->
            </tbody>
        </table>
    </div>

    <script>
       $(document).ready(function () {
    $('#barcodeInput').on('keypress', function (e) {
        if (e.which === 13) { // Enter tuşu
            e.preventDefault();

            const barcode = $(this).val();
            const url = '{{ route("fetch.product") }}'; // Backend route

            // Ajax isteği
            $.ajax({
                url: url,
                method: 'POST',
                data: {
                    barcode: barcode
                },
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function (response) {
                    if (response.success) {
                        // Ürün bilgilerini tabloya ekle
                        const product = response.product;
                        $('#productTable').append(`
                            <tr>
                                <td class="px-4 py-2">${product.name}</td>
                                <td class="px-4 py-2">${product.barcode}</td>
                                <td class="px-4 py-2">${product.price} ₺</td>

                            </tr>
                        `);
                        $('#barcodeInput').val(''); // Input'u temizle
                    } else {
                        alert(response.message || 'Ürün bulunamadı.');
                    }
                },
                error: function () {
                    alert('Bir hata oluştu. Lütfen tekrar deneyin.');
                }
            });
        }
    });
});

    </script>
</body>
</html>
