@extends('back.layouts.master')

{{-- @section('title', 'Menü Kategori Yönetimi')
@section('title_header', 'Menü Kategori Yönetimi') --}}

@section('section')
    <div class="mb-4">
        <a href="{{ route('menu-categories.create') }}" class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
            <i class="ri-add-line align-middle"></i> Yeni Kategori Ekle
        </a>
    </div>

    @if(session('success'))
        <div class="bg-green-200 p-3 rounded mb-4">
            {{ session('success') }}
        </div>
    @endif

    <div class="overflow-x-auto">
        <table id="menuCategoriesTable" class="min-w-full bg-white border border-gray-300">
            <thead class="bg-gray-100">
                <tr>
                    <th class="px-4 py-2 border-b">#</th>
                    <th class="px-4 py-2 border-b">Adı</th>
                    <th class="px-4 py-2 border-b">Slug</th>
                    <th class="px-4 py-2 border-b">Sıra</th>
                    <th class="px-4 py-2 border-b">Açıklama</th>
                    <th class="px-4 py-2 border-b">Oluşturulma Tarihi</th>
                    <th class="px-4 py-2 border-b">İşlemler</th>
                </tr>
            </thead>
            <tbody>
                @foreach($menuCategories as $menuCategory)
                    <tr>
                        <td class="px-4 py-2 border-b">{{ $menuCategory->id }}</td>
                        <td class="px-4 py-2 border-b">{{ $menuCategory->name }}</td>
                        <td class="px-4 py-2 border-b">{{ $menuCategory->slug }}</td>
                        <td class="px-4 py-2 border-b">{{ $menuCategory->order }}</td>
                        <td class="px-4 py-2 border-b">{{ $menuCategory->description }}</td>
                        <td class="px-4 py-2 border-b">{{ $menuCategory->created_at->format('d-m-Y H:i') }}</td>
                        <td class="px-4 py-2 border-b">
                            <a href="{{ route('menu-categories.edit', $menuCategory) }}" class="text-blue-500 hover:text-blue-700"><i class="ri-edit-line align-middle"></i> Düzenle</a>
                            <form action="{{ route('menu-categories.destroy', $menuCategory) }}" method="POST" class="inline-block" onsubmit="return confirm('Menü kategorisini silmek istediğinize emin misiniz?')">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="text-red-500 hover:text-red-700 ml-2"><i class="ri-delete-bin-line align-middle"></i> Sil</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection

@section('scripts')
    <script>
        $(document).ready( function () {
            $('#menuCategoriesTable').DataTable({
                language: {
                    url: '//cdn.datatables.net/plug-ins/1.13.6/i18n/tr.json', // Türkçe dil dosyası
                }
            });
        } );
    </script>
@endsection
