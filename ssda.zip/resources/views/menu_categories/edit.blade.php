@extends('back.layouts.master')

@section('title', 'Menü Kategorisi Düzenle')
@section('title_header', 'Menü Kategorisi Düzenle')

@section('section')
<form action="{{ route('menu-categories.update', $menuCategory->id) }}" method="POST" enctype="multipart/form-data" class="max-w-lg mx-auto bg-white p-6 rounded-lg shadow-md">
    @csrf
    @method('PUT')

    <!-- Başlık -->
    <h2 class="text-xl font-bold text-gray-700 mb-4 flex items-center">
        <i class="ri-edit-2-line text-blue-500 mr-2"></i> Kategori Güncelle
    </h2>

    <!-- Kategori Adı -->
    <div class="mb-4">
        <label class="block text-gray-600 font-medium">Kategori Adı</label>
        <input type="text" name="name" value="{{ old('name', $menuCategory->name) }}" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400">
        @error('name')
            <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
        @enderror
    </div>

    <!-- Açıklama -->
    <div class="mb-4">
        <label class="block text-gray-600 font-medium">Açıklama</label>
        <textarea name="description" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400">{{ old('description', $menuCategory->description) }}</textarea>
    </div>

    <!-- Sıra -->
    <div class="mb-4">
        <label class="block text-gray-600 font-medium">Sıra</label>
        <input type="number" name="order" value="{{ old('order', $menuCategory->order) }}" min="1" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400">
        @error('order')
            <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
        @enderror
    </div>

    <!-- Mevcut Resim -->
    @if($menuCategory->image_path)
    <div class="mb-4">
        <label class="block text-gray-600 font-medium">Mevcut Resim</label>
        <img src="{{ asset($menuCategory->image_path) }}" alt="Kategori Resmi" class="w-32 h-32 object-cover rounded-md shadow">
    </div>
    @endif

    <!-- Yeni Resim Yükleme -->
    <div class="mb-4">
        <label class="block text-gray-600 font-medium">Yeni Resim</label>
        <input type="file" name="image_path" accept="image/*" onchange="previewImage(event)" class="w-full px-3 py-2 border rounded-lg">
        @error('image_path')
            <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
        @enderror
    </div>

    <!-- Resim Önizleme -->
    <div id="imagePreviewContainer" class="mb-4 hidden">
        <p class="text-gray-600 font-medium">Önizleme:</p>
        <img id="imagePreview" class="w-32 h-32 object-cover rounded-md shadow">
    </div>

    <!-- Güncelle Butonu -->
    <button type="submit" class="w-full bg-blue-500 text-white py-2 px-4 rounded-lg hover:bg-blue-600 flex items-center justify-center">
        <i class="ri-save-line mr-2"></i> Güncelle
    </button>
</form>

<!-- Resim Önizleme Scripti -->
<script>
    function previewImage(event) {
        let reader = new FileReader();
        reader.onload = function() {
            let preview = document.getElementById('imagePreview');
            preview.src = reader.result;
            document.getElementById('imagePreviewContainer').classList.remove('hidden');
        };
        reader.readAsDataURL(event.target.files[0]);
    }
</script>

@endsection
