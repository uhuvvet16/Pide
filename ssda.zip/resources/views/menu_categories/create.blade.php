@extends('back.layouts.master')

@section('title', 'Yeni Menü Kategorisi Ekle')
@section('title_header', 'Yeni Menü Kategorisi Ekle')

@section('section')
<div class="max-w-lg mx-auto mt-2 mb-4 bg-white p-6 rounded-lg shadow-lg">
    <h2 class="text-2xl font-semibold text-gray-800 flex items-center gap-2">
        <i class="ri-folder-add-line text-blue-600"></i> Menü Kategorisi Ekle
    </h2>

    @if(session('success'))
        <div class="mt-4 p-3 bg-green-100 text-green-700 rounded-lg flex items-center">
            <i class="ri-check-line mr-2"></i> {{ session('success') }}
        </div>
    @endif

    <form action="{{ route('menu-categories.store') }}" method="POST" enctype="multipart/form-data" class="mt-6 space-y-4">
        @csrf

        <!-- Kategori Adı -->
        <div>
            <label class="block text-gray-700 font-medium">Kategori Adı</label>
            <div class="relative">
                <i class="ri-folder-line absolute left-3 top-3 text-gray-400"></i>
                <input type="text" name="name" value="{{ old('name') }}"
                    class="w-full border border-gray-300 rounded-lg px-4 py-2 pl-10 focus:ring focus:ring-blue-300"
                    placeholder="Kategori adını girin">
            </div>
            @error('name')
                <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
            @enderror
        </div>

        <!-- Açıklama -->
        <div>
            <label class="block text-gray-700 font-medium">Açıklama</label>
            <textarea name="description" rows="3"
                class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring focus:ring-blue-300"
                placeholder="Açıklama ekleyin (isteğe bağlı)">{{ old('description') }}</textarea>
            @error('description')
                <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
            @enderror
        </div>

        <!-- Sıra -->
        <div>
            <label class="block text-gray-700 font-medium">Sıra</label>
            <div class="relative">
                <i class="ri-list-ordered absolute left-3 top-3 text-gray-400"></i>
                <input type="number" name="order" min="1" value="{{ old('order', 1) }}"
                    class="w-full border border-gray-300 rounded-lg px-4 py-2 pl-10 focus:ring focus:ring-blue-300">
            </div>
            @error('order')
                <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
            @enderror
        </div>

        <!-- Resim Yükleme -->
        <div>
            <label class="block text-gray-700 font-medium">Kategori Resmi</label>
            <input type="file" name="image_path"
                class="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg
                    file:border file:border-gray-300 file:text-gray-700 file:bg-gray-100 hover:file:bg-gray-200">
            @error('image_path')
                <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
            @enderror
        </div>

        <!-- Gönder Butonu -->
        <button type="submit"
            class="w-full bg-blue-600 text-white font-semibold py-2 rounded-lg shadow-md hover:bg-blue-700 transition flex items-center justify-center gap-2">
            <i class="ri-add-line"></i> Kategoriyi Kaydet
        </button>
    </form>
</div>
@endsection
