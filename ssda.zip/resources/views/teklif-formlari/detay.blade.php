<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Teklif Formu Detayı: #{{ $teklifFormu->id }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-3xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                <div class="mb-6">
                    <h3 class="text-lg font-semibold text-gray-800 mb-2">Etkinlik Bilgileri</h3>
                    <p><strong>Etkinlik Türü:</strong> {{ $teklifFormu->etkinlik_turu }}</p>
                    <p><strong>Etkinlik Tarihi:</strong> {{ $teklifFormu->etkinlik_tarihi->format('d-m-Y') }}</p>
                    <p><strong>Etkinlik Saati:</strong> {{ $teklifFormu->etkinlik_saati ? $teklifFormu->etkinlik_saati->format('H:i') : 'Belirtilmedi' }}</p>
                    <p><strong>Tahmini Kişi Sayısı:</strong> {{ $teklifFormu->kisi_sayisi }}</p>
                </div>

                <div class="mb-6">
                    <h3 class="text-lg font-semibold text-gray-800 mb-2">İletişim Bilgileri</h3>
                    <p><strong>Ad Soyad:</strong> {{ $teklifFormu->ad_soyad }}</p>
                    <p><strong>E-Posta:</strong> {{ $teklifFormu->email }}</p>
                    <p><strong>Telefon:</strong> {{ $teklifFormu->telefon }}</p>
                </div>

                @if($teklifFormu->ek_istekler)
                    <div class="mb-6">
                        <h3 class="text-lg font-semibold text-gray-800 mb-2">Ek İstekler</h3>
                        <p>{{ $teklifFormu->ek_istekler }}</p>
                    </div>
                @endif

                @if($teklifFormu->butce_araligi_min || $teklifFormu->butce_araligi_max)
                    <div class="mb-6">
                        <h3 class="text-lg font-semibold text-gray-800 mb-2">Bütçe Aralığı</h3>
                        <p><strong>Minimum:</strong> {{ $teklifFormu->butce_araligi_min ? number_format($teklifFormu->butce_araligi_min, 2) : 'Belirtilmedi' }}</p>
                        <p><strong>Maksimum:</strong> {{ $teklifFormu->butce_araligi_max ? number_format($teklifFormu->butce_araligi_max, 2) : 'Belirtilmedi' }}</p>
                    </div>
                @endif

                <div class="mt-8">
                    <a href="{{ route('admin.teklif.formlari') }}" class="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline inline-block">
                        Geri Dön
                    </a>
                    </div>
            </div>
        </div>
    </div>
</x-app-layout>
