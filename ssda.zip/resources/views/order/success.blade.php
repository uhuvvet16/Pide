<x-guest-layout>
    <div class="container mx-auto px-4 py-12 text-center">
        <h2 class="text-3xl font-bold mb-4 text-green-500">Sipariş Başarılı!</h2>
        <p class="text-gray-700">Siparişiniz başarıyla alınmıştır. Sipariş numaranız: {{ session('order_id') }}</p>
        <p class="mt-4">Teşekkür ederiz!</p>
        <a href="{{ url('/') }}" class="mt-8 bg-amber-500 hover:bg-amber-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline inline-block">Anasayfaya Dön</a>
    </div>
</x-guest-layout>
