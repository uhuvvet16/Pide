<x-guest-layout>
    <div class="container mx-auto px-4 py-12">
        <h2 class="text-3xl font-bold mb-8 text-center">Sipariş Ver</h2>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
                <h3 class="text-xl font-semibold mb-4">Standart Sipariş</h3>
                <form action="{{ route('order.store.standard') }}" method="POST" id="standardOrderForm">
                    @csrf
                    <div class="mb-4">
                        <label for="name" class="block text-gray-700 text-sm font-bold mb-2">Ad</label>
                        <input type="text" name="name" id="name" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required>
                    </div>
                    <div class="mb-4">
                        <label for="surname" class="block text-gray-700 text-sm font-bold mb-2">Soyad</label>
                        <input type="text" name="surname" id="surname" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required>
                    </div>
                    <div class="mb-4">
                        <label for="email" class="block text-gray-700 text-sm font-bold mb-2">E-posta</label>
                        <input type="email" name="email" id="email" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required>
                    </div>
                    <div class="mb-4">
                        <label for="phone" class="block text-gray-700 text-sm font-bold mb-2">Telefon</label>
                        <input type="tel" name="phone" id="phone" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required>
                    </div>
                    <div class="mb-4">
                        <label for="address" class="block text-gray-700 text-sm font-bold mb-2">Adres</label>
                        <textarea name="address" id="address" rows="3" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required></textarea>
                    </div>
                    <div class="mb-4">
                        <label for="payment_method" class="block text-gray-700 text-sm font-bold mb-2">Ödeme Yöntemi</label>
                        <select name="payment_method" id="payment_method" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required>
                            <option value="credit_card">Kredi Kartı</option>
                            <option value="cash_on_delivery">Kapıda Ödeme</option>
                        </select>
                    </div>
                    <button type="submit" class="bg-amber-500 hover:bg-amber-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">Sipariş Ver</button>
                </form>
            </div>

            <div>
                <h3 class="text-xl font-semibold mb-4">Sonradan Gel Ye Siparişi</h3>
                <form action="{{ route('order.store.come_later') }}" method="POST" id="comeLaterOrderForm">
                    @csrf
                    <div class="mb-4">
                        <label for="name_come_later" class="block text-gray-700 text-sm font-bold mb-2">Ad</label>
                        <input type="text" name="name" id="name_come_later" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required>
                    </div>
                    <div class="mb-4">
                        <label for="surname_come_later" class="block text-gray-700 text-sm font-bold mb-2">Soyad</label>
                        <input type="text" name="surname" id="surname_come_later" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required>
                    </div>
                    <div class="mb-4">
                        <label for="email_come_later" class="block text-gray-700 text-sm font-bold mb-2">E-posta</label>
                        <input type="email" name="email" id="email_come_later" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required>
                    </div>
                    <div class="mb-4">
                        <label for="phone_come_later" class="block text-gray-700 text-sm font-bold mb-2">Telefon</label>
                        <input type="tel" name="phone" id="phone_come_later" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required>
                    </div>
                    <div class="mb-4">
                        <label for="reservation_time" class="block text-gray-700 text-sm font-bold mb-2">Rezervasyon Zamanı</label>
                        <input type="datetime-local" name="reservation_time" id="reservation_time" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required>
                    </div>
                    <button type="submit" class="bg-amber-500 hover:bg-amber-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">Sipariş Ver (Sonradan Gel Ye)</button>
                </form>
            </div>
        </div>
    </div>
</x-guest-layout>
