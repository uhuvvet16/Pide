@include('front.header')
@yield('section')
@include('front.footer')
