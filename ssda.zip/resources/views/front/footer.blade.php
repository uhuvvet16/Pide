<a href="https://wa.me/905386292030" class="whatsapp__button" target="_blank">
    <span>Whatsapp</span>
    <i class="uil uil-whatsapp"></i>
</a>
<a href="https://www.instagram.com/onat_pide16/" class="instagram__button" target="_blank">
    <span>Bizi Takip Edin</span>
    <i class="uil uil-instagram"></i>
</a>

<!-- Footer -->
<footer class="footer">
    <div class="container">
        <div class="footer-content">
            <div class="footer-section">
                <h3>Onat Pide</h3>
                <p>Onat Pide, 01.01.2015'te İzmir Şirinyer'de kurulmuştur. Ancak sektör tecrübemiz 1997'ye
                    dayanmaktadır. 8. işletmemiz olan Onat Pide, kaliteli malzeme ve güvenilir hizmet anlayışıyla
                    faaliyet göstermektedir.</p>
                <div class="location-info">
                    <i class="fas fa-map-marker-alt"></i>
                    <p>Güneştepe, 2. Meşe Cd. 80/A, 16165 Osmangazi̇/Bursa</p>
                </div>
            </div>

            <div class="footer-section">
                <h3>Çalışma Saatleri</h3>
                <div class="working-hours">
                    <p>
                        <span><i class="fas fa-clock"></i> Hafta içi:</span>
                        <span>09:00 - 21:00</span>
                    </p>
                    <p>
                        <span><i class="fas fa-clock"></i> Hafta sonu:</span>
                        <span>09:00 - 21:00</span>
                    </p>
                </div>
            </div>

            <div class="footer-section">
                <h3>Sosyal Medya</h3>
                <div class="social-links">
                    <a href="https://www.instagram.com/onat_pide16/"><i class="fab fa-instagram"></i></a>
                    {{-- <a href="#"><i class="fab fa-facebook-f"></i></a> --}}
                    {{-- <a href="#"><i class="fab fa-youtube"></i></a> --}}
                </div>
            </div>
        </div>

        <div class="footer-bottom">
            <p>&copy; 2025 Onat Pide. Tüm hakları saklıdır.</p>
        </div>
    </div>
</footer>

<!-- Scroll To Top Button -->
<button onclick="scrollToTop()" id="scrollTopBtn"
    class="scroll-top fixed left-4 bottom-4 bg-amber-600 text-white p-2 rounded-full opacity-0 translate-y-5 transition hover:bg-amber-700">
    <i class="ri-arrow-up-line text-xl"></i>
</button>


<!-- Scripts -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/8.4.5/swiper-bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightgallery-js/1.4.0/js/lightgallery.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        lightGallery(document.getElementById('lightgallery'), {
            selector: 'a',
            plugins: [],
            download: false, // İsteğe bağlı: İndirme butonunu kaldırır
            loop: true,
            thumbnail: false,
            autoplayControls: true,
            controls: true
        });
    });
</script>



<script>
    document.addEventListener('DOMContentLoaded', function() {
        const mobileMenuButton = document.querySelector('.mobile-menu-button');
        const mobileMenu = document.querySelector('.mobile-menu');
        const navbar = document.querySelector('.navbar');
        const dropdownToggles = document.querySelectorAll('.mobile-menu-item.menu-dropdown .menu-button');

        // Mobil menüyü aç/kapa
        mobileMenuButton.addEventListener('click', function() {
            mobileMenu.classList.toggle('active');
        });

        // Sayfa kaydırıldığında navbarı sticky yap ve blur ekle
        window.addEventListener('scroll', function() {
            if (window.scrollY > 50) {
                navbar.classList.add('sticky');
            } else {
                navbar.classList.remove('sticky');
            }
        });

        // Mobil menü dropdown aç/kapa
        dropdownToggles.forEach(toggle => {
            toggle.addEventListener('click', function(e) {
                e.preventDefault();
                const parentItem = this.closest('.mobile-menu-item');
                parentItem.classList.toggle('active');
            });
        });
    });
    const scrollTopBtn = document.getElementById('scrollTopBtn');

    window.onscroll = function() {
        if (document.documentElement.scrollTop > 200) {
            scrollTopBtn.classList.remove('opacity-0', 'translate-y-5');
        } else {
            scrollTopBtn.classList.add('opacity-0', 'translate-y-5');
        }
    };

    function scrollToTop() {
        const scrollStep = -window.scrollY / 45; // 60 adımda yukarı çık
        function scrollAnimation() {
            if (window.scrollY > 0) {
                window.scrollBy(0, scrollStep);
                requestAnimationFrame(scrollAnimation);
            }
        }
        scrollAnimation();
    }

    // Initialize AOS
    AOS.init({
        duration: 800,
        offset: 100,
        once: true
    });

    // Mobile Menu Toggle
    function toggleMenu() {
        const menu = document.getElementById('mobileMenu');
        menu.classList.toggle('hidden');
    }





    // Scroll kontrolü için navbar renk değişimi
    window.addEventListener('scroll', function() {
        const navbar = document.getElementById('navbar');
        if (window.scrollY > 50) {
            navbar.classList.add('bg-white/95', 'backdrop-blur-md', 'shadow-md');
            navbar.classList.remove('bg-transparent');
            // Menü yazı renklerini değiştir
            const menuItems = navbar.getElementsByTagName('a');
            for (let item of menuItems) {
                item.classList.remove('text-white');
                item.classList.add('text-gray-600');
            }
        } else {
            navbar.classList.remove('bg-white/95', 'backdrop-blur-md', 'shadow-md');
            navbar.classList.add('bg-transparent');
            // Menü yazı renklerini geri al
            const menuItems = navbar.getElementsByTagName('a');
            for (let item of menuItems) {
                if (!item.classList.contains('text-amber-600')) { // Logo hariç
                    item.classList.add('text-white');
                    item.classList.remove('text-gray-600');
                }
            }
        }
    });
</script>

<script>
    // Ana Sayfa Slider
    const mainSwiper = new Swiper('.mainSwiper', {
        loop: true,
        autoplay: {
            delay: 5000,
            disableOnInteraction: false,
        },
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
    });

    // Müşteri Yorumları Slider
    const reviewSwiper = new Swiper('.reviewSwiper', {
        slidesPerView: 1,
        spaceBetween: 30,
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
        breakpoints: {
            640: {
                slidesPerView: 2,
            },
            1024: {
                slidesPerView: 3,
            }
        }
    });

    // Online Sipariş Sistemi
    const menu = {
        'kiymalı': {
            name: 'Kıymalı Pide',
            price: 75
        },
        'kasarlı': {
            name: 'Kaşarlı Pide',
            price: 70
        },
        'kusbasılı': {
            name: 'Kuşbaşılı Pide',
            price: 85
        },
        'karisik': {
            name: 'Karışık Pide',
            price: 90
        },
        'sucuklu': {
            name: 'Sucuklu Pide',
            price: 80
        },
        'yumurtalı': {
            name: 'Yumurtalı Pide',
            price: 75
        }
    };

    let orderItemCount = 0;

    function addOrderItem() {
        orderItemCount++;
        const orderItems = document.getElementById('orderItems');

        const itemDiv = document.createElement('div');
        itemDiv.className = 'flex items-center space-x-4';
        itemDiv.innerHTML = `
    <select onchange="updateTotal()" class="flex-1 px-4 py-2 border rounded-lg focus:outline-none focus:border-amber-600">
        <option value="">Ürün Seçin</option>
        ${Object.entries(menu).map(([key, item]) =>
            `<option value="${key}">${item.name} - ₺${item.price}</option>`
        ).join('')}
    </select>
    <input type="number" min="1" value="1" onchange="updateTotal()"
        class="w-20 px-4 py-2 border rounded-lg focus:outline-none focus:border-amber-600">
    <button type="button" onclick="removeOrderItem(this)"
        class="text-red-500 hover:text-red-700">
        <i class="ri-delete-bin-line"></i>
    </button>
`;

        orderItems.appendChild(itemDiv);
        updateTotal();
    }

    function removeOrderItem(button) {
        button.parentElement.remove();
        updateTotal();
    }

    function updateTotal() {
        let total = 0;
        const orderItems = document.getElementById('orderItems').children;

        for (let item of orderItems) {
            const select = item.querySelector('select');
            const quantity = item.querySelector('input[type="number"]').value;

            if (select.value) {
                total += menu[select.value].price * quantity;
            }
        }

        document.getElementById('totalPrice').textContent = `Toplam: ₺${total}`;
    }

    // Form Submissions
    document.getElementById('orderForm').addEventListener('submit', function(e) {
        e.preventDefault();
        // Burada sipariş gönderme API'si entegre edilebilir
        alert('Siparişiniz alındı! En kısa sürede hazırlanacaktır.');
    });

    // Rezervasyon formu submit
    document.querySelector('#reservation form').addEventListener('submit', function(e) {
        e.preventDefault();
        // Burada rezervasyon API'si entegre edilebilir
        alert('Rezervasyonunuz alındı! Onay için sizinle iletişime geçeceğiz.');
    });

    // İlk sipariş öğesini otomatik ekle
    addOrderItem();
</script>
<script>
    $(document).ready(function() {
        let currentPage = 1;
        let currentCategoryId = 'all';
        let loading = false;
        let noMoreItems = false; // Tüm ürünlerin yüklenip yüklenmediğini takip etmek için

        // Kategori butonlarına tıklama olayı
        $('.category-btn').click(function() {
            $('.category-btn').removeClass('active'); // Tüm butonlardan active sınıfını kaldır
            $(this).addClass('active'); // Tıklanan butona active sınıfını ekle
            currentCategoryId = $(this).data('category-id');
            currentPage = 1; // Kategori değiştiğinde sayfayı sıfırla
            noMoreItems = false; // Yeni kategori seçildiğinde "Devamını Gör" butonunu tekrar aktif et
            loadMenuItems(currentCategoryId, currentPage);
        });

        // "Devamını Gör" butonuna tıklama olayı
        $('#load-more-button').click(function() {
            if (loading || noMoreItems)
                return; // Eğer yükleniyorsa veya tüm ürünler yüklendiyse işlemi durdur
            loading = true;
            currentPage++; // Sayfa numarasını artır
            loadMenuItems(currentCategoryId, currentPage);
        });

        function loadMenuItems(categoryId, page) {
            if (noMoreItems) return; // Eğer tüm ürünler yüklendiyse daha fazla yükleme yapma

            $.ajax({
                url: "{{ route('get.menu.items') }}",
                type: 'GET',
                data: {
                    category_id: categoryId,
                    page: page
                },
                dataType: 'json',
                beforeSend: function() {
                    $('#load-more-button').text(
                        'Yükleniyor...'); // Buton metnini "Yükleniyor..." olarak değiştir
                },
                success: function(response) {
                    loading = false;
                    $('#load-more-button').text('Devamını Gör'); // Buton metnini geri al

                    if (page === 1) {
                        $('#menu-items-container')
                            .empty(); // İlk sayfayı yüklerken mevcut içeriği temizle
                    }

                    if (response.data.length > 0) {
                        $.each(response.data, function(index, item) {
                            // Blade partial kullanarak menü item HTML'ini oluştur ve ekle
                            let menuItemHTML = `
                                <div class="menu-item">
                                    <div class="item-image" style="background-image: url('${item.image ? '/storage/' + item.image : 'https://source.unsplash.com/random/400x300/?food'}');">
                                        ${item.label ? '<span class="item-badge">' + item.label + '</span>' : ''}
                                    </div>
                                    <div class="item-content">
                                        <div class="item-title">
                                            <span>${item.name}</span>
                                            <span class="item-price">${item.price ? item.price + ' ₺' : ''}</span>
                                        </div>
                                        <p class="item-description">${item.description || ''}</p>
                                        <div class="item-features">
                                            ${item.extra_condition ? '<span class="feature"><i class="fas fa-info-circle"></i>' + item.extra_condition + '</span>' : ''}
                                            ${item.preparation_time ? '<span class="feature"><i class="fas fa-clock"></i>' + item.preparation_time + ' dk</span>' : ''}
                                            ${item.rating ? '<span class="feature"><i class="fas fa-star"></i>' + item.rating + '</span>' : ''}
                                        </div>
                                    </div>
                                    <span class="item-category" style="display: none;">${item.category ? item.category.name : 'Tüm Menü'}</span>
                                </div>
                            `;
                            $('#menu-items-container').append(menuItemHTML);
                        });

                        if (!response.next_page_url) {
                            $('#load-more-container')
                                .hide(); // Eğer sonraki sayfa yoksa "Devamını Gör" butonunu gizle
                            noMoreItems = true; // Tüm ürünler yüklendi işaretle
                        } else {
                            $('#load-more-button').data('next-page-url', response
                                .next_page_url
                                ); // "Devamını Gör" butonunun data-next-page-url özelliğini güncelle
                        }


                    } else if (page === 1) {
                        $('#menu-items-container').html(
                            '<p>Bu kategoride ürün bulunmamaktadır.</p>'
                            ); // Kategoriye ait ürün yoksa mesaj göster
                        $('#load-more-container')
                            .hide(); // Ürün yoksa "Devamını Gör" butonunu gizle
                    } else {
                        $('#load-more-container')
                            .hide(); // Daha fazla ürün yoksa "Devamını Gör" butonunu gizle
                        noMoreItems = true; // Tüm ürünler yüklendi işaretle
                    }
                },
                error: function(xhr, status, error) {
                    loading = false;
                    $('#load-more-button').text('Devamını Gör'); // Buton metnini geri al
                    console.error("Menü öğeleri yüklenirken hata oluştu:", error);
                    if (page === 1) {
                        $('#menu-items-container').html(
                            '<p>Menü öğeleri yüklenirken bir hata oluştu. Lütfen sayfayı yenileyin.</p>'
                        );
                    }
                    if (page > 1) {
                        $('#load-more-container')
                            .hide(); // Hata durumunda "Devamını Gör" butonunu gizle
                        noMoreItems =
                            true; // Tüm ürünler yüklendi işaretle, hata sonrası tekrar yükleme denemesini engellemek için
                    }
                }
            });
        }
    });
</script>
<script>
    // Menü Filtresi
    document.querySelectorAll('.menu-filter-btn').forEach(button => {
        button.addEventListener('click', () => {
            // Aktif buton stilini güncelle
            document.querySelector('.menu-filter-btn.active').classList.remove('active');
            button.classList.add('active');

            const filter = button.dataset.filter;

            document.querySelectorAll('.menu-item').forEach(item => {
                if (filter === 'all' || item.dataset.category === filter) {
                    item.style.display = 'block';
                } else {
                    item.style.display = 'none';
                }
            });
        });
    });

    // Kampanya Sayacı
    function updateCampaignTimer() {
        const timer = document.getElementById('campaign1Timer');
        if (!timer) return;

        let [hours, minutes, seconds] = timer.textContent.split(':').map(Number);

        setInterval(() => {
            seconds--;
            if (seconds < 0) {
                seconds = 59;
                minutes--;
                if (minutes < 0) {
                    minutes = 59;
                    hours--;
                    if (hours < 0) {
                        hours = 23; // Reset timer for demo
                    }
                }
            }
            timer.textContent =
                `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
        }, 1000);
    }

    // Sipariş Takip
    function trackOrder() {
        const orderNumber = document.getElementById('orderTrackingNumber').value;
        if (!orderNumber) return;

        document.getElementById('orderStatus').classList.remove('hidden');

        // Demo için rastgele sipariş durumu
        const steps = document.querySelectorAll('.order-status-step');
        const randomProgress = Math.floor(Math.random() * 4) + 1;

        steps.forEach((step, index) => {
            if (index < randomProgress) {
                step.classList.add('completed');
            } else {
                step.classList.remove('completed');
            }
        });
    }

    // Lightbox ayarları
    lightbox.option({
        'resizeDuration': 200,
        'wrapAround': true
    });

    // Sayfa yüklendiğinde
    document.addEventListener('DOMContentLoaded', () => {
        updateCampaignTimer();
    });
</script>

<script>
    $(document).ready(function() {
        // Load cart on page load
        loadCart();

        // Toggle cart dropdown
        $('#cart-button').on('click', function(e) {
            e.stopPropagation();
            $('#cart-menu').toggleClass('hidden');
        });

        // Close cart when clicking outside
        $(document).on('click', function(e) {
            if (!$(e.target).closest('#cart-dropdown').length) {
                $('#cart-menu').addClass('hidden');
            }
        });

        // Add to cart button click
        $(document).on('click', '.add-to-cart', function(e) {
            e.preventDefault();

            const menuItemId = $(this).data('id');
            const quantity = parseInt($('#quantity-' + menuItemId).val() || 1);

            // Get selected extra items
            const extraItems = [];
            $('.extra-item-checkbox:checked').each(function() {
                extraItems.push($(this).val());
            });

            // Get special instructions
            const specialInstructions = $('#special-instructions-' + menuItemId).val();

            addToCart(menuItemId, quantity, extraItems, specialInstructions);
        });

        // Update quantity
        $(document).on('click', '.update-quantity', function() {
            const itemId = $(this).data('item-id');
            const action = $(this).data('action');
            const quantityInput = $('#cart-item-quantity-' + itemId);
            let quantity = parseInt(quantityInput.val());

            if (action === 'increase') {
                quantity += 1;
            } else if (action === 'decrease' && quantity > 1) {
                quantity -= 1;
            }

            quantityInput.val(quantity);
            updateCartItem(itemId, quantity);
        });

        // Remove item from cart
        $(document).on('click', '.remove-from-cart', function() {
            const itemId = $(this).data('item-id');
            removeFromCart(itemId);
        });
    });

    function loadCart() {
        $.ajax({
            url: '/cart',
            method: 'GET',
            success: function(response) {
                updateCartUI(response);
            },
            error: function(error) {
                console.error('Error loading cart:', error);
            }
        });
    }

    function addToCart(menuItemId, quantity, extraItems, specialInstructions) {
        $.ajax({
            url: '/cart/add',
            method: 'POST',
            data: {
                menu_item_id: menuItemId,
                quantity: quantity,
                extra_items: extraItems,
                special_instructions: specialInstructions,
                _token: '{{ csrf_token() }}'
            },
            success: function(response) {
                updateCartUI(response.cart);
                showNotification('Item added to cart');
            },
            error: function(error) {
                console.error('Error adding to cart:', error);
                showNotification('Failed to add item to cart', 'error');
            }
        });
    }

    function updateCartItem(itemId, quantity) {
        $.ajax({
            url: '/cart/update',
            method: 'POST',
            data: {
                item_id: itemId,
                quantity: quantity,
                _token: '{{ csrf_token() }}'
            },
            success: function(response) {
                updateCartUI(response.cart);
            },
            error: function(error) {
                console.error('Error updating cart:', error);
                showNotification('Failed to update cart', 'error');
            }
        });
    }

    function removeFromCart(itemId) {
        $.ajax({
            url: '/cart/remove',
            method: 'POST',
            data: {
                item_id: itemId,
                _token: '{{ csrf_token() }}'
            },
            success: function(response) {
                updateCartUI(response.cart);
                showNotification('Item removed from cart');
            },
            error: function(error) {
                console.error('Error removing from cart:', error);
                showNotification('Failed to remove item', 'error');
            }
        });
    }

    function updateCartUI(cart) {
        // Update cart count
        const itemCount = Object.keys(cart.items).length;
        $('#cart-count').text(itemCount);

        // Update cart total
        $('#cart-total').text('₺' + cart.total.toFixed(2));

        // Update cart items
        const $cartItems = $('#cart-items');
        $cartItems.empty();

        if (itemCount === 0) {
            $cartItems.html('<p class="py-4 text-center text-gray-500">Your cart is empty</p>');
            return;
        }

        $.each(cart.items, function(id, item) {
            const extraItemsHtml = item.extra_items.length > 0 ?
                '<div class="text-xs text-gray-500 mt-1">' +
                item.extra_items.map(extra => extra.name).join(', ') +
                '</div>' :
                '';

            const itemHtml = `
            <div class="py-2 border-b border-gray-100 last:border-0">
                <div class="flex justify-between">
                    <div>
                        <div class="font-medium">${item.name}</div>
                        ${extraItemsHtml}
                        <div class="text-sm text-gray-500 mt-1">₺${item.price.toFixed(2)}</div>
                    </div>
                    <div class="flex flex-col items-end">
                        <div class="flex items-center space-x-2">
                            <button class="update-quantity text-gray-500 hover:text-orange-500" data-item-id="${id}" data-action="decrease">
                                <i class="ri-subtract-line"></i>
                            </button>
                            <input id="cart-item-quantity-${id}" type="text" class="w-8 text-center border border-gray-200 rounded" value="${item.quantity}" readonly>
                            <button class="update-quantity text-gray-500 hover:text-orange-500" data-item-id="${id}" data-action="increase">
                                <i class="ri-add-line"></i>
                            </button>
                        </div>
                        <div class="text-sm font-medium mt-1">₺${item.subtotal.toFixed(2)}</div>
                        <button class="remove-from-cart text-xs text-red-500 hover:text-red-700 mt-1" data-item-id="${id}">
                            <i class="ri-delete-bin-line"></i> Remove
                        </button>
                    </div>
                </div>
            </div>
        `;

            $cartItems.append(itemHtml);
        });
    }

    function showNotification(message, type = 'success') {
        const notificationClass = type === 'success' ? 'bg-green-500' : 'bg-red-500';

        const notification = `
        <div class="fixed top-4 right-4 ${notificationClass} text-white px-4 py-2 rounded shadow-lg notification">
            ${message}
        </div>
    `;

        $('body').append(notification);

        setTimeout(function() {
            $('.notification').fadeOut(300, function() {
                $(this).remove();
            });
        }, 3000);
    }
</script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Menü Dropdown (Geniş Ekran)
        const menuDropdownButton = document.querySelector('.navbar .menu-dropdown > button');
        const menuDropdownMenu = document.querySelector('.navbar .menu-dropdown > .dropdown-menu');

        if (menuDropdownButton && menuDropdownMenu) {
            menuDropdownButton.addEventListener('click', function() {
                menuDropdownMenu.classList.toggle('hidden');
            });
        }


        // Hesap Dropdown (Geniş Ekran)
        const accountDropdownButton = document.querySelector('.navbar .account-dropdown > button');
        const accountDropdownMenu = document.querySelector('.navbar .account-dropdown > .dropdown-menu');

        if (accountDropdownButton && accountDropdownMenu) {
            accountDropdownButton.addEventListener('click', function() {
                accountDropdownMenu.classList.toggle('hidden');
            });
        }




        // Mobil Menü - Menü Dropdown
        const mobileMenuDropdownButton = document.querySelector('.mobile-menu .menu-dropdown > button');
        const mobileMenuDropdownMenu = document.querySelector('.mobile-menu .menu-dropdown > .dropdown-menu');

        if (mobileMenuDropdownButton && mobileMenuDropdownMenu) {
            mobileMenuDropdownButton.addEventListener('click', function() {
                mobileMenuDropdownMenu.classList.toggle('hidden');
            });
        }

         // Mobil Menü - Hesap Dropdown
         const mobileAccountDropdownButton = document.querySelector('.mobile-menu .account-dropdown > button');
         const mobileAccountDropdownMenu = document.querySelector('.mobile-menu .account-dropdown > .dropdown-menu');

         if (mobileAccountDropdownButton && mobileAccountDropdownMenu) {
            mobileAccountDropdownButton.addEventListener('click', function() {
                mobileAccountDropdownMenu.classList.toggle('hidden');
            });
        }

        // Dropdown Menülerini Tıklama Dışında Kapatma (Geniş Ekran)
        document.addEventListener('click', function(event) {
            if (!menuDropdownMenu?.closest('div')?.contains(event.target) && !menuDropdownButton?.contains(event.target)) {
                menuDropdownMenu?.classList.add('hidden');
            }
            if (!cartDropdownMenu?.closest('div')?.contains(event.target) && !cartDropdownButton?.contains(event.target)) {
                cartDropdownMenu?.classList.add('hidden');
            }
            if (!accountDropdownMenu?.closest('div')?.contains(event.target) && !accountDropdownButton?.contains(event.target)) {
                accountDropdownMenu?.classList.add('hidden');
            }
            if (!mobileMenuDropdownMenu?.closest('div')?.contains(event.target) && !mobileMenuDropdownButton?.contains(event.target)) {
                mobileMenuDropdownMenu?.classList.add('hidden');
            }
            if (!mobileAccountDropdownMenu?.closest('div')?.contains(event.target) && !mobileAccountDropdownButton?.contains(event.target)) {
                mobileAccountDropdownMenu?.classList.add('hidden');
            }
        });
    });
</script>
@yield('scripts')
</body>

</html>
