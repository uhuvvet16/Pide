<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="En lezzetli geleneksel ve modern pide çeşitleri. Taze malzemeler, özel taş fırın.">
    <title>@yield('title', 'Onat Pide | Geleneksel Taş Fırın')</title>

    <!-- TailwindCSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Icon -->
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.8/css/line.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">

    <!-- AOS Animations -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/8.4.5/swiper-bundle.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightgallery-js/1.4.0/css/lightgallery.min.css">


    <!-- Custom Styles -->
    <style>
        /* Tema değişkenleri */
        :root {
            --bg-primary: #ffffff;
            --bg-secondary: #f9fafb;
            --text-primary: #1f2937;
            --text-secondary: #E63946;
            --border-color: #e5e7eb;
        }

        [data-theme="dark"] {
            --bg-primary: #1f2937;
            --bg-secondary: #111827;
            --text-primary: #f9fafb;
            --text-secondary: #E63946;
            --border-color: #374151;
        }

        /* Tema geçiş animasyonu */
        * {
            transition: background-color 0.3s, color 0.3s, border-color 0.3s;
        }

        /* Tema stilleri */
        body {
            background-color: var(--bg-primary);
            color: var(--text-primary);
            overflow-x: hidden;
            max-width: 100vw;
        }

        .bg-theme-primary {
            background-color: var(--bg-primary);
        }

        .bg-theme-secondary {
            background-color: var(--bg-secondary);
        }

        .text-theme-primary {
            color: var(--text-primary);
        }

        .text-theme-secondary {
            color: var(--text-secondary);
        }

        .border-theme {
            border-color: var(--border-color);
        }

        /* Tema toggle butonu stilleri */
        .theme-toggle {
            position: fixed;
            bottom: 20px;
            left: 20px;
            z-index: 50;
            padding: 12px;
            border-radius: 50%;
            background-color: var(--bg-primary);
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            border: 1px solid var(--border-color);
        }

        html {
            scroll-behavior: smooth;
        }

        /* Scroll stilini özelleştirme */
        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: rgba(243, 244, 246, 0.1);
        }

        ::-webkit-scrollbar-thumb {
            background: rgba(230, 57, 70, 0.5);
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: rgba(234, 88, 12, 0.7);
        }

        .navbar {
            background-color: #fff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .navbar.sticky {
            background-color: rgba(255, 255, 255, 0.8);
            backdrop-filter: blur(10px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
        }

        .navbar-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 20px;
            max-width: 1200px;
            margin: 0 auto;
        }


        .siparis-hatti {
            display: flex;
            align-items: center;
            color: #333;
        }

        .siparis-hatti i {
            margin-right: 5px;
            font-size: 1.2em;
        }

        .siparis-hatti span {
            font-weight: bold;
            margin-right: 10px;
        }

        .siparis-hatti p {
            margin: 0;
            font-size: 0.9em;
        }


        /* Navbar Ana Kısım */
        .navbar-main {
            display: flex;
            align-items: center;
            justify-content: space-between;
            width: 100%;
        }

        .navbar-brand {
            text-decoration: none;
            color: #e74c3c;
            /* Restoran temasına uygun renk */
            font-size: 1.5em;
            font-weight: bold;
        }

        .navbar-menu {
            list-style: none;
            padding: 0;
            margin: 0;
            display: flex;
            align-items: center;
        }

        .navbar-menu li {
            margin-left: 25px;
            position: relative;
            /* Dropdown için pozisyonlama */
        }

        .navbar-menu li:first-child {
            margin-left: 0;
        }

        .navbar-menu a {
            text-decoration: none;
            color: #555;
            font-weight: 500;
            transition: color 0.3s ease;
            display: block;
            /* Tıklanabilir alanı genişletmek için */
            padding: 10px 0;
            /* Dikey boşluk ayarı */
        }

        .navbar-menu a:hover {
            color: #e74c3c;
        }

        .navbar-menu .sepet,
        .navbar-menu .siparislerim,
        .navbar-menu .menu-button,
        .navbar-menu .online-siparis-ver {
            display: flex;
            align-items: center;
        }

        .navbar-menu .sepet i,
        .navbar-menu .siparislerim i,
        .navbar-menu .menu-button i {
            margin-right: 5px;
            font-size: 1.2em;
        }


        /* Dropdown Menü Stilleri */
        .menu-dropdown .dropdown-menu {
            position: absolute;
            top: 100%;
            left: 0;
            background-color: #fff;
            border: 1px solid #eee;
            border-top: none;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 15px;
            list-style: none;
            width: 200px;
            /* Dropdown genişliği */
            display: none;
            /* Başlangıçta gizli */
        }

        .menu-dropdown:hover .dropdown-menu {
            display: block;
            /* Hover olunca göster */
        }

        .dropdown-menu li {
            margin: 0;
            padding: 10px 0;
            border-bottom: 1px solid #f0f0f0;
        }

        .dropdown-menu li:last-child {
            border-bottom: none;
        }

        .dropdown-menu a {
            display: flex;
            align-items: center;
            padding: 5px 0;
            color: #333;
        }

        .dropdown-menu img {
            width: 30px;
            height: 30px;
            margin-right: 10px;
            border-radius: 4px;
            object-fit: cover;
        }


        /* Mobil Menü Butonu */
        .mobile-menu-button {
            display: none;
            /* Başlangıçta masaüstünde gizli */
            font-size: 1.8em;
            color: #555;
            cursor: pointer;
        }

        /* Mobil Menü */
        .mobile-menu {
            position: fixed;
            top: 0;
            right: 0;
            height: 100%;
            width: 250px;
            background-color: #fff;
            box-shadow: -2px 0 5px rgba(0, 0, 0, 0.2);
            padding: 20px;
            transform: translateX(100%);
            /* Başlangıçta sağda gizli */
            transition: transform 0.3s ease;
            z-index: 101;
            /* Navbar'ın üzerinde */
            overflow-y: auto;
            /* Uzun içerik için kaydırma */
        }

        .mobile-menu.active {
            transform: translateX(0);
            /* Aktif olduğunda içeri kaydır */
        }

        .mobile-menu-list {
            list-style: none;
            padding: 0;
            margin-top: 40px;
        }

        .mobile-menu-list li {
            padding: 10px 0;
            border-bottom: 1px solid #f0f0f0;
        }

        .mobile-menu-list li:last-child {
            border-bottom: none;
        }

        .mobile-menu-list a {
            display: block;
            text-decoration: none;
            color: #333;
            padding: 10px 0;
        }

        .mobile-menu-item .dropdown-menu {
            position: static;
            /* Mobil menüde statik konum */
            display: none;
            /* Başlangıçta kapalı */
            border: none;
            box-shadow: none;
            padding-left: 20px;
            width: 100%;
        }

        .mobile-menu-item.active .dropdown-menu {
            display: block;
            /* Aktif olduğunda göster */
        }

        .mobile-menu-item .dropdown-menu li {
            border-bottom: none;
            /* Alt çizgiyi kaldır */
        }


        /* Responsive Tasarım */
        @media (max-width: 960px) {
            .navbar-container {
                flex-direction: column;
                align-items: stretch;
            }

            .navbar-top {
                display: flex;
                /* Mobil ve küçük ekranlarda göster */
                justify-content: flex-end;
                margin-bottom: 15px;
                width: 100%;
            }

            .navbar-main {
                flex-direction: column;
                align-items: stretch;
            }

            .navbar-brand {
                margin-bottom: 15px;
                text-align: center;
            }

            .navbar-menu {
                display: none;
                /* Masaüstü menüsünü gizle */
            }

            .mobile-menu-button {
                display: block;
                /* Mobil menü butonunu göster */
                position: absolute;
                top: 20px;
                right: 20px;
            }

            .navbar-container {
                position: relative;
                /* Mobil menü butonu için */
            }
        }


        @media (max-width: 768px) {
            .siparis-hatti {
                flex-direction: column;
                text-align: right;
            }

            .siparis-hatti span {
                margin-bottom: 5px;
            }
        }

        /* Mobil menü animasyonu */
        #mobileMenu {
            transform: translateX(100%);
            transition: transform 0.3s ease-in-out;
        }

        #mobileMenu.active {
            transform: translateX(0);
        }


        .hero-section {
            background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('https://images.unsplash.com/photo-1634487359989-3e90c9432133?q=80');
            background-size: cover;
            background-position: center;
        }

        .h-screen .swiper {
            width: 100%;
            height: 100vh;
        }

        .h-screen .swiper-slide {
            background-position: center;
            background-size: cover;
        }

        .h-screen .overlay {
            background: rgba(0, 0, 0, 0.5);
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
        }

        .menu-filter-btn.active {
            background-color: #d97706;
            color: white;
        }

        .campaign-timer {
            background: rgba(217, 119, 6, 0.1);
            border: 1px solid #d97706;
        }

        .order-status-step.completed {
            color: #d97706;
            border-color: #d97706;
        }

        .order-status-step.completed::after {
            background-color: #d97706;
        }

        .social-feed-item:hover {
            transform: translateY(-5px);
        }

        .whatsapp__button i,
        .whatsapp__button span {
            background: #25d366;
        }

        .whatsapp__button {
            position: fixed;
            bottom: 25px;
            right: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #FFF;
            text-decoration: none;
            border-radius: 10px;
            text-align: center;
            /* background-color: #25d366; */
            /* box-shadow: rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px; */
            z-index: 100;
        }

        .whatsapp__button:hover,
        .whatsapp__button:focus {
            color: #ffffff;
        }

        .whatsapp__button i,
        .whatsapp__button span {
            background: #25d366;
        }

        .whatsapp__button i {
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 25px;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background-color: #25d366;
        }

        .whatsapp__button span {
            font-size: 14px;
            background-color: #25d366;
            padding: 5px 10px;
            border-radius: 5px;
            margin: 0 -10px 0 0;
        }


        @media screen and (max-width: 768px) {
            .whatsapp__button {
                bottom: 65px;
                right: 15px;
            }
        }

        .instagram__button i,
        .instagram__button span {
            background: radial-gradient(circle at 30% 107%, #fdf497 0%, #fdf497 5%, #fd5949 45%, #d6249f 60%, #285AEB 90%);
        }

        .instagram__button {
            position: fixed;
            bottom: 85px;
            right: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #FFF;
            text-decoration: none;
            border-radius: 10px;
            text-align: center;
            /* background-color: #25d366; */
            /* box-shadow: rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px; */
            z-index: 100;
        }

        .instagram__button:hover,
        .instagram__button:focus {
            color: #ffffff;
        }

        .instagram__button i,
        .instagram__button span {
            background: #25d366;
        }

        .instagram__button i {
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 25px;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: radial-gradient(circle at 30% 107%, #fdf497 0%, #fdf497 5%, #fd5949 45%, #d6249f 60%, #285AEB 90%);
        }

        .instagram__button span {
            font-size: 14px;
            background: #fd5949;
            padding: 5px 10px;
            border-radius: 5px;
            margin: 0 -10px 0 0;
        }


        @media screen and (max-width: 768px) {
            .instagram__button {
                bottom: 135px;
                right: 15px;
            }
        }

        #scrollTopBtn {
            bottom: 45px;
            width: 37px;
            height: 37px;
            border-radius: 50%;
            padding: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: opacity 0.5s ease-out, transform 0.5s ease-out;
        }

        #scrollTopBtn i {
            font-size: 18px;
        }


        .scroll-top {
            transition: opacity 0.5s ease-out, transform 0.5s ease-out;
        }

        .menu-container {
            max-width: 1200px;
            margin: 0 auto;
        }

        .menu-header {
            text-align: center;
            margin-bottom: 50px;
            position: relative;
        }

        .menu-header h1 {
            font-size: 3em;
            color: #2c3e50;
            margin-bottom: 20px;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.1);
        }

        .menu-header p {
            color: #7f8c8d;
            font-size: 1.2em;
        }

        .menu-categories {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 20px;
            margin-bottom: 40px;
        }

        .category-btn {
            padding: 12px 25px;
            border: none;
            background: white;
            color: #2c3e50;
            border-radius: 30px;
            cursor: pointer;
            font-size: 1.1em;
            font-weight: 500;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }

        .category-btn:hover,
        .category-btn.active {
            background: #e67e22;
            color: white;
            transform: translateY(-2px);
        }

        .menu-items {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
            padding: 20px;
        }

        .menu-item {
            background: white;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            position: relative;
        }

        .menu-item:hover {
            transform: translateY(-10px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
        }

        .item-image {
            height: 200px;
            background-size: cover;
            background-position: center;
            position: relative;
        }

        .item-badge {
            position: absolute;
            top: 20px;
            right: 20px;
            background: #e74c3c;
            color: white;
            padding: 8px 15px;
            border-radius: 20px;
            font-size: 0.9em;
            font-weight: 500;
        }

        .item-content {
            padding: 25px;
        }

        .item-title {
            font-size: 1.4em;
            color: #2c3e50;
            margin-bottom: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .item-price {
            color: #e67e22;
            font-weight: 600;
            font-size: 1.2em;
        }

        .item-description {
            color: #7f8c8d;
            margin-bottom: 15px;
            line-height: 1.6;
        }

        .item-features {
            display: flex;
            gap: 15px;
            margin-top: 15px;
        }

        .feature {
            display: flex;
            align-items: center;
            gap: 5px;
            color: #95a5a6;
            font-size: 0.9em;
        }

        .feature i {
            color: #e67e22;
        }

        @media (max-width: 768px) {
            .menu-header h1 {
                font-size: 2em;
            }

            .menu-items {
                grid-template-columns: 1fr;
            }
        }

        /* footer */

        .footer {
            background: linear-gradient(to right, #1a1c20, #2d3436);
            color: #fff;
            padding: 4rem 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        footer .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 2rem;
        }

        .footer-content {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 3rem;
        }

        .footer-section h3 {
            color: #fff;
            font-size: 1.5rem;
            margin-bottom: 1.5rem;
            position: relative;
            padding-bottom: 0.5rem;
        }

        .footer-section h3::after {
            content: '';
            position: absolute;
            left: 0;
            bottom: 0;
            width: 50px;
            height: 2px;
            background: #e74c3c;
        }

        .footer-section p {
            color: #bdc3c7;
            line-height: 1.6;
            margin-bottom: 1rem;
        }

        .working-hours {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .working-hours p {
            display: flex;
            justify-content: space-between;
            padding: 0.5rem 0;
            border-bottom: 1px solid #34495e;
        }

        .social-links {
            display: flex;
            gap: 1rem;
        }

        .social-links a {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            color: #fff;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .social-links a:hover {
            background: #e74c3c;
            transform: translateY(-3px);
        }

        .footer-bottom {
            margin-top: 3rem;
            padding-top: 2rem;
            border-top: 1px solid #34495e;
            text-align: center;
            color: #bdc3c7;
        }

        .location-info {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin-top: 1rem;
            color: #bdc3c7;
        }

        @media (max-width: 768px) {
            .footer-content {
                grid-template-columns: 1fr;
            }

            .footer-section {
                text-align: center;
            }

            .footer-section h3::after {
                left: 50%;
                transform: translateX(-50%);
            }

            .social-links {
                justify-content: center;
            }

            .working-hours p {
                flex-direction: column;
                align-items: center;
                gap: 0.5rem;
            }
        }


        .contact-icon {
            @apply text-amber-500;
        }

        .contact-input {
            @apply shadow-sm focus:ring-amber-500 focus:border-amber-500 block w-full sm:text-sm border-gray-300 rounded-md;
        }

        .contact-card {
            @apply shadow-lg rounded-2xl p-8 bg-white;
        }

        #mobileMenu {
            background: #E63946;
        }

        .add-to-cart-btn {
            background-color: #ff9f43;
            /* Örnek renk */
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            transition: background-color 0.3s ease;
        }

        .add-to-cart-btn:hover {
            background-color: #ff7b00;
            /* Hover rengi */
        }

        /* "Online Sipariş Ver" Butonu İyileştirmeleri Örneği */
        .navbar-menu .online-siparis-ver {
            background-color: #e74c3c;
            /* Daha canlı kırmızı renk */
            color: white;
            padding: 12px 25px;
            /* Dolgu artırıldı */
            border-radius: 8px;
            /* Köşe yuvarlaklığı */
            font-weight: bold;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
            /* Gölge efekti */
            transition: background-color 0.3s ease, transform 0.2s ease;
            /* Hover geçiş efektleri */
        }

        .navbar-menu .online-siparis-ver:hover {
            background-color: #c0392b;
            /* Hoverda daha koyu kırmızı */
            transform: scale(1.05);
            /* Hoverda hafif büyüme */
            color: white;
            /* Hoverda metin rengi beyaz kalsın */
        }

        /* Sepet İkonu Değişikliği Örneği - Farklı bir Remix Icon sepet ikonu */
        .navbar-menu .sepet i {
            /* margin-right: 5px; - Zaten tanımlı, değiştirmeye gerek yok */
            /* font-size: 1.2em; - Zaten tanımlı, değiştirmeye gerek yok */
            content: "\ea58";
            /* Farklı Remix Icon kodu (örnek olarak) - Remix Icon sitesinden farklı bir kod seçebilirsiniz */
        }

        /* VEYA - Sepet ikonunu tamamen değiştirmek için (Remix Icon yerine başka bir ikon kütüphanesi veya SVG kullanabilirsiniz) */
        /* Örneğin Font Awesome'dan bir ikon kullanmak isterseniz: */
        /* <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="...">  head bölümüne ekleyin */
        /* Sonra CSS'te: */
        .navbar-menu .sepet i {
            display: none;
            /* Remix Icon'u gizle */
        }

        .navbar-menu .sepet::before {
            content: "\f07a";
            /* Font Awesome sepet ikon kodu örneği */
            font-family: 'Font Awesome 6 Free';
            /* Font Awesome font ailesini belirtin */
            font-weight: 900;
            /* Font ağırlığı (Font Awesome'a göre değişebilir) */
            margin-right: 5px;
            font-size: 1.2em;
            color: #555;
            /* İkon rengi */
        }

        .load-more-container {
            text-align: center;
            margin-top: 20px;
        }

        .load-more-btn {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            background-color: #C0392B;
            color: white;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .load-more-btn:hover {
            background-color: #ad3426;
        }
        .brand-logo {
    width: 180px; /* Genişlik */
    height: auto; /* Yükseklik oranı korunur */
}

    </style>
    @yield('css')
</head>

<body class="font-sans">
    <nav class="bg-white shadow-md sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16 items-center"> {{-- items-center eklendi --}}
                <div class="flex">
                    <div class="flex-shrink-0 flex items-center">
                        <a href="{{ url('/') }}" class="block">
                            <img src="{{ asset('front/img/logo.png') }}" alt="Onat Pide" class="h-16 w-auto">
                        </a>
                    </div>
                </div>

                {{-- Menü bölümü ortaya alındı ve ml-6 kaldırıldı --}}
                <div class="hidden md:flex space-x-4 items-center">
                    <div class="relative menu-dropdown">
                        <button class="flex items-center space-x-1 text-gray-700 hover:text-orange-500 focus:outline-none">
                            <i class="ri-menu-line align-middle"></i>
                            <span class="font-medium">Menü</span>
                            <i class="ri-arrow-down-s-line align-middle"></i>
                        </button>
                        <ul class="dropdown-menu absolute left-0 mt-2 w-48 bg-white rounded-md shadow-lg py-2 z-10 hidden">
                            {{-- @foreach($menuCategories as $category)
                                <li>
                                    <a href="#" class="block px-4 py-2 text-gray-800 hover:bg-gray-100 flex items-center space-x-2">
                                        <img src="{{asset($category->image_path)}}" alt="{{ $category->name }}" class="h-6 w-6 rounded-full object-cover">
                                        <span>{{ $category->name }}</span>
                                    </a>
                                </li>
                            @endforeach --}}
                        </ul>
                    </div>
                    <a href="#" class="text-gray-700 hover:text-orange-500 font-medium online-siparis-ver">Online Sipariş Ver</a>
                    <a href="#" class="text-gray-700 hover:text-orange-500 font-medium siparislerim"><i class="ri-file-list-line align-middle"></i> Siparişlerim</a>
                    <div class="relative cart-dropdown">
                        <button id="cart-button" class="flex items-center space-x-1 text-gray-700 hover:text-orange-500 focus:outline-none">
                            <i class="ri-shopping-cart-2-line text-xl"></i>
                            <span class="font-medium">Sepet</span>
                            <span id="cart-count" class="bg-orange-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">0</span>
                        </button>
                        <div id="cart-menu" class="absolute right-0 mt-2 w-80 bg-white rounded-md shadow-lg py-2 z-50 hidden">
                            <div id="cart-items" class="max-h-96 overflow-y-auto px-4">
                                </div>
                            <div class="border-t border-gray-200 mt-2 pt-2 px-4">
                                <div class="flex justify-between font-semibold">
                                    <span>Toplam:</span>
                                    <span id="cart-total">₺0.00</span>
                                </div>
                                <div class="mt-4">
                                    <a href="/checkout" class="block w-full bg-orange-500 text-white text-center py-2 rounded-md hover:bg-orange-600 transition">
                                        Checkout
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {{-- Kullanıcı Giriş/Kayıt bölümü (sağda) --}}
                <div class="hidden md:flex items-center space-x-4">
                    @guest
                        <a href="{{ route('register') }}" class="text-gray-700 hover:text-orange-500 font-medium">Kayıt Ol</a>
                        <a href="{{ route('login') }}" class="bg-orange-500 hover:bg-orange-600 text-white font-medium py-2 px-4 rounded-md transition">Giriş Yap</a>
                    @else
                        <div class="relative account-dropdown">
                            <button class="flex items-center space-x-2 text-gray-700 hover:text-orange-500 focus:outline-none">
                                <i class="ri-user-line align-middle"></i>
                                <span class="font-medium">{{ Auth::user()->name }}</span> <i class="ri-arrow-down-s-line align-middle"></i>
                            </button>
                            <ul class="dropdown-menu absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-2 z-10 hidden">
                                <li>
                                    <a href="{{ route('hesabim') }}" class="block px-4 py-2 text-gray-800 hover:bg-gray-100 flex items-center space-x-2">
                                        <i class="ri-user-settings-line align-middle"></i>
                                        <span>Hesabım</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="{{ route('logout') }}" class="block px-4 py-2 text-gray-800 hover:bg-gray-100 flex items-center space-x-2"
                                       onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                        <i class="ri-logout-box-line align-middle"></i>
                                        <span>Çıkış Yap</span>
                                    </a>
                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" class="hidden">
                                        @csrf
                                    </form>
                                </li>
                            </ul>
                        </div>
                    @endguest
                </div>
            </div>
        </div>

        <div class="md:hidden mobile-menu hidden" id="mobile-menu">
            <div class="px-2 pt-2 pb-3 space-y-1 sm:px-3">
                <a href="#" class="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:bg-gray-50 hover:text-gray-900 online-siparis-ver">Online Sipariş Ver</a>
                <a href="#" class="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:bg-gray-50 hover:text-gray-900 sepet"><i class="ri-shopping-cart-2-line align-middle"></i></a>
                <a href="#" class="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:bg-gray-50 hover:text-gray-900 siparislerim"><i class="ri-file-list-line align-middle"></i> Siparişlerim</a>
                <div class="relative mobile-menu-item menu-dropdown">
                    <button class="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:bg-gray-50 hover:text-gray-900 w-full text-left flex items-center justify-between">
                        <span><i class="ri-menu-line align-middle"></i> Menü</span>
                        <i class="ri-arrow-down-s-line align-middle"></i>
                    </button>
                    <ul class="dropdown-menu absolute left-0 mt-2 w-full bg-white rounded-md shadow-lg py-2 z-10 hidden">
                        {{-- @foreach($menuCategories as $category)
                            <li>
                                <a href="#" class="block px-4 py-2 text-gray-800 hover:bg-gray-100 flex items-center space-x-2">
                                    <img src="{{asset($category->image_path)}}" alt="{{ $category->name }}" class="h-6 w-6 rounded-full object-cover">
                                    <span>{{ $category->name }}</span>
                                </a>
                            </li>
                        @endforeach --}}
                    </ul>
                </div>
                @guest
                    <a href="{{ route('register') }}" class="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:bg-gray-50 hover:text-gray-900">Kayıt Ol</a>
                    <a href="{{ route('login') }}" class="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:bg-gray-50 hover:text-gray-900">Giriş Yap</a>
                @else
                    <div class="relative mobile-menu-item account-dropdown">
                        <button class="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:bg-gray-50 hover:text-gray-900 w-full text-left flex items-center justify-between">
                            <span><i class="ri-user-line align-middle"></i> Hesabım</span>
                            <i class="ri-arrow-down-s-line align-middle"></i>
                        </button>
                        <ul class="dropdown-menu absolute left-0 mt-2 w-full bg-white rounded-md shadow-lg py-2 z-10 hidden">
                            <li>
                                <a href="{{ route('hesabim') }}" class="block px-4 py-2 text-gray-800 hover:bg-gray-100 flex items-center space-x-2">
                                    <i class="ri-user-settings-line align-middle"></i>
                                    Hesabım
                                </a>
                            </li>
                            <li>
                                <a href="{{ route('logout') }}" class="block px-4 py-2 text-gray-800 hover:bg-gray-100 flex items-center space-x-2"
                                   onclick="event.preventDefault(); document.getElementById('logout-form-mobile').submit();">
                                    <i class="ri-logout-box-line align-middle"></i>
                                    Çıkış Yap
                                </a>
                                <form id="logout-form-mobile" action="{{ route('logout') }}" method="POST" class="hidden">
                                    @csrf
                                </form>
                            </li>
                        </ul>
                    </div>
                @endguest
            </div>
        </div>
    </nav>


