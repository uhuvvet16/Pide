@if (session('basarili'))
<div id="success-alert" class="fixed top-4 right-4 bg-green-500 text-white px-6 py-4 rounded-lg shadow-lg flex items-center transition-all duration-500 ease-in-out transform translate-x-full opacity-0">
    <i class="uil uil-check-circle text-2xl mr-2"></i>
    <span id="success-message">{{ session('basarili') }}</span>
</div>
@endif
