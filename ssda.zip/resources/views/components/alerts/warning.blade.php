@if (session('uyari'))
<div id="warning-alert" class="fixed top-4 right-4 bg-yellow-500 text-white px-6 py-4 rounded-lg shadow-lg flex items-center transition-all duration-500 transform translate-x-full opacity-0">
    <i class="uil uil-exclamation-circle text-2xl mr-2"></i>
    <span>{{ session('uyari') }}</span>
</div>
@endif
