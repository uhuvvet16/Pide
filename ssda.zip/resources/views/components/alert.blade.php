@props(['message'])

<div id="customAlert" class="custom-alert">
    <i class="uil uil-exclamation-triangle"></i>
    <div class="custom-alert-content">
        <strong>Hata!</strong>
        <p>{{ $message }}</p>
    </div>
    <button class="custom-alert-close" onclick="closeAlert()">&times;</button>
</div>
