<div class="sidebar-container">
    <div class="sidebar closed" id="sidebar">
        <div class="sidebar-content">
            <nav>
                <a href="{{ route('sales.index') }}"
                    class="nav-item {{ $activeRoute === 'sales.index' ? 'active' : '' }}">
                    <i class="ri-file-list-3-line"></i>
                    <span>Siparişler</span>
                </a>

                <a href="{{ route('mocan.genel') }}"
                    class="nav-item {{ $activeRoute === 'mocan.genel' ? 'active' : '' }}">
                    <i class="ri-shopping-cart-line"></i>
                    <span>Hızlı Satış</span>
                </a>

                <a href="{{ route('stock.management') }}"
                    class="nav-item {{ $activeRoute === 'stock.management' ? 'active' : '' }}">
                    <i class="ri-database-2-line"></i>
                    <span>Stok Yönetimi</span>
                </a>

                <a href="{{ route('barcode.list.mocan') }}"
                    class="nav-item {{ $activeRoute === 'barcode.list.mocan' ? 'active' : '' }}">
                    <i class="ri-barcode-line"></i>
                    <span>Barkod Yönetimi</span>
                </a>
            </nav>
        </div>

    </div>
    <div class="sidebar-toggle" onclick="toggleSidebar()">
        <i class="ri-arrow-left-line" id="toggleIcon"></i>
    </div>
    <div class="active-icon" id="activeIcon" style="display: none;"></div>
</div>
