@extends('back.layouts.master')

@section('title', 'Kategori Yönetimi')
@section('title_header', 'Kategori Yönetimi')

@section('section')
    <div class="mb-4">
        <a href="{{ route('categories.create') }}" class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
            <i class="ri-add-line align-middle"></i> Yeni Kategori Ekle
        </a>
    </div>

    @if(session('success'))
        <div class="bg-green-200 p-3 rounded mb-4">
            {{ session('success') }}
        </div>
    @endif

    <div class="overflow-x-auto">
        <table id="categoriesTable" class="min-w-full bg-white border border-gray-300">
            <thead class="bg-gray-100">
                <tr>
                    <th class="px-4 py-2 border-b">#</th>
                    <th class="px-4 py-2 border-b">Adı</th>
                    <th class="px-4 py-2 border-b">Slug</th>
                    <th class="px-4 py-2 border-b">Açıklama</th>
                    <th class="px-4 py-2 border-b">Oluşturulma Tarihi</th>
                    <th class="px-4 py-2 border-b">İşlemler</th>
                </tr>
            </thead>
            <tbody>
                @foreach($categories as $category)
                    <tr>
                        <td class="px-4 py-2 border-b">{{ $category->id }}</td>
                        <td class="px-4 py-2 border-b">{{ $category->name }}</td>
                        <td class="px-4 py-2 border-b">{{ $category->slug }}</td>
                        <td class="px-4 py-2 border-b">{{ $category->description }}</td>
                        <td class="px-4 py-2 border-b">{{ $category->created_at->format('d-m-Y H:i') }}</td>
                        <td class="px-4 py-2 border-b">
                            <a href="{{ route('categories.edit', $category) }}" class="text-blue-500 hover:text-blue-700"><i class="ri-edit-line align-middle"></i> Düzenle</a>
                            <form action="{{ route('categories.destroy', $category) }}" method="POST" class="inline-block" onsubmit="return confirm('Kategoriyi silmek istediğinize emin misiniz?')">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="text-red-500 hover:text-red-700 ml-2"><i class="ri-delete-bin-line align-middle"></i> Sil</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection

@section('scripts')
    <script>
        $(document).ready( function () {
            $('#categoriesTable').DataTable({
                language: {
                    url: '//cdn.datatables.net/plug-ins/1.13.6/i18n/tr.json', // Türkçe dil dosyası
                }
            });
        } );
    </script>
@endsection
