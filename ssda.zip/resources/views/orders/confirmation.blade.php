@extends('front.master')
@section('section')
<div class="container mx-auto py-8">
    <div class="max-w-2xl mx-auto bg-white rounded-lg shadow-md p-8">
        <div class="text-center mb-8">
            <div class="inline-block bg-green-100 p-4 rounded-full mb-4">
                <i class="ri-check-line text-4xl text-green-500"></i>
            </div>

            <h1 class="text-2xl font-bold text-gray-800">Order Confirmed!</h1>
            <p class="text-gray-600 mt-2">Your order has been placed successfully.</p>
        </div>

        <div class="border-t border-b border-gray-200 py-4 mb-6">
            <div class="flex justify-between mb-2">
                <span class="font-medium">Order Code:</span>
                <span class="font-bold">{{ $order->order_code }}</span>
            </div>

            <div class="flex justify-between mb-2">
                <span class="font-medium">Order Date:</span>
                <span>{{ $order->created_at->format('M d, Y h:i A') }}</span>
            </div>

            <div class="flex justify-between mb-2">
                <span class="font-medium">Payment Method:</span>
                <span>Cash on Delivery</span>
            </div>

            <div class="flex justify-between">
                <span class="font-medium">Order Status:</span>
                <span class="bg-orange-100 text-orange-800 px-2 py-1 rounded text-xs">{{ ucfirst($order->status) }}</span>
            </div>
        </div>

        <div class="mb-6">
            <h2 class="text-lg font-semibold mb-3">Order Summary</h2>

            @foreach($order->items as $item)
            <div class="flex justify-between py-2 border-b border-gray-100 last:border-0">
                <div>
                    <div>{{ $item->quantity }}x {{ $item->name }}</div>
                    @if($item->special_instructions)
                    <div class="text-sm text-gray-500 italic">
                        "{{ $item->special_instructions }}"
                    </div>
                    @endif
                </div>
                <div class="font-medium">₺{{ number_format($item->subtotal, 2) }}</div>
            </div>
            @endforeach

            <div class="mt-4 pt-4 border-t border-gray-200">
                <div class="flex justify-between mb-2">
                    <span>Subtotal</span>
                    <span>₺{{ number_format($order->subtotal, 2) }}</span>
                </div>
                <div class="flex justify-between mb-2">
                    <span>Delivery Fee</span>
                    <span>₺{{ number_format($order->delivery_fee, 2) }}</span>
                </div>
                <div class="flex justify-between font-bold text-lg">
                    <span>Total</span>
                    <span>₺{{ number_format($order->total, 2) }}</span>
                </div>
            </div>
        </div>

        <div class="mb-6">
            <h2 class="text-lg font-semibold mb-3">Delivery Information</h2>

            <div class="bg-gray-50 p-4 rounded">
                <div class="mb-2">
                    <span class="font-medium">Delivery Address:</span>
                    <div class="mt-1">
                        {{ $order->address->address_line }}<br>
                        {{ $order->address->city }}, {{ $order->address->postal_code }}
                    </div>
                </div>

                <div>
                    <span class="font-medium">Contact:</span>
                    <div class="mt-1">
                        {{ $order->address->contact_name }}<br>
                        {{ $order->address->contact_phone }}
                    </div>
                </div>
            </div>
        </div>

        <div class="text-center">
            <p class="text-gray-600 mb-4">You can track your order status using your order code.</p>

            <a href="{{ route('orders.show', ['order_code' => $order->order_code]) }}" class="inline-block bg-orange-500 text-white px-6 py-2 rounded-lg font-medium hover:bg-orange-600 transition">
                Track Order
            </a>
        </div>
    </div>
</div>
@endsection
