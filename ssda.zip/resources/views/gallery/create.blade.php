@extends('back.layouts.master')

@section('section')
    <div class="container">
        <h1><i class="ri-add-circle-fill"></i> Yeni Galeri Öğesi Ekle</h1>

        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form action="{{ route('gallery.store') }}" method="POST" enctype="multipart/form-data">
            @csrf

            <div class="form-group">
                <label for="type"><i class="ri-slideshow-3-fill"></i> Tür</label>
                <select class="form-control" id="type" name="type">
                    <option value="image">Resim</option>
                    <option value="video">Video</option>
                </select>
            </div>

            <div class="form-group" id="image-upload-section">
                <label for="files"><i class="ri-image-add-fill"></i> Resim(ler) Yükle (Toplu Seçim Yapabilirsiniz)</label>
                <input type="file" class="form-control-file" id="files" name="files[]" multiple>
            </div>

            <div class="form-group" id="video-url-section" style="display: none;">
                <label for="video_path"><i class="ri-video-add-fill"></i> Video URL</label>
                <input type="url" class="form-control" id="video_path" name="video_path">
            </div>

            <button type="submit" class="btn btn-primary"><i class="ri-save-fill"></i> Kaydet</button>
            <a href="{{ route('gallery.index') }}" class="btn btn-secondary"><i class="ri-arrow-left-s-line"></i> İptal</a>
        </form>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const typeSelect = document.getElementById('type');
            const imageUploadSection = document.getElementById('image-upload-section');
            const videoUrlSection = document.getElementById('video-url-section');

            typeSelect.addEventListener('change', function() {
                if (typeSelect.value === 'image') {
                    imageUploadSection.style.display = 'block';
                    videoUrlSection.style.display = 'none';
                } else if (typeSelect.value === 'video') {
                    imageUploadSection.style.display = 'none';
                    videoUrlSection.style.display = 'block';
                }
            });
        });
    </script>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
@endsection
