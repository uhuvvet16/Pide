@extends('back.layouts.master')

@section('section')
    <div class="container">
        <h1><i class="ri-image-fill"></i> Galeri Yönetimi</h1>

        @if(session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
        @endif

        <a href="{{ route('gallery.create') }}" class="btn btn-primary mb-3"><i class="ri-add-circle-fill"></i> Yeni Galeri Öğesi Ekle</a>

        <ul id="gallery-list" class="list-group">
            @foreach($galleries as $gallery)
                <li class="list-group-item d-flex justify-content-between align-items-center handle" data-id="{{ $gallery->id }}">
                    <i class="ri-drag-move-2-fill align-middle mr-2" style="cursor: move;"></i>
                    @if($gallery->type == 'image')
                        <img src="{{ asset($gallery->path) }}" alt="Galeri Resmi" style="max-height: 50px;">
                    @elseif($gallery->type == 'video')
                        <i class="ri-movie-2-fill ri-2x align-middle"></i>
                        <span class="ml-2">Video Öğesi</span>
                    @endif
                    <span class="ml-2">{{ basename($gallery->path) }} (Sıra: {{ $gallery->order }}) - Tür: {{ $gallery->type }}</span>
                    <div>
                        <form action="{{ route('gallery.destroy', $gallery->id) }}" method="POST" class="d-inline">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Emin misiniz?')"><i class="ri-delete-bin-fill"></i> Sil</button>
                        </form>
                    </div>
                </li>
            @endforeach
        </ul>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const galleryList = document.getElementById('gallery-list');
            if (galleryList) {
                Sortable.create(galleryList, {
                    handle: '.handle', // Sürükleme alanı için handle class'ı
                    animation: 150,
                    onEnd: function (evt) {
                        const newOrder = Array.from(galleryList.children).map(item => item.dataset.id);
                        fetch('{{ route('gallery.sort') }}', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-CSRF-TOKEN': '{{ csrf_token() }}'
                            },
                            body: JSON.stringify({ order: newOrder })
                        }).then(response => response.json())
                          .then(data => {
                              if (data.success) {
                                  console.log('Sıralama Güncellendi');
                              }
                          });
                    }
                });
            }
        });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/sortablejs@latest/Sortable.min.js"></script>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
@endsection
