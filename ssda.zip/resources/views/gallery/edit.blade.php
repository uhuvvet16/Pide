@extends('back.layouts.master')

@section('section')
    <div class="container">
        <h1>Galeri Öğesini Düzenle</h1>

        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form action="{{ route('gallery.update', $gallery->id) }}" method="POST">
            @csrf
            @method('PUT')

            <div class="form-group">
                <label for="order">Sıra</label>
                <input type="number" class="form-control" id="order" name="order" value="{{ $gallery->order }}">
            </div>

            <button type="submit" class="btn btn-primary">Güncelle</button>
            <a href="{{ route('gallery.index') }}" class="btn btn-secondary">İptal</a>
        </form>
    </div>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
@endsection
