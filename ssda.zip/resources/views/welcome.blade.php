@extends('front.master') {{-- Layout dosyanızı kullanın --}}

@section('title', 'Menümüz')
@section('title_header', 'Menümüz') {{-- İsteğe bağlı başlık --}}

@section('section')
    {{-- <button id="themeToggle" class="theme-toggle" aria-label="Tema değiştir">
        <!-- Güneş ikonu (açık tema) -->
        <i class="ri-sun-line text-2xl hidden dark:inline"></i>
        <!-- Ay ikonu (koyu tema) -->
        <i class="ri-moon-line text-2xl dark:hidden"></i>
    </button> --}}

    <!-- Navigation -->
    {{-- <nav id="navbar" class="fixed w-full z-50 transition-all duration-300">
        <div class="container mx-auto px-4">
            <div class="flex justify-between items-center h-16">
                <a href="#" class="text-2xl font-bold text-amber-600">Onat Pide</a>

                <!-- Mobile Menu Button -->
                <button class="lg:hidden text-white" onclick="toggleMenu()">
                    <i class="ri-menu-line text-2xl"></i>
                </button>

                <!-- Desktop Menu -->
                <div class="hidden lg:flex space-x-8">
                    <a href="#menu" class="text-white hover:text-amber-400 transition">Menü</a>
                    <a href="#about" class="text-white hover:text-amber-400 transition">Hakkımızda</a>
                    <a href="#gallery" class="text-white hover:text-amber-400 transition">Galeri</a>
                    <a href="#contact" class="text-white hover:text-amber-400 transition">İletişim</a>
                </div>
            </div>
        </div>

        <!-- Mobile Menu -->
        <div id="mobileMenu" class="fixed top-0 right-0 h-full w-64 backdrop-blur-md shadow-lg lg:hidden">
            <div class="p-4">
                <button onclick="toggleMenu()" class="mb-4 text-gray-600">
                    <i class="ri-close-line text-2xl"></i>
                </button>
                <div class="flex flex-col space-y-4">
                    <a href="#menu" class="text-gray-600 hover:text-amber-600">Menü</a>
                    <a href="#about" class="text-gray-600 hover:text-amber-600">Hakkımızda</a>
                    <a href="#gallery" class="text-gray-600 hover:text-amber-600">Galeri</a>
                    <a href="#contact" class="text-gray-600 hover:text-amber-600">İletişim</a>
                </div>
            </div>
        </div>
    </nav> --}}



    <section class="h-screen">
        <div class="swiper mainSwiper">
            <div class="swiper-wrapper">
                @foreach ($sliders as $slider)
                    <div class="swiper-slide relative" style="background-image: url('{{ asset($slider->image) }}')">
                        <div class="overlay"></div>
                        <div class="absolute inset-0 flex items-center justify-center text-center text-white z-10">
                            <div data-aos="fade-up">
                                {{-- <h1 class="text-4xl md:text-6xl font-bold mb-4">{{ $slider->title }}</h1> --}}
                                <p class="text-xl mb-8">{{ $slider->description }}</p>
                                @if ($slider->button_text && $slider->button_url)
                                    <a href="{{ $slider->button_url }}"
                                        class="bg-amber-600 text-white px-8 py-3 rounded-full hover:bg-amber-700 transition">
                                        {{ $slider->button_text }}
                                    </a>
                                @endif
                            </div>
                        </div>
                    </div>
                @endforeach

            </div>
            <div class="swiper-pagination"></div>
            <div class="swiper-button-next text-white"></div>
            <div class="swiper-button-prev text-white"></div>
        </div>
    </section>

    <!-- About Section -->
    <section id="about" class="py-20">
        <div class="container mx-auto px-4">
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                <div data-aos="fade-right">
                    <img src="{{ asset('front/img/Restoran.jpg') }}" alt="Taş Fırın" class="rounded-lg shadow-lg">
                </div>
                <div data-aos="fade-left">
                    <h2 class="text-3xl font-bold mb-6">Hikayemiz</h2>
                    <p class="text-gray-600 mb-6">Onat Pide, 01.01.2015'te İzmir Şirinyer'de kurulmuştur. Ancak sektör
                        tecrübemiz 1997'ye dayanmaktadır. 8. işletmemiz olan Onat Pide, kaliteli malzeme ve güvenilir
                        hizmet anlayışıyla faaliyet göstermektedir. Hedefimiz, markamızı büyüterek restoran zinciri
                        haline getirmektir. 20 Ekim 2024 itibarıyla Bursa Osmangazi Güneştepe’de hizmet vermeye devam
                        ediyoruz.</p>
                    <div class="grid grid-cols-2 gap-6">
                        <div>
                            <i class="ri-fire-line text-3xl text-amber-600"></i>
                            <h3 class="text-xl font-semibold my-2">Taş Fırın</h3>
                            <p class="text-gray-600">Özel yapım taş fırınımızda pişen eşsiz lezzetler</p>
                        </div>
                        <div>
                            <i class="ri-leaf-line text-3xl text-amber-600"></i>
                            <h3 class="text-xl font-semibold my-2">Taze Malzemeler</h3>
                            <p class="text-gray-600">Günlük tedarik edilen en kaliteli malzemeler</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    {{-- <section id="order" class="py-20 bg-gray-50">
        <div class="container mx-auto px-4">
            <h2 class="text-3xl font-bold text-center mb-12" data-aos="fade-up">Online Sipariş</h2>
            <div class="max-w-2xl mx-auto">
                <form class="space-y-6" id="orderForm">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-gray-700 mb-2">Ad Soyad *</label>
                            <input type="text" required
                                class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-amber-600">
                        </div>
                        <div>
                            <label class="block text-gray-700 mb-2">Telefon *</label>
                            <input type="tel" required
                                class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-amber-600">
                        </div>
                    </div>
                    <div>
                        <label class="block text-gray-700 mb-2">Adres *</label>
                        <textarea required class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-amber-600"
                            rows="3"></textarea>
                    </div>
                    <div class="border rounded-lg p-4">
                        <h3 class="font-semibold mb-4">Siparişiniz</h3>
                        <div class="space-y-4" id="orderItems">
                            <!-- Sipariş öğeleri dinamik olarak eklenecek -->
                        </div>
                        <button type="button" onclick="addOrderItem()"
                            class="mt-4 text-amber-600 hover:text-amber-700">
                            <i class="ri-add-line"></i> Ürün Ekle
                        </button>
                    </div>
                    <div class="flex justify-between items-center">
                        <div class="flex items-center">
                            <input type="radio" name="payment" id="doorPayment" checked class="mr-2">
                            <label for="doorPayment">Kapıda Ödeme</label>
                        </div>
                        <div class="text-xl font-bold" id="totalPrice">
                            Toplam: ₺0
                        </div>
                    </div>
                    <button type="submit"
                        class="w-full bg-amber-600 text-white px-6 py-3 rounded-lg hover:bg-amber-700 transition">
                        Siparişi Tamamla
                    </button>
                </form>
            </div>
        </div>
    </section> --}}
    <!-- Rezervasyon - Sonradan Gel Ye Section -->
    {{-- <section id="eatLater" class="py-20 bg-gray-50">
        <div class="container mx-auto px-4">
            <h2 class="text-3xl font-bold text-center mb-12" data-aos="fade-up">Rezervasyon - Sonradan Gel Ye</h2>
            <div class="max-w-2xl mx-auto">
                <form class="space-y-6" id="eatLaterForm">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-gray-700 mb-2">Ad Soyad *</label>
                            <input type="text" required
                                class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-amber-600">
                        </div>
                        <div>
                            <label class="block text-gray-700 mb-2">Telefon *</label>
                            <input type="tel" required
                                class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-amber-600">
                        </div>
                    </div>
                    <div>
                        <label class="block text-gray-700 mb-2">Not (İsteğe Bağlı)</label>
                        <textarea required class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-amber-600"
                            rows="3"></textarea>
                    </div>
                    <div class="border rounded-lg p-4">
                        <h3 class="font-semibold mb-4">Siparişiniz</h3>
                        <div class="space-y-4" id="orderItems">
                            <!-- Sipariş öğeleri dinamik olarak eklenecek -->
                        </div>
                        <button type="button" onclick="addOrderItem()"
                            class="mt-4 text-amber-600 hover:text-amber-700">
                            <i class="ri-add-line"></i> Ürün Ekle
                        </button>
                    </div>
                    <div class="flex justify-between items-center">
                        <div class="flex items-center">
                            <input type="radio" name="payment" id="doorPayment" checked class="mr-2">
                            <label for="doorPayment">Kart İle Ödeme</label>
                        </div>
                        <div class="text-xl font-bold" id="totalPrice">
                            Toplam: ₺0
                        </div>
                    </div>
                    <button type="submit"
                        class="w-full bg-amber-600 text-white px-6 py-3 rounded-lg hover:bg-amber-700 transition">
                        Siparişi Tamamla
                    </button>
                </form>
            </div>
        </div>
    </section> --}}

    <!-- Rezervasyon Section -->
    {{-- <section id="reservation" class="py-20">
        <div class="container mx-auto px-4">
            <h2 class="text-3xl font-bold text-center mb-12" data-aos="fade-up">Rezervasyon</h2>
            <div class="max-w-2xl mx-auto">
                <form class="space-y-6">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-gray-700 mb-2">Ad Soyad *</label>
                            <input type="text" required
                                class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-amber-600">
                        </div>
                        <div>
                            <label class="block text-gray-700 mb-2">Telefon *</label>
                            <input type="tel" required
                                class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-amber-600">
                        </div>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-gray-700 mb-2">Tarih *</label>
                            <input type="date" required
                                class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-amber-600">
                        </div>
                        <div>
                            <label class="block text-gray-700 mb-2">Saat *</label>
                            <input type="time" required
                                class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-amber-600">
                        </div>
                    </div>
                    <div>
                        <label class="block text-gray-700 mb-2">Kişi Sayısı *</label>
                        <select required
                            class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-amber-600">
                            <option value="">Seçiniz</option>
                            <option value="1-2">1-2 Kişi</option>
                            <option value="3-4">3-4 Kişi</option>
                            <option value="5-6">5-6 Kişi</option>
                            <option value="7+">7+ Kişi</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-gray-700 mb-2">Not (Opsiyonel)</label>
                        <textarea class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-amber-600" rows="3"></textarea>
                    </div>
                    <button type="submit"
                        class="w-full bg-amber-600 text-white px-6 py-3 rounded-lg hover:bg-amber-700 transition">
                        Rezervasyon Yap
                    </button>
                </form>
            </div>
        </div>
    </section> --}}

    <!-- Müşteri Yorumları Section -->
    {{-- <section class="py-20 bg-gray-50">
        <div class="container mx-auto px-4">
            <h2 class="text-3xl font-bold text-center mb-12" data-aos="fade-up">Müşteri Yorumları</h2>
            <div class="swiper reviewSwiper">
                <div class="swiper-wrapper pb-8">
                    <!-- Yorum 1 -->
                    <div class="swiper-slide">
                        <div class="bg-white p-6 rounded-lg shadow-md">
                            <div class="flex items-center mb-4">
                                <img src="/api/placeholder/64/64" alt="Müşteri" class="w-12 h-12 rounded-full">
                                <div class="ml-4">
                                    <h3 class="font-semibold">Ahmet Yılmaz</h3>
                                    <div class="flex text-amber-500">
                                        <i class="ri-star-fill"></i>
                                        <i class="ri-star-fill"></i>
                                        <i class="ri-star-fill"></i>
                                        <i class="ri-star-fill"></i>
                                        <i class="ri-star-fill"></i>
                                    </div>
                                </div>
                            </div>
                            <p class="text-gray-600">"Harika lezzetler, özellikle kuşbaşılı pide favorim. Servis de çok
                                iyi, kesinlikle tavsiye ederim."</p>
                        </div>
                    </div>
                    <!-- Yorum 2 -->
                    <div class="swiper-slide">
                        <div class="bg-white p-6 rounded-lg shadow-md">
                            <div class="flex items-center mb-4">
                                <img src="/api/placeholder/64/64" alt="Müşteri" class="w-12 h-12 rounded-full">
                                <div class="ml-4">
                                    <h3 class="font-semibold">Ayşe Demir</h3>
                                    <div class="flex text-amber-500">
                                        <i class="ri-star-fill"></i>
                                        <i class="ri-star-fill"></i>
                                        <i class="ri-star-fill"></i>
                                        <i class="ri-star-fill"></i>
                                        <i class="ri-star-half-fill"></i>
                                    </div>
                                </div>
                            </div>
                            <p class="text-gray-600">"Pideler her zaman sıcak ve taze. Personel çok ilgili. Sürekli
                                müşterileri olduk artık."</p>
                        </div>
                    </div>
                    <!-- Yorum 3 -->
                    <div class="swiper-slide">
                        <div class="bg-white p-6 rounded-lg shadow-md">
                            <div class="flex items-center mb-4">
                                <img src="/api/placeholder/64/64" alt="Müşteri" class="w-12 h-12 rounded-full">
                                <div class="ml-4">
                                    <h3 class="font-semibold">Mehmet Kaya</h3>
                                    <div class="flex text-amber-500">
                                        <i class="ri-star-fill"></i>
                                        <i class="ri-star-fill"></i>
                                        <i class="ri-star-fill"></i>
                                        <i class="ri-star-fill"></i>
                                        <i class="ri-star-fill"></i>
                                    </div>
                                </div>
                            </div>
                            <p class="text-gray-600">"Online sipariş sistemi çok pratik. Kapıda ödeme seçeneği de büyük
                                kolaylık. Lezzet zaten tartışılmaz."</p>
                        </div>
                    </div>
                </div>
                <div class="swiper-pagination"></div>
            </div>
        </div>
    </section> --}}

    <!-- Menu Section -->
    {{-- <section id="menu" class="py-20 bg-gray-50">
        <div class="container mx-auto px-4">
            <h2 class="text-3xl font-bold text-center mb-12" data-aos="fade-up">Menümüz</h2>

            <!-- Menü Filtreleri -->
            <div class="flex flex-wrap justify-center gap-4 mb-8" data-aos="fade-up">
                <button
                    class="menu-filter-btn active px-6 py-2 rounded-full border border-amber-600 hover:bg-amber-600 hover:text-white transition"
                    data-filter="all">Tümü</button>
                <button
                    class="menu-filter-btn px-6 py-2 rounded-full border border-amber-600 hover:bg-amber-600 hover:text-white transition"
                    data-filter="pide">Pideler</button>
                <button
                    class="menu-filter-btn px-6 py-2 rounded-full border border-amber-600 hover:bg-amber-600 hover:text-white transition"
                    data-filter="lahmacun">Lahmacunlar</button>
                <button
                    class="menu-filter-btn px-6 py-2 rounded-full border border-amber-600 hover:bg-amber-600 hover:text-white transition"
                    data-filter="corba">Çorbalar</button>
                <button
                    class="menu-filter-btn px-6 py-2 rounded-full border border-amber-600 hover:bg-amber-600 hover:text-white transition"
                    data-filter="tatli">Tatlılar</button>
            </div>

            <!-- Menü Grid -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <!-- Menü Öğesi 1 -->
                <div class="menu-item bg-white rounded-lg shadow-md overflow-hidden" data-category="pide"
                    data-aos="fade-up">
                    <a href="https://images.unsplash.com/photo-1528699633788-424224dc89b5?q=80"
                        data-lightbox="menu-gallery" data-title="Kıymalı Pide">
                        <img src="https://images.unsplash.com/photo-1528699633788-424224dc89b5?q=80"
                            alt="Kıymalı Pide" class="w-full h-48 object-cover hover:scale-105 transition">
                    </a>
                    <div class="p-6">
                        <h3 class="text-xl font-semibold mb-2">Kıymalı Pide</h3>
                        <p class="text-gray-600 mb-4">Özel baharatlı kıyma, domates, biber ve maydanoz</p>
                        <div class="flex justify-between items-center">
                            <p class="text-amber-600 font-bold">₺75</p>
                            <button onclick="addToCart('kiymalı')"
                                class="bg-amber-600 text-white px-4 py-2 rounded hover:bg-amber-700 transition">
                                <i class="ri-shopping-cart-line mr-2"></i>Sepete Ekle
                            </button>
                        </div>
                    </div>
                </div>
                <div class="menu-item bg-white rounded-lg shadow-md overflow-hidden" data-category="pide"
                    data-aos="fade-up">
                    <a href="https://images.unsplash.com/photo-1528699633788-424224dc89b5?q=80"
                        data-lightbox="menu-gallery" data-title="Kıymalı Pide">
                        <img src="https://images.unsplash.com/photo-1528699633788-424224dc89b5?q=80"
                            alt="Kıymalı Pide" class="w-full h-48 object-cover hover:scale-105 transition">
                    </a>
                    <div class="p-6">
                        <h3 class="text-xl font-semibold mb-2">Kıymalı Pide</h3>
                        <p class="text-gray-600 mb-4">Özel baharatlı kıyma, domates, biber ve maydanoz</p>
                        <div class="flex justify-between items-center">
                            <p class="text-amber-600 font-bold">₺75</p>
                            <button onclick="addToCart('kiymalı')"
                                class="bg-amber-600 text-white px-4 py-2 rounded hover:bg-amber-700 transition">
                                <i class="ri-shopping-cart-line mr-2"></i>Sepete Ekle
                            </button>
                        </div>
                    </div>
                </div>
                <div class="menu-item bg-white rounded-lg shadow-md overflow-hidden" data-category="pide"
                    data-aos="fade-up">
                    <a href="https://images.unsplash.com/photo-1528699633788-424224dc89b5?q=80"
                        data-lightbox="menu-gallery" data-title="Kıymalı Pide">
                        <img src="https://images.unsplash.com/photo-1528699633788-424224dc89b5?q=80"
                            alt="Kıymalı Pide" class="w-full h-48 object-cover hover:scale-105 transition">
                    </a>
                    <div class="p-6">
                        <h3 class="text-xl font-semibold mb-2">Kıymalı Pide</h3>
                        <p class="text-gray-600 mb-4">Özel baharatlı kıyma, domates, biber ve maydanoz</p>
                        <div class="flex justify-between items-center">
                            <p class="text-amber-600 font-bold">₺75</p>
                            <button onclick="addToCart('kiymalı')"
                                class="bg-amber-600 text-white px-4 py-2 rounded hover:bg-amber-700 transition">
                                <i class="ri-shopping-cart-line mr-2"></i>Sepete Ekle
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section> --}}

    <!-- Kampanyalar Section -->
    {{-- <section class="py-20">
        <div class="container mx-auto px-4">
            <h2 class="text-3xl font-bold text-center mb-12" data-aos="fade-up">Özel Kampanyalar</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <!-- Kampanya 1 -->
                <div class="bg-white rounded-lg shadow-md overflow-hidden" data-aos="fade-up">
                    <img src="https://images.unsplash.com/photo-1513104890138-7c749659a591?q=80" alt="2 Al 1 Öde"
                        class="w-full h-48 object-cover">
                    <div class="p-6">
                        <h3 class="text-xl font-semibold mb-2">2 Al 1 Öde Kampanyası</h3>
                        <p class="text-gray-600 mb-4">Seçili pidelerde geçerlidir</p>
                        <div class="campaign-timer p-3 rounded-lg text-center mb-4">
                            <p class="text-sm text-gray-600 mb-2">Kampanya Bitimine:</p>
                            <div class="text-xl font-bold text-amber-600" id="campaign1Timer">23:59:59</div>
                        </div>
                        <button class="w-full bg-amber-600 text-white px-4 py-2 rounded hover:bg-amber-700 transition">
                            Kampanyayı Kullan
                        </button>
                    </div>
                </div>
                <!-- Diğer kampanyalar benzer şekilde -->
            </div>
        </div>
    </section> --}}

    <!-- Sipariş Takip Section -->
    {{-- <section class="py-20 bg-gray-50">
        <div class="container mx-auto px-4">
            <h2 class="text-3xl font-bold text-center mb-12" data-aos="fade-up">Sipariş Takip</h2>
            <div class="max-w-2xl mx-auto">
                <div class="bg-white rounded-lg shadow-md p-6">
                    <div class="mb-6">
                        <label class="block text-gray-700 mb-2">Sipariş Numarası</label>
                        <div class="flex gap-4">
                            <input type="text" id="orderTrackingNumber"
                                class="flex-1 px-4 py-2 border rounded-lg focus:outline-none focus:border-amber-600"
                                placeholder="Örn: #123456">
                            <button onclick="trackOrder()"
                                class="bg-amber-600 text-white px-6 py-2 rounded-lg hover:bg-amber-700 transition">
                                Takip Et
                            </button>
                        </div>
                    </div>
                    <div id="orderStatus" class="hidden">
                        <div class="flex justify-between items-center relative mb-8">
                            <div class="absolute left-0 right-0 top-1/2 h-0.5 bg-gray-200 -z-10"></div>
                            <div class="order-status-step completed relative flex flex-col items-center">
                                <div
                                    class="w-8 h-8 rounded-full bg-white border-2 border-gray-200 flex items-center justify-center mb-2">
                                    <i class="ri-check-line"></i>
                                </div>
                                <span class="text-sm">Sipariş Alındı</span>
                            </div>
                            <div class="order-status-step relative flex flex-col items-center">
                                <div
                                    class="w-8 h-8 rounded-full bg-white border-2 border-gray-200 flex items-center justify-center mb-2">
                                    <i class="ri-time-line"></i>
                                </div>
                                <span class="text-sm">Hazırlanıyor</span>
                            </div>
                            <div class="order-status-step relative flex flex-col items-center">
                                <div
                                    class="w-8 h-8 rounded-full bg-white border-2 border-gray-200 flex items-center justify-center mb-2">
                                    <i class="ri-bike-line"></i>
                                </div>
                                <span class="text-sm">Yolda</span>
                            </div>
                            <div class="order-status-step relative flex flex-col items-center">
                                <div
                                    class="w-8 h-8 rounded-full bg-white border-2 border-gray-200 flex items-center justify-center mb-2">
                                    <i class="ri-home-smile-line"></i>
                                </div>
                                <span class="text-sm">Teslim Edildi</span>
                            </div>
                        </div>
                        <div class="text-center text-gray-600">
                            Tahmini Teslimat: <span class="font-semibold" id="estimatedDelivery">20-25 dakika</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section> --}}


    <!-- Sosyal Medya Feed Section -->
    {{-- <section class="py-20">
        <div class="container mx-auto px-4">
            <h2 class="text-3xl font-bold text-center mb-12" data-aos="fade-up">Sosyal Medya'da Biz</h2>
            <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                <!-- Instagram Post 1 -->
                <div class="social-feed-item relative overflow-hidden rounded-lg transition duration-300"
                    data-aos="zoom-in">
                    <img src="https://images.unsplash.com/photo-1590947132387-155cc02f3212?q=80" alt="Instagram Post"
                        class="w-full h-64 object-cover">
                    <div
                        class="absolute inset-0 bg-black bg-opacity-50 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center">
                        <div class="text-white text-center">
                            <div class="flex items-center space-x-4">
                                <span><i class="ri-heart-line"></i> 234</span>
                                <span><i class="ri-chat-1-line"></i> 18</span>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Diğer sosyal medya postları benzer şekilde -->
            </div>
            <div class="text-center mt-8">
                <a href="#" class="inline-flex items-center text-amber-600 hover:text-amber-700 transition">
                    <span class="mr-2">Daha fazlası için Instagram'da takip edin</span>
                    <i class="ri-instagram-line"></i>
                </a>
            </div>
        </div>
    </section> --}}


    <!-- Gallery Section -->
    {{-- <section id="gallery" class="py-20 bg-gray-50">
        <div class="container mx-auto px-4">
            <h2 class="text-3xl font-bold text-center mb-12" data-aos="fade-up">Galeri</h2>
            <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                <img src="https://images.unsplash.com/photo-1590947132387-155cc02f3212?q=80" alt="Galeri 1"
                    class="w-full h-48 object-cover rounded-lg" data-aos="zoom-in">
                <img src="https://images.unsplash.com/photo-1615719413546-198b25453f85?q=80" alt="Galeri 2"
                    class="w-full h-48 object-cover rounded-lg" data-aos="zoom-in" data-aos-delay="100">
                <img src="https://images.unsplash.com/photo-1573821663912-569905455b1c?q=80" alt="Galeri 3"
                    class="w-full h-48 object-cover rounded-lg" data-aos="zoom-in" data-aos-delay="200">
                <img src="https://images.unsplash.com/photo-1590947132387-155cc02f3212?q=80" alt="Galeri 4"
                    class="w-full h-48 object-cover rounded-lg" data-aos="zoom-in" data-aos-delay="300">
            </div>
        </div>
    </section> --}}
    {{-- <div
        class="relative flex items-top justify-center min-h-screen bg-gray-100 dark:bg-gray-900 sm:items-center py-4 sm:pt-0">

        <section id="gallery" class="py-20 bg-gray-50">
            <div class="container mx-auto px-4">
                <h2 class="text-3xl font-bold text-center mb-12" data-aos="fade-up">Galeri</h2>
                <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4" id="lightgallery">
                    @foreach ($galleries as $gallery)
                        @if ($gallery->type == 'image')
                            <a href="{{ $gallery->path }}">
                                <img src="{{ $gallery->path }}" alt="Galeri Resmi"
                                    class="w-full h-48 object-cover rounded-lg" data-aos="zoom-in">
                            </a>
                        @elseif($gallery->type == 'video')
                            <a href="{{ $gallery->path }}">
                                <video class="w-full h-48 object-cover rounded-lg" data-aos="zoom-in">
                                    <source src="{{ $gallery->path }}" type="video/mp4">
                                    Tarayıcınız video etiketini desteklemiyor.
                                </video>
                            </a>
                        @endif
                    @endforeach
                </div>
            </div>
        </section>
    </div> --}}

    <!-- Contact Section -->
    <section class="py-20 bg-gradient-to-b from-gray-50 to-gray-100">
        <div class="container mx-auto px-4 max-w-6xl">
            <div class="text-center mb-16">
                <h2 class="text-4xl font-bold text-gray-800 mb-4">Bizimle İletişime Geçin</h2>
                <p class="text-gray-600 text-lg">Sorularınız ve özel siparişleriniz için bize ulaşabilirsiniz</p>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-2 gap-12">
                <!-- İletişim Bilgileri Kartı -->
                <div class="bg-white p-8 rounded-2xl shadow-lg contact-card h-full">
                    <div class="space-y-8">
                        <div class="flex items-center space-x-6">
                            <div class="contact-icon">
                                <i class="ri-map-pin-line text-2xl"></i>
                            </div>
                            <div>
                                <h3 class="text-xl font-semibold text-gray-800 mb-1">Adres</h3>
                                <p class="text-gray-600">Güneştepe, 2. Meşe Cd. 80/A, 16165</p>
                                <p class="text-gray-600">Osmangazi̇/Bursa</p>
                            </div>
                        </div>

                        <div class="flex items-center space-x-6">
                            <div class="contact-icon">
                                <i class="ri-phone-line text-2xl"></i>
                            </div>
                            <div>
                                <h3 class="text-xl font-semibold text-gray-800 mb-1">Telefon</h3>
                                <p class="text-gray-600">+90 538 629 20 30</p>
                            </div>
                        </div>

                        <div class="flex items-center space-x-6">
                            <div class="contact-icon">
                                <i class="ri-mail-line text-2xl"></i>
                            </div>
                            <div>
                                <h3 class="text-xl font-semibold text-gray-800 mb-1">E-posta</h3>
                                <p class="text-gray-600">info@onatpide.com</p>
                                <p class="text-gray-600">destek@onatpide.com</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- İletişim Formu Kartı -->
                <div class="bg-white p-8 rounded-2xl shadow-lg contact-card h-full">
                    <form class="space-y-6">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-gray-700 font-medium mb-2">Ad</label>
                                <div class="relative">
                                    <div
                                        class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3 text-gray-500">
                                        <i class="ri-user-line"></i>
                                    </div>
                                    <input type="text" class="contact-input pl-10 w-full" placeholder="Adınız">
                                </div>
                            </div>
                            <div>
                                <label class="block text-gray-700 font-medium mb-2">Soyad</label>
                                <div class="relative">
                                    <div
                                        class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3 text-gray-500">
                                        <i class="ri-user-line"></i>
                                    </div>
                                    <input type="text" class="contact-input pl-10 w-full" placeholder="Soyadınız">
                                </div>
                            </div>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-gray-700 font-medium mb-2">E-posta</label>
                                <div class="relative">
                                    <div
                                        class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3 text-gray-500">
                                        <i class="ri-mail-line"></i>
                                    </div>
                                    <input type="email" class="contact-input pl-10 w-full"
                                        placeholder="ornek@email.com">
                                </div>
                            </div>
                            <div>
                                <label class="block text-gray-700 font-medium mb-2">Telefon</label>
                                <div class="relative">
                                    <div
                                        class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3 text-gray-500">
                                        <i class="ri-phone-line"></i>
                                    </div>
                                    <input type="tel" class="contact-input pl-10 w-full"
                                        placeholder="+90 (___) ___ __ __">
                                </div>
                            </div>
                        </div>

                        <div>
                            <label class="block text-gray-700 font-medium mb-2">Mesajınız</label>
                            <textarea class="contact-input w-full" rows="4" placeholder="Mesajınızı buraya yazın..."></textarea>
                        </div>

                        <button type="submit"
                            class="w-full bg-amber-500 text-white py-3 px-6 rounded-lg hover:bg-amber-600 focus:ring-4 focus:ring-amber-200 transition-all duration-300 font-medium text-lg">
                            Mesaj Gönder
                        </button>
                    </form>
                </div>
            </div>

            <div class="mt-12">
                <div class="rounded-2xl overflow-hidden shadow-lg">
                    <iframe
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3044.8634156954686!2d28.99861877514088!3d40.25656666537321!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14ca1582c721c945%3A0x91b8d4292afd7402!2sOnat%20pide!5e0!3m2!1str!2str!4v1739303456479!5m2!1str!2str"
                        class="w-full h-96" style="border:0;" allowfullscreen="" loading="lazy">
                    </iframe>
                </div>
            </div>
        </div>
    </section>

@endsection
