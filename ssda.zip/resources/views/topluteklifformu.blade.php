<section class="py-20 bg-gradient-to-br from-amber-50 to-amber-100">
    <div class="container mx-auto px-4 max-w-3xl">
        <div class="bg-white rounded-3xl shadow-2xl p-8 border border-amber-100">
            <!-- Form Başlığı -->
            <div class="text-center mb-12">
                <h2 class="text-4xl font-bold text-gray-800 mb-4">Teklif Formu</h2>
                <p class="text-gray-600">Toplu etkinlikleriniz için hemen teklif alın</p>
                <div class="w-20 h-1 bg-amber-500 mx-auto mt-4 rounded-full"></div>
            </div>

            <form action="{{ route('teklif.formu.kaydet') }}" method="POST" class="space-y-8">
                @csrf

                <!-- Etkinlik Bilgileri Bölümü -->
                <div class="bg-amber-50 p-6 rounded-xl space-y-6">
                    <h3 class="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                        <i class="ri-calendar-event-fill text-amber-500 mr-2 text-xl"></i>
                        Etkinlik Detayları
                    </h3>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <!-- Etkinlik Türü -->
                        <div>
                            <label for="etkinlik_turu" class="block text-gray-700 font-medium mb-2">
                                Etkinlik Türü <span class="text-red-500">*</span>
                            </label>
                            <div class="relative">
                                <select id="etkinlik_turu" name="etkinlik_turu"
                                    class="shadow-sm focus:ring-amber-500 focus:border-amber-500 block w-full text-sm border-gray-300 rounded-lg h-11 bg-white"
                                    required>
                                    <option value="">Seçiniz</option>
                                    <option value="Cenaze">Cenaze</option>
                                    <option value="Mevlit">Mevlit</option>
                                    <option value="Acilis Toreni">Açılış Töreni</option>
                                    <option value="Hayir Yemegi">Hayır Yemeği</option>
                                    <option value="Diger">Diğer</option>
                                </select>
                                <div class="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                                    <i class="ri-arrow-down-s-line text-gray-400 text-xl"></i>
                                </div>
                            </div>
                        </div>

                        <!-- Kişi Sayısı -->
                        <div>
                            <label for="kisi_sayisi" class="block text-gray-700 font-medium mb-2">
                                Tahmini Kişi Sayısı <span class="text-red-500">*</span>
                            </label>
                            <div class="relative">
                                <input type="number" id="kisi_sayisi" name="kisi_sayisi"
                                    class="shadow-sm focus:ring-amber-500 focus:border-amber-500 block w-full text-sm border-gray-300 rounded-lg pl-11 h-11"
                                    placeholder="Örn: 100" required>
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <i class="ri-group-line text-amber-500 text-lg"></i>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <!-- Etkinlik Tarihi -->
                        <div>
                            <label for="etkinlik_tarihi" class="block text-gray-700 font-medium mb-2">
                                Etkinlik Tarihi <span class="text-red-500">*</span>
                            </label>
                            <div class="relative">
                                <input type="date" id="etkinlik_tarihi" name="etkinlik_tarihi"
                                    class="shadow-sm focus:ring-amber-500 focus:border-amber-500 block w-full text-sm border-gray-300 rounded-lg pl-11 h-11"
                                    required>
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <i class="ri-calendar-line text-amber-500 text-lg"></i>
                                </div>
                            </div>
                        </div>

                        <!-- Etkinlik Saati -->
                        <div>
                            <label for="etkinlik_saati" class="block text-gray-700 font-medium mb-2">
                                Etkinlik Saati
                            </label>
                            <div class="relative">
                                <input type="time" id="etkinlik_saati" name="etkinlik_saati"
                                    class="shadow-sm focus:ring-amber-500 focus:border-amber-500 block w-full text-sm border-gray-300 rounded-lg pl-11 h-11">
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <i class="ri-time-line text-amber-500 text-lg"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- İletişim Bilgileri Bölümü -->
                <div class="bg-gray-50 p-6 rounded-xl space-y-6">
                    <h3 class="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                        <i class="ri-contacts-fill text-amber-500 mr-2 text-xl"></i>
                        İletişim Bilgileri
                    </h3>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <!-- Ad Soyad -->
                        <div>
                            <label for="ad_soyad" class="block text-gray-700 font-medium mb-2">
                                Adınız Soyadınız <span class="text-red-500">*</span>
                            </label>
                            <div class="relative">
                                <input type="text" id="ad_soyad" name="ad_soyad"
                                    class="shadow-sm focus:ring-amber-500 focus:border-amber-500 block w-full text-sm border-gray-300 rounded-lg pl-11 h-11"
                                    placeholder="Adınız Soyadınız" required>
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <i class="ri-user-line text-amber-500 text-lg"></i>
                                </div>
                            </div>
                        </div>

                        <!-- Telefon -->
                        <div>
                            <label for="telefon" class="block text-gray-700 font-medium mb-2">
                                Telefon Numaranız <span class="text-red-500">*</span>
                            </label>
                            <div class="relative">
                                <input type="tel" id="telefon" name="telefon"
                                    class="shadow-sm focus:ring-amber-500 focus:border-amber-500 block w-full text-sm border-gray-300 rounded-lg pl-11 h-11"
                                    placeholder="(5XX) XXX XX XX" required>
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <i class="ri-phone-line text-amber-500 text-lg"></i>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Email -->
                    <div>
                        <label for="email" class="block text-gray-700 font-medium mb-2">
                            E-Posta Adresiniz <span class="text-red-500">*</span>
                        </label>
                        <div class="relative">
                            <input type="email" id="email" name="email"
                                class="shadow-sm focus:ring-amber-500 focus:border-amber-500 block w-full text-sm border-gray-300 rounded-lg pl-11 h-11"
                                placeholder="ornek@email.com" required>
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <i class="ri-mail-line text-amber-500 text-lg"></i>
                            </div>
                        </div>
                    </div>

                </div>

                <!-- Bütçe ve Ek İstekler Bölümü -->
                <div class="bg-amber-50 p-6 rounded-xl space-y-6">
                    <h3 class="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                        <i class="ri-money-dollar-circle-line text-amber-500 mr-2 text-xl"></i>
                        Ek İstekler
                    </h3>
                    {{--
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <!-- Minimum Bütçe -->
                        <div>
                            <label for="butce_araligi_min" class="block text-gray-700 font-medium mb-2">
                                Minimum Bütçe
                            </label>
                            <div class="relative">
                                <input type="number" id="butce_araligi_min" name="butce_araligi_min"
                                    class="shadow-sm focus:ring-amber-500 focus:border-amber-500 block w-full text-sm border-gray-300 rounded-lg pl-11 h-11"
                                    placeholder="Min. Bütçe">
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <i class="ri-money-dollar-circle-line text-amber-500 text-lg"></i>
                                </div>
                            </div>
                        </div>

                        <!-- Maksimum Bütçe -->
                        <div>
                            <label for="butce_araligi_max" class="block text-gray-700 font-medium mb-2">
                                Maksimum Bütçe
                            </label>
                            <div class="relative">
                                <input type="number" id="butce_araligi_max" name="butce_araligi_max"
                                    class="shadow-sm focus:ring-amber-500 focus:border-amber-500 block w-full text-sm border-gray-300 rounded-lg pl-11 h-11"
                                    placeholder="Max. Bütçe">
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <i class="ri-money-dollar-circle-line text-amber-500 text-lg"></i>
                                </div>
                            </div>
                        </div>
                    </div> --}}

                    <!-- Ek İstekler -->
                    <div>
                        <label for="ek_istekler" class="block text-gray-700 font-medium mb-2">
                            Ek İstekleriniz
                        </label>
                        <div class="relative">
                            <textarea id="ek_istekler" name="ek_istekler" rows="4"
                                class="shadow-sm focus:ring-amber-500 focus:border-amber-500 block w-full text-sm border-gray-300 rounded-lg pl-11"
                                placeholder="Ek isteklerinizi veya notlarınızı buraya yazabilirsiniz."></textarea>
                            <div class="absolute top-3 left-0 pl-3 flex items-start pointer-events-none">
                                <i class="ri-message-3-line text-amber-500 text-lg"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Gönder Butonu -->
                <div>
                    <button type="submit"
                        class="w-full bg-amber-500 text-white py-4 px-6 rounded-xl hover:bg-amber-600 focus:ring-4 focus:ring-amber-200 transition-all duration-300 font-medium text-lg flex items-center justify-center space-x-2">
                        <i class="ri-send-plane-fill"></i>
                        <span>Teklif İste</span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</section>
