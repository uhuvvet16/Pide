<form action="{{ route('products.upload.image') }}" method="POST" enctype="multipart/form-data" class="upload-form flex items-center space-x-4">
    @csrf
    <input type="hidden" name="product_id" value="{{ $product->id }}">
    <input type="file" name="image" required class="border border-gray-300 rounded px-3 py-2">
    <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Yükle</button>
</form>
