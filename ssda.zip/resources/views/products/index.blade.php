@extends('back.layouts.master')

@section('title', 'Ürün Yönetimi')
@section('title_header', 'Ürün Yönetimi')

@section('section')
    <div class="mb-4">
        <a href="{{ route('products.create') }}" class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
            <i class="ri-add-line align-middle"></i> Yeni Ürün Ekle
        </a>
    </div>

    @if(session('success'))
        <div class="bg-green-200 p-3 rounded mb-4">
            {{ session('success') }}
        </div>
    @endif

    <div class="overflow-x-auto">
        <table id="productsTable" class="min-w-full bg-white border border-gray-300">
            <thead class="bg-gray-100">
                <tr>
                    <th class="px-4 py-2 border-b">#</th>
                    <th class="px-4 py-2 border-b">Adı</th>
                    <th class="px-4 py-2 border-b">Slug</th>
                    <th class="px-4 py-2 border-b">Açıklama</th>
                    <th class="px-4 py-2 border-b">Fiyat</th>
                    <th class="px-4 py-2 border-b">Stok</th>
                    <th class="px-4 py-2 border-b">Kategori</th>
                    <th class="px-4 py-2 border-b">Oluşturulma Tarihi</th>
                    <th class="px-4 py-2 border-b">İşlemler</th>
                </tr>
            </thead>
            <tbody>
                @foreach($products as $product)
                    <tr>
                        <td class="px-4 py-2 border-b">{{ $product->id }}</td>
                        <td class="px-4 py-2 border-b">{{ $product->name }}</td>
                        <td class="px-4 py-2 border-b">{{ $product->slug }}</td>
                        <td class="px-4 py-2 border-b">{{ $product->description }}</td>
                        <td class="px-4 py-2 border-b">{{ number_format($product->price, 2) }} TL</td>
                        <td class="px-4 py-2 border-b">{{ $product->stock }}</td>
                        <td class="px-4 py-2 border-b">{{ $product->category->name }}</td>
                        <td class="px-4 py-2 border-b">{{ $product->created_at->format('d-m-Y H:i') }}</td>
                        <td class="px-4 py-2 border-b">
                            <a href="{{ route('products.edit', $product) }}" class="text-blue-500 hover:text-blue-700"><i class="ri-edit-line align-middle"></i> Düzenle</a>
                            <form action="{{ route('products.destroy', $product) }}" method="POST" class="inline-block" onsubmit="return confirm('Ürünü silmek istediğinize emin misiniz?')">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="text-red-500 hover:text-red-700 ml-2"><i class="ri-delete-bin-line align-middle"></i> Sil</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection

@section('scripts')
    <script>
        $(document).ready( function () {
            $('#productsTable').DataTable({
                language: {
                    url: '//cdn.datatables.net/plug-ins/1.13.6/i18n/tr.json', // Türkçe dil dosyası
                }
            });
        } );
    </script>
@endsection
