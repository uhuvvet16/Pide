<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WooCommerce Ürünler</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.5/css/jquery.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.5/js/jquery.dataTables.min.js"></script>
</head>
<body class="bg-gray-100">

<div class="container mx-auto py-10">
    <h1 class="text-2xl font-bold text-center mb-6">WooCommerce Ürünleri</h1>

    <table id="productsTable" class="min-w-full bg-white shadow-md rounded-lg">
        <thead>
        <tr>
            <th>Ürün Adı</th>
            <th>Eylemler</th>
        </tr>
        </thead>
    </table>
</div>

<!-- Success or Error Modal -->
<div id="statusModal" class="fixed z-50 inset-0 hidden bg-gray-900 bg-opacity-50 flex items-center justify-center">
    <div class="bg-white rounded-lg shadow-lg p-6 w-1/3">
        <h2 id="modalTitle" class="text-xl font-bold mb-4"></h2>
        <p id="modalMessage" class="mb-4"></p>
        <button id="closeModal" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Kapat</button>
    </div>
</div>

<script>
    $(document).ready(function () {
        const table = $('#productsTable').DataTable({
            processing: true,
            serverSide: true,
            ajax: '{{ route('products.data') }}',
            columns: [
                {data: 'name', name: 'name'},
                {data: 'actions', name: 'actions', orderable: false, searchable: false},
            ]
        });

        // Görsel yükleme işlemi
        $(document).on('submit', '.upload-form', function (e) {
            e.preventDefault();

            const form = $(this);
            const formData = new FormData(form[0]);

            $.ajax({
                url: form.attr('action'),
                method: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function (response) {
                    showModal('Başarılı', response.message);
                    table.ajax.reload();
                },
                error: function (xhr) {
                    const errorMessage = xhr.responseJSON?.message || 'Bilinmeyen bir hata oluştu.';
                    showModal('Hata', errorMessage);
                }
            });
        });

        // Modal göster
        function showModal(title, message) {
            $('#modalTitle').text(title);
            $('#modalMessage').text(message);
            $('#statusModal').removeClass('hidden');
        }

        // Modal kapat
        $('#closeModal').click(function () {
            $('#statusModal').addClass('hidden');
        });
    });
</script>

</body>
</html>
