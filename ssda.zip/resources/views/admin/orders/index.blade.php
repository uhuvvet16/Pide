@extends('back.layouts.master')

@section('section')
<div class="container mx-auto py-6">
    <h1 class="text-2xl font-bold mb-6">Sipariş Yönetimi</h1>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Bekleyen Siparişler -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-xl font-semibold">Bekleyen Siparişler</h2>
                <span class="bg-orange-100 text-orange-800 px-3 py-1 rounded-full text-sm">{{ $pendingOrders->count() }}</span>
            </div>

            @if($pendingOrders->isEmpty())
            <p class="text-gray-500 text-center py-4">Bekleyen sipariş yok</p>
            @else
            <div class="overflow-y-auto max-h-96">
                @foreach($pendingOrders as $order)
                <div class="border-b border-gray-100 last:border-0 py-3 order-item" data-id="{{ $order->id }}">
                    <div class="flex justify-between items-start">
                        <div>
                            <div class="font-medium">{{ $order->order_code }}</div>
                            <div class="text-sm text-gray-500">{{ $order->created_at->diffForHumans() }}</div>
                            <div class="text-sm mt-1">{{ $order->address->contact_name }} • {{ $order->address->contact_phone }}</div>
                        </div>
                        <div class="text-right">
                            <div class="font-bold">₺{{ number_format($order->total, 2) }}</div>
                            <div class="mt-2">
                                <button class="confirm-order bg-green-500 text-white px-3 py-1 rounded text-sm hover:bg-green-600 transition" data-id="{{ $order->id }}">
                                    Onayla
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
            @endif
        </div>

        <!-- İşlemdeki Siparişler -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-xl font-semibold">İşlemdeki Siparişler</h2>
                <span class="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm">{{ $processingOrders->count() }}</span>
            </div>

            @if($processingOrders->isEmpty())
            <p class="text-gray-500 text-center py-4">İşlemde sipariş yok</p>
            @else
            <div class="overflow-y-auto max-h-96">
                @foreach($processingOrders as $order)
                <div class="border-b border-gray-100 last:border-0 py-3 order-item" data-id="{{ $order->id }}">
                    <div class="flex justify-between items-start">
                        <div>
                            <div class="font-medium">{{ $order->order_code }}</div>
                            <div class="text-sm text-gray-500">{{ $order->created_at->diffForHumans() }}</div>
                            <div class="text-sm mt-1">
                                <span class="bg-blue-100 text-blue-800 px-2 py-0.5 rounded text-xs">{{ ucfirst($order->status) }}</span>
                            </div>
                        </div>
                        <div class="text-right">
                            <div class="font-bold">₺{{ number_format($order->total, 2) }}</div>
                            <div class="mt-2">
                                <a href="{{ route('admin.orders.show', $order->id) }}" class="bg-gray-200 text-gray-800 px-3 py-1 rounded text-sm hover:bg-gray-300 transition">
                                    Detaylar
                                </a>

                                @if($order->status === 'confirmed')
                                <button class="update-status bg-orange-500 text-white px-3 py-1 rounded text-sm hover:bg-orange-600 transition ml-1" data-id="{{ $order->id }}" data-status="preparing">
                                    Hazırlanıyor
                                </button>
                                @elseif($order->status === 'preparing')
                                <button class="update-status bg-orange-500 text-white px-3 py-1 rounded text-sm hover:bg-orange-600 transition ml-1" data-id="{{ $order->id }}" data-status="out_for_delivery">
                                    Teslimata Çıkıyor
                                </button>
                                @elseif($order->status === 'out_for_delivery')
                                <button class="update-status bg-green-500 text-white px-3 py-1 rounded text-sm hover:bg-green-600 transition ml-1" data-id="{{ $order->id }}" data-status="delivered">
                                    Teslim Edildi
                                </button>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
            @endif
        </div>
    </div>

    <!-- Tamamlanan ve İptal Edilen Siparişler -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
        <!-- Tamamlanan Siparişler -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-xl font-semibold">Tamamlanan Siparişler</h2>
                <span class="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm">{{ $completedOrders->count() }}</span>
            </div>

            @if($completedOrders->isEmpty())
            <p class="text-gray-500 text-center py-4">Tamamlanan sipariş yok</p>
            @else
            <div class="overflow-y-auto max-h-96">
                @foreach($completedOrders as $order)
                <div class="border-b border-gray-100 last:border-0 py-3">
                    <div class="flex justify-between items-start">
                        <div>
                            <div class="font-medium">{{ $order->order_code }}</div>
                            <div class="text-sm text-gray-500">{{ $order->created_at->format('M d, Y h:i A') }}</div>
                        </div>
                        <div class="text-right">
                            <div class="font-bold">₺{{ number_format($order->total, 2) }}</div>
                            <div class="mt-2">
                                <a href="{{ route('admin.orders.show', $order->id) }}" class="bg-gray-200 text-gray-800 px-3 py-1 rounded text-sm hover:bg-gray-300 transition">
                                    Detaylar
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
            @endif
        </div>

        <!-- İptal Edilen Siparişler -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-xl font-semibold">İptal Edilen Siparişler</h2>
                <span class="bg-red-100 text-red-800 px-3 py-1 rounded-full text-sm">{{ $cancelledOrders->count() }}</span>
            </div>

            @if($cancelledOrders->isEmpty())
            <p class="text-gray-500 text-center py-4">İptal edilen sipariş yok</p>
            @else
            <div class="overflow-y-auto max-h-96">
                @foreach($cancelledOrders as $order)
                <div class="border-b border-gray-100 last:border-0 py-3">
                    <div class="flex justify-between items-start">
                        <div>
                            <div class="font-medium">{{ $order->order_code }}</div>
                            <div class="text-sm text-gray-500">{{ $order->created_at->format('M d, Y h:i A') }}</div>
                        </div>
                        <div class="text-right">
                            <div class="font-bold">₺{{ number_format($order->total, 2) }}</div>
                            <div class="mt-2">
                                <a href="{{ route('admin.orders.show', $order->id) }}" class="bg-gray-200 text-gray-800 px-3 py-1 rounded text-sm hover:bg-gray-300 transition">
                                    Detaylar
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
            @endif
        </div>
    </div>
</div>

<!-- Sipariş Bildirim Sesi -->
<audio id="notification-sound" src="{{ asset('sounds/notification.mp3') }}" preload="auto"></audio>
@endsection

@section('scripts')
<script>
$(document).ready(function() {
    // Her 30 saniyede bir yeni siparişleri kontrol et
    setInterval(checkNewOrders, 30000);

    let lastOrderCount = {{ $pendingOrders->count() }};

    function checkNewOrders() {
        $.ajax({
            url: '{{ route("admin.orders.check-new") }}',
            method: 'GET',
            success: function(response) {
                if (response.count > lastOrderCount) {
                    // Bildirim sesini çal
                    $('#notification-sound')[0].play();

                    // Bildirimi göster
                    showNotification(`Yeni ${response.count - lastOrderCount} siparişiniz var!`);

                    // Yeni siparişleri göstermek için sayfayı yenile
                    location.reload();
                }

                lastOrderCount = response.count;
            }
        });
    }

    // Sipariş durumu güncellemelerini işle
    $('.confirm-order').on('click', function() {
        const orderId = $(this).data('id');
        updateOrderStatus(orderId, 'confirmed');
    });

    $('.update-status').on('click', function() {
        const orderId = $(this).data('id');
        const status = $(this).data('status');
        updateOrderStatus(orderId, status);
    });

    function updateOrderStatus(orderId, status) {
        $.ajax({
            url: `/admin/orders/${orderId}/status`,
            method: 'POST',
            data: {
                status: status,
                _token: '{{ csrf_token() }}'
            },
            success: function(response) {
                showNotification('Sipariş durumu başarıyla güncellendi');

                // Değişiklikleri yansıtmak için sayfayı yenile
                location.reload();
            },
            error: function(error) {
                console.error('Sipariş durumu güncellenirken hata:', error);
                showNotification('Sipariş durumu güncellenemedi', 'error');
            }
        });
    }

    function showNotification(message, type = 'success') {
        const notificationClass = type === 'success' ? 'bg-green-500' : 'bg-red-500';

        const notification = `
            <div class="fixed top-4 right-4 ${notificationClass} text-white px-4 py-2 rounded shadow-lg notification">
                ${message}
            </div>
        `;

        $('body').append(notification);

        setTimeout(function() {
            $('.notification').fadeOut(300, function() {
                $(this).remove();
            });
        }, 3000);
    }
});
</script>
@endsection
