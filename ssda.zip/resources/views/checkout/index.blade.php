@extends('front.master')
@section('section')
<div class="container mx-auto py-8">
    <h1 class="text-2xl font-bold mb-6">Checkout</h1>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <!-- Order Summary -->
        <div class="md:col-span-2">
            <div class="bg-white rounded-lg shadow-md p-6 mb-6">
                <h2 class="text-xl font-semibold mb-4">Order Summary</h2>

                <div class="border-b border-gray-200 pb-4">
                    @foreach($cart['items'] as $item)
                    <div class="flex justify-between py-2">
                        <div>
                            <div class="font-medium">{{ $item['quantity'] }}x {{ $item['name'] }}</div>

                            @if(!empty($item['extra_items']))
                            <div class="text-sm text-gray-500 ml-4">
                                @foreach($item['extra_items'] as $extra)
                                + {{ $extra['name'] }}
                                @endforeach
                            </div>
                            @endif

                            @if(!empty($item['special_instructions']))
                            <div class="text-sm text-gray-500 ml-4 italic">
                                "{{ $item['special_instructions'] }}"
                            </div>
                            @endif
                        </div>
                        <div class="font-medium">₺{{ number_format($item['subtotal'], 2) }}</div>
                    </div>
                    @endforeach
                </div>

                <div class="py-4">
                    <div class="flex justify-between mb-2">
                        <span>Subtotal</span>
                        <span>₺{{ number_format($cart['total'], 2) }}</span>
                    </div>
                    <div class="flex justify-between mb-2">
                        <span>Delivery Fee</span>
                        <span id="delivery-fee">₺0.00</span>
                    </div>
                    <div class="flex justify-between font-bold text-lg">
                        <span>Total</span>
                        <span id="order-total">₺{{ number_format($cart['total'], 2) }}</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Checkout Form -->
        <div class="md:col-span-1">
            <div class="bg-white rounded-lg shadow-md p-6">
                <h2 class="text-xl font-semibold mb-4">Delivery Information</h2>

                <form id="checkout-form" action="{{ route('checkout.process') }}" method="POST">
                 @csrf

                    <!-- Authentication Options -->
                    @guest
                    <div class="mb-6">
                        <div class="flex justify-between mb-4">
                            <button type="button" id="continue-as-guest" class="bg-gray-200 text-gray-800 px-4 py-2 rounded w-[48%] hover:bg-gray-300 transition active">Continue as Guest</button>
                            <a href="{{ route('login') }}?redirect=checkout" class="bg-orange-500 text-white px-4 py-2 rounded w-[48%] text-center hover:bg-orange-600 transition">Sign In</a>
                        </div>

                        <div class="text-sm text-gray-500">
                            <p>Sign in to use your saved addresses and faster checkout.</p>
                        </div>
                    </div>

                    <!-- Guest Information -->
                    <div id="guest-info">
                        <div class="mb-4">
                            <label for="contact_name" class="block text-gray-700 mb-1">Full Name</label>
                            <input type="text" id="contact_name" name="contact_name" class="w-full border border-gray-300 rounded px-3 py-2" required>
                        </div>

                        <div class="mb-4">
                            <label for="contact_phone" class="block text-gray-700 mb-1">Phone Number</label>
                            <input type="tel" id="contact_phone" name="contact_phone" class="w-full border border-gray-300 rounded px-3 py-2" required>
                        </div>

                        <div class="mb-4">
                            <label for="email" class="block text-gray-700 mb-1">Email</label>
                            <input type="email" id="email" name="email" class="w-full border border-gray-300 rounded px-3 py-2" required>
                        </div>
                    </div>
                    @endguest

                    <!-- Address Selection for Logged In Users -->
                    @auth
                    <div class="mb-4">
                        <label for="address_id" class="block text-gray-700 mb-1">Select Delivery Address</label>
                        <select id="address_id" name="address_id" class="w-full border border-gray-300 rounded px-3 py-2" required>
                            @foreach($addresses as $address)
                            <option value="{{ $address->id }}" data-lat="{{ $address->latitude }}" data-lng="{{ $address->longitude }}">
                                {{ $address->address_line }}, {{ $address->city }}
                            </option>
                            @endforeach
                        </select>

                        <div class="mt-2">
                            <a href="{{ route('addresses.create') }}?redirect=checkout" class="text-orange-500 text-sm">+ Add New Address</a>
                        </div>
                    </div>
                    @endauth

                    <!-- Address Map for Guests -->
                    @guest
                    <div class="mb-4">
                        <label class="block text-gray-700 mb-1">Delivery Address</label>

                        <div class="mb-4">
                            <input type="text" id="address_search" class="w-full border border-gray-300 rounded px-3 py-2" placeholder="Search for your address">
                        </div>

                        <div id="map" class="h-48 bg-gray-200 rounded mb-4"></div>

                        <input type="hidden" id="latitude" name="latitude" required>
                        <input type="hidden" id="longitude" name="longitude" required>

                        <div id="address-fields">
                            <div class="mb-4">
                                <label for="address_line" class="block text-gray-700 mb-1">Address Line</label>
                                <input type="text" id="address_line" name="address_line" class="w-full border border-gray-300 rounded px-3 py-2" required>
                            </div>

                            <div class="grid grid-cols-2 gap-4">
                                <div class="mb-4">
                                    <label for="city" class="block text-gray-700 mb-1">City</label>
                                    <input type="text" id="city" name="city" class="w-full border border-gray-300 rounded px-3 py-2" required>
                                </div>

                                <div class="mb-4">
                                    <label for="postal_code" class="block text-gray-700 mb-1">Postal Code</label>
                                    <input type="text" id="postal_code" name="postal_code" class="w-full border border-gray-300 rounded px-3 py-2" required>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endguest

                    <!-- Payment Method -->
                    <div class="mb-4">
                        <label class="block text-gray-700 mb-1">Payment Method</label>
                        <div class="border border-gray-300 rounded p-3">
                            <div class="flex items-center">
                                <input type="radio" id="cash_on_delivery" name="payment_method" value="cash_on_delivery" checked>
                                <label for="cash_on_delivery" class="ml-2">Cash on Delivery</label>
                            </div>
                        </div>
                    </div>

                    <!-- Order Notes -->
                    <div class="mb-6">
                        <label for="notes" class="block text-gray-700 mb-1">Order Notes (Optional)</label>
                        <textarea id="notes" name="notes" class="w-full border border-gray-300 rounded px-3 py-2" rows="2"></textarea>
                    </div>

                    <!-- Submit Button -->
                    <button type="submit" id="place-order-btn" class="w-full bg-orange-500 text-white py-3 rounded-lg font-semibold hover:bg-orange-600 transition">
                        Place Order
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection

@section('scripts')
<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_GOOGLE_MAPS_API_KEY&libraries=places"></script>
<script>
$(document).ready(function() {
    // Restaurant location
    const restaurantLat = 41.0082; // Replace with your restaurant's latitude
    const restaurantLng = 28.9784; // Replace with your restaurant's longitude
    const maxDeliveryRadius = 3; // 3 km

    let map, marker, circle;
    let deliveryFee = 0;

    // Initialize map for guest checkout
    @guest
    initMap();

    function initMap() {
        // Create map centered at restaurant
        map = new google.maps.Map(document.getElementById('map'), {
            center: { lat: restaurantLat, lng: restaurantLng },
            zoom: 13,
            mapTypeControl: false
        });

        // Add restaurant marker
        const restaurantMarker = new google.maps.Marker({
            position: { lat: restaurantLat, lng: restaurantLng },
            map: map,
            icon: {
                url: '/images/restaurant-marker.png',
                scaledSize: new google.maps.Size(40, 40)
            },
            title: 'Our Restaurant'
        });

        // Add delivery radius circle
        circle = new google.maps.Circle({
            map: map,
            center: { lat: restaurantLat, lng: restaurantLng },
            radius: maxDeliveryRadius * 1000, // Convert km to meters
            fillColor: '#FF9800',
            fillOpacity: 0.2,
            strokeColor: '#FF9800',
            strokeWeight: 1
        });

        // Add customer marker (draggable)
        marker = new google.maps.Marker({
            position: { lat: restaurantLat, lng: restaurantLng },
            map: map,
            draggable: true,
            animation: google.maps.Animation.DROP,
            title: 'Drag to your location'
        });

        // Handle marker drag events
        marker.addListener('dragend', function() {
            const position = marker.getPosition();
            updateAddressFields(position.lat(), position.lng());
        });

        // Initialize places autocomplete
        const input = document.getElementById('address_search');
        const autocomplete = new google.maps.places.Autocomplete(input);

        autocomplete.addListener('place_changed', function() {
            const place = autocomplete.getPlace();

            if (!place.geometry) {
                return;
            }

            // Update map and marker
            map.setCenter(place.geometry.location);
            marker.setPosition(place.geometry.location);

            // Update form fields
            updateAddressFields(
                place.geometry.location.lat(),
                place.geometry.location.lng(),
                place
            );
        });
    }

    function updateAddressFields(lat, lng, place = null) {
        $('#latitude').val(lat);
        $('#longitude').val(lng);

        // Calculate distance from restaurant
        const distance = calculateDistance(restaurantLat, restaurantLng, lat, lng);

        // Check if within delivery radius
        if (distance > maxDeliveryRadius) {
            showDeliveryError();
            return;
        }

        hideDeliveryError();

        // Update delivery fee based on distance
        deliveryFee = calculateDeliveryFee(distance);
        updateOrderTotal();

        // If we have place data, fill in address fields
        if (place) {
            let addressLine = '';
            let city = '';
            let postalCode = '';

            // Extract address components
            for (const component of place.address_components) {
                const type = component.types[0];

                if (type === 'street_number' || type === 'route') {
                    addressLine += component.long_name + ' ';
                } else if (type === 'locality' || type === 'administrative_area_level_1') {
                    city += component.long_name + ' ';
                } else if (type === 'postal_code') {
                    postalCode = component.long_name;
                }
            }

            $('#address_line').val(addressLine.trim() || place.formatted_address);
            $('#city').val(city.trim());
            $('#postal_code').val(postalCode);
        } else {
            // Reverse geocode to get address details
            const geocoder = new google.maps.Geocoder();
            geocoder.geocode({ location: { lat: lat, lng: lng } }, function(results, status) {
                if (status === 'OK' && results[0]) {
                    const place = results[0];

                    let addressLine = '';
                    let city = '';
                    let postalCode = '';

                    // Extract address components
                    for (const component of place.address_components) {
                        const type = component.types[0];

                        if (type === 'street_number' || type === 'route') {
                            addressLine += component.long_name + ' ';
                        } else if (type === 'locality' || type === 'administrative_area_level_1') {
                            city += component.long_name + ' ';
                        } else if (type === 'postal_code') {
                            postalCode = component.long_name;
                        }
                    }

                    $('#address_line').val(addressLine.trim() || place.formatted_address);
                    $('#city').val(city.trim());
                    $('#postal_code').val(postalCode);
                }
            });
        }
    }

    function showDeliveryError() {
        if ($('#delivery-error').length === 0) {
            const errorHtml = `
                <div id="delivery-error" class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                    <p>Sorry, your location is outside our delivery area (${maxDeliveryRadius}km radius).</p>
                </div>
            `;

            $('#map').after(errorHtml);
            $('#place-order-btn').prop('disabled', true).addClass('bg-gray-400').removeClass('bg-orange-500 hover:bg-orange-600');
        }
    }

    function hideDeliveryError() {
        $('#delivery-error').remove();
        $('#place-order-btn').prop('disabled', false).removeClass('bg-gray-400').addClass('bg-orange-500 hover:bg-orange-600');
    }
    @endguest

    // For logged in users, calculate delivery fee based on selected address
    @auth
    $('#address_id').on('change', function() {
        const $selected = $(this).find('option:selected');
        const lat = $selected.data('lat');
        const lng = $selected.data('lng');

        // Calculate distance from restaurant
        const distance = calculateDistance(restaurantLat, restaurantLng, lat, lng);

        // Check if within delivery radius
        if (distance > maxDeliveryRadius) {
            showDeliveryError();
            return;
        }

        hideDeliveryError();

        // Update delivery fee based on distance
        deliveryFee = calculateDeliveryFee(distance);
        updateOrderTotal();
    });

    function showDeliveryError() {
        if ($('#delivery-error').length === 0) {
            const errorHtml = `
                <div id="delivery-error" class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                    <p>Sorry, this address is outside our delivery area (${maxDeliveryRadius}km radius).</p>
                </div>
            `;

            $('#address_id').after(errorHtml);
            $('#place-order-btn').prop('disabled', true).addClass('bg-gray-400').removeClass('bg-orange-500 hover:bg-orange-600');
        }
    }

    function hideDeliveryError() {
        $('#delivery-error').remove();
        $('#place-order-btn').prop('disabled', false).removeClass('bg-gray-400').addClass('bg-orange-500 hover:bg-orange-600');
    }

    // Trigger change event to calculate initial delivery fee
    $('#address_id').trigger('change');
    @endauth

    // Helper functions
    function calculateDistance(lat1, lng1, lat2, lng2) {
        const R = 6371; // Radius of the earth in km
        const dLat = deg2rad(lat2 - lat1);
        const dLng = deg2rad(lng2 - lng1);
        const a =
            Math.sin(dLat/2) * Math.sin(dLat/2) +
            Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
            Math.sin(dLng/2) * Math.sin(dLng/2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        const distance = R * c; // Distance in km
        return distance;
    }

    function deg2rad(deg) {
        return deg * (Math.PI/180);
    }

    function calculateDeliveryFee(distance) {
        // Example delivery fee calculation
        const baseFee = 10;
        const feePerKm = 5;

        return baseFee + (distance * feePerKm);
    }

    function updateOrderTotal() {
        const subtotal = {{ $cart['total'] }};
        const total = subtotal + deliveryFee;

        $('#delivery-fee').text('₺' + deliveryFee.toFixed(2));
        $('#order-total').text('₺' + total.toFixed(2));
    }

    // Form validation
    $('#checkout-form').on('submit', function(e) {
        e.preventDefault();

        // Validate minimum order amount
        const minimumOrderAmount = 50; // Set your minimum order amount
        const subtotal = {{ $cart['total'] }};

        if (subtotal < minimumOrderAmount) {
            alert(`Minimum order amount is ₺${minimumOrderAmount}`);
            return false;
        }

        // Submit the form
        this.submit();
    });
});
</script>
@endsection
