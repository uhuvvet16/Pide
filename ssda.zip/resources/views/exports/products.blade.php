<table>
    <thead>
        <tr>
            <th>Ürün Adı</th>
            <th>Stok Miktarı</th>
            <th>Satış Fiyatı</th>
            <th>Kdv Miktarı</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($products as $product)
            <tr>
                <td>{{ $product->name ?? 'Bilinmiyor' }}</td>
                <td>{{ $product->stock_quantity ?? 0 }}</td>
                <td>{{ $product->price ?? 0 }}</td>
                <td>{{ $product->tax_class ?? 0 }}</td>
            </tr>
        @endforeach
    </tbody>
</table>
