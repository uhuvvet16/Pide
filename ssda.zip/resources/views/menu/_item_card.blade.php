<div class="bg-white rounded-lg shadow-md overflow-hidden">
    <img src="{{ $item->image }}" alt="{{ $item->name }}" class="w-full h-48 object-cover">

    <div class="p-4">
        <h3 class="text-lg font-semibold">{{ $item->name }}</h3>
        <p class="text-gray-600 text-sm mt-1">{{ $item->description }}</p>

        <div class="flex justify-between items-center mt-4">
            <span class="text-orange-500 font-bold">₺{{ number_format($item->price, 2) }}</span>

            <button
                class="add-to-cart bg-orange-500 text-white px-3 py-1 rounded-full text-sm hover:bg-orange-600 transition"
                data-id="{{ $item->id }}"
                data-toggle="modal"
                data-target="#item-modal-{{ $item->id }}"
            >
                <i class="ri-add-line"></i> Add to Cart
            </button>
        </div>
    </div>
</div>

<!-- Item Modal -->
<div class="modal fade" id="item-modal-{{ $item->id }}" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header border-b border-gray-200">
                <h5 class="modal-title font-semibold">{{ $item->name }}</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <img src="{{ $item->image }}" alt="{{ $item->name }}" class="w-full h-48 object-cover rounded">

                <p class="text-gray-600 my-3">{{ $item->description }}</p>

                <div class="mb-4">
                    <label class="block text-gray-700 mb-2">Quantity</label>
                    <div class="flex items-center">
                        <button class="quantity-btn bg-gray-200 px-3 py-1 rounded-l" data-action="decrease" data-target="quantity-{{ $item->id }}">-</button>
                        <input type="number" id="quantity-{{ $item->id }}" class="w-16 text-center border-t border-b border-gray-300 py-1" value="1" min="1">
                        <button class="quantity-btn bg-gray-200 px-3 py-1 rounded-r" data-action="increase" data-target="quantity-{{ $item->id }}">+</button>
                    </div>
                </div>

                @if($extraItems->count() > 0)
                <div class="mb-4">
                    <label class="block text-gray-700 mb-2">Add Extras</label>

                    @foreach($extraItems as $extra)
                    <div class="flex items-center mb-2">
                        <input type="checkbox" id="extra-{{ $extra->id }}" value="{{ $extra->id }}" class="extra-item-checkbox">
                        <label for="extra-{{ $extra->id }}" class="ml-2 flex justify-between w-full">
                            <span>{{ $extra->name }}</span>
                            <span class="text-orange-500">+₺{{ number_format($extra->price, 2) }}</span>
                        </label>
                    </div>
                    @endforeach
                </div>
                @endif

                <div class="mb-4">
                    <label for="special-instructions-{{ $item->id }}" class="block text-gray-700 mb-2">Special Instructions</label>
                    <textarea id="special-instructions-{{ $item->id }}" class="w-full border border-gray-300 rounded p-2" rows="2" placeholder="Any special requests?"></textarea>
                </div>
            </div>
            <div class="modal-footer border-t border-gray-200">
                <button type="button" class="bg-gray-300 text-gray-700 px-4 py-2 rounded" data-dismiss="modal">Cancel</button>
                <button type="button" class="add-to-cart bg-orange-500 text-white px-4 py-2 rounded" data-id="{{ $item->id }}">
                    Add to Cart - ₺{{ number_format($item->price, 2) }}
                </button>
            </div>
        </div>
    </div>
</div>
