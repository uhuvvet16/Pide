@extends('front.master') {{-- Layout dosyanızı kullanın --}}

@section('title', 'Menümüz')
@section('title_header', 'Menümüz') {{-- İsteğe bağlı başlık --}}

@section('section')

<div class="menu-container">
    <div class="menu-header">
        <h1>Menümüz</h1>
        <p>Özenle hazırladığımız lezzetli pidelerimiz</p>
    </div>

    <div class="menu-categories" id="menu-categories-container">
        <button class="category-btn active" data-category-id="all">Tüm Menü</button>
        @foreach ($menuCategories as $category)
            <button class="category-btn" data-category-id="{{ $category->id }}">{{ $category->name }}</button>
        @endforeach
    </div>

    <div class="menu-items" id="menu-items-container">
        @each('partials.menu_item', $menuItems, 'menuItem')
    </div>

    @if ($menuItems->hasMorePages())
        {{-- Paginator metodu kullanın --}}
        <div class="load-more-container" id="load-more-container">
            <button class="load-more-btn" id="load-more-button"
                data-next-page-url="{{ $menuItems->nextPageUrl() }}">Devamını Gör</button>
        </div>
    @endif
</div>



@endsection

@section('css')
<style>
    .menu-container {
            max-width: 1200px;
            margin: 0 auto;
        }

        .menu-header {
            text-align: center;
            margin-bottom: 50px;
            position: relative;
        }

        .menu-header h1 {
            font-size: 3em;
            color: #2c3e50;
            margin-bottom: 20px;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.1);
        }

        .menu-header p {
            color: #7f8c8d;
            font-size: 1.2em;
        }

        .menu-categories {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 20px;
            margin-bottom: 40px;
        }

        .category-btn {
            padding: 12px 25px;
            border: none;
            background: white;
            color: #2c3e50;
            border-radius: 30px;
            cursor: pointer;
            font-size: 1.1em;
            font-weight: 500;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }

        .category-btn:hover,
        .category-btn.active {
            background: #e67e22;
            color: white;
            transform: translateY(-2px);
        }

        .menu-items {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
            padding: 20px;
        }

        .menu-item {
            background: white;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            position: relative;
        }

        .menu-item:hover {
            transform: translateY(-10px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
        }

        .item-image {
            height: 200px;
            background-size: cover;
            background-position: center;
            position: relative;
        }

        .item-badge {
            position: absolute;
            top: 20px;
            right: 20px;
            background: #e74c3c;
            color: white;
            padding: 8px 15px;
            border-radius: 20px;
            font-size: 0.9em;
            font-weight: 500;
        }

        .item-content {
            padding: 25px;
        }

        .item-title {
            font-size: 1.4em;
            color: #2c3e50;
            margin-bottom: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .item-price {
            color: #e67e22;
            font-weight: 600;
            font-size: 1.2em;
        }

        .item-description {
            color: #7f8c8d;
            margin-bottom: 15px;
            line-height: 1.6;
        }

        .item-features {
            display: flex;
            gap: 15px;
            margin-top: 15px;
        }

        .feature {
            display: flex;
            align-items: center;
            gap: 5px;
            color: #95a5a6;
            font-size: 0.9em;
        }

        .feature i {
            color: #e67e22;
        }

        @media (max-width: 768px) {
            .menu-header h1 {
                font-size: 2em;
            }

            .menu-items {
                grid-template-columns: 1fr;
            }
        }
</style>
@endsection

@section('scripts')
<script>
    document.addEventListener('DOMContentLoaded', function() {
            const categoryButtons = document.querySelectorAll('.category-btn');
            const menuItems = document.querySelectorAll('.menu-item');

            categoryButtons.forEach(button => {
                button.addEventListener('click', function() {
                    // Aktif butonu güncelle
                    categoryButtons.forEach(btn => btn.classList.remove('active'));
                    this.classList.add('active');

                    const category = this.textContent.trim(); // Butonun metnini al (örn: "Pideler")

                    menuItems.forEach(item => {
                        if (category === 'Tüm Menü' || item.querySelector('.item-category')
                            ?.textContent.trim() === category) {
                            item.style.display = 'block'; // Göster
                        } else {
                            item.style.display = 'none'; // Gizle
                        }
                    });
                });
            });
        });
</script>

@endsection
