@extends('layouts.guest')

@section('section')
    <section class="py-20 bg-gray-50">
        <div class="container mx-auto px-4 max-w-xl">
            <div class="bg-white rounded-2xl shadow-xl p-12 text-center">
                <i class="ri-checkbox-circle-fill text-6xl text-green-500 mb-6"></i>
                <h2 class="text-3xl font-bold text-gray-800 mb-4">Teklif Formu Başarıyla Gönderildi!</h2>
                <p class="text-gray-600 mb-8">Teklif talebiniz başarıyla alınmıştır. En kısa sürede sizinle iletişime geçeceğiz.</p>
                <a href="{{ url('/') }}" class="bg-amber-500 hover:bg-amber-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline inline-block">Anasayfaya Dön</a>
            </div>
        </div>
    </section>
    @endsection
