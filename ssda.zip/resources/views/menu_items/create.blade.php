@extends('back.layouts.master')

@section('title', 'Yeni Menü Öğesi Ekle')
@section('title_header', 'Yeni Menü Öğesi Ekle')

@section('section')
<!-- Form başlangıcından hemen önce -->
@if($errors->any())
    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
        <ul>
            @foreach($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif



<div class="py-12">
    <div class="max-w-md mx-auto sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
            <div class="p-6 bg-white border-b border-gray-200">
                <form method="POST" action="{{ route('menu-items.store') }}" enctype="multipart/form-data">
                    @csrf

                    <div class="mb-4">
                        <label for="name" class="block text-gray-700 text-sm font-bold mb-2">Ad</label>
                        <input type="text" name="name" id="name" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline @error('name') border-red-500 @enderror" placeholder="Menü Öğesi Adı" value="{{ old('name') }}" required>
                        @error('name')
                            <p class="text-red-500 text-xs italic">{{ $message }}</p>
                        @enderror
                    </div>

                    <div class="mb-4">
                        <label for="description" class="block text-gray-700 text-sm font-bold mb-2">Açıklama</label>
                        <textarea name="description" id="description" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline @error('description') border-red-500 @enderror" placeholder="Menü Öğesi Açıklaması">{{ old('description') }}</textarea>
                        @error('description')
                            <p class="text-red-500 text-xs italic">{{ $message }}</p>
                        @enderror
                    </div>

                    <div class="mb-4">
                        <label for="price" class="block text-gray-700 text-sm font-bold mb-2">Fiyat</label>
                        <input type="number" name="price" id="price" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline @error('price') border-red-500 @enderror" placeholder="Fiyat" value="{{ old('price', 0) }}" required min="0" step="0.01">
                        @error('price')
                            <p class="text-red-500 text-xs italic">{{ $message }}</p>
                        @enderror
                    </div>

                    <div class="mb-4">
                        <label for="is_active" class="block text-gray-700 text-sm font-bold mb-2">Durum</label>
                        <input type="checkbox" checked name="is_active" id="is_active" class="form-checkbox h-5 w-5 text-green-600 rounded" {{ old('is_active') ? 'checked' : '' }}>
                        <span class="ml-2 text-gray-700 text-sm">Aktif</span>
                        @error('is_active')
                            <p class="text-red-500 text-xs italic">{{ $message }}</p>
                        @enderror
                    </div>

                    <div class="mb-4">
                        <label for="menu_category_id" class="block text-gray-700 text-sm font-bold mb-2">Kategori</label>
                        <select name="menu_category_id" id="menu_category_id" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline @error('menu_category_id') border-red-500 @enderror" required>
                            <option value="" disabled {{ old('menu_category_id') ? '' : 'selected' }}>Kategori Seçin</option>
                            @foreach ($categories as $category)
                                <option value="{{ $category->id }}" {{ old('menu_category_id') == $category->id ? 'selected' : '' }}>{{ $category->name }}</option>
                            @endforeach
                        </select>
                        @error('menu_category_id')
                            <p class="text-red-500 text-xs italic">{{ $message }}</p>
                        @enderror
                    </div>

                    <div class="mb-4">
                        <label for="image" class="block text-gray-700 text-sm font-bold mb-2">Resim</label>
                        <input type="file" name="image" id="image" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline @error('image') border-red-500 @enderror">
                        @error('image')
                            <p class="text-red-500 text-xs italic">{{ $message }}</p>
                        @enderror
                    </div>

                    <div class="mb-4">
                        <label for="order" class="block text-gray-700 text-sm font-bold mb-2">Sıralama</label>
                        <input type="number" name="order" id="order" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline @error('order') border-red-500 @enderror" placeholder="Sıralama" value="{{ old('order') }}">
                        @error('order')
                            <p class="text-red-500 text-xs italic">{{ $message }}</p>
                        @enderror
                    </div>

                    <div class="mb-4">
                        <label for="rating" class="block text-gray-700 text-sm font-bold mb-2">Değerlendirme (0-5)</label>
                        <input type="number" name="rating" id="rating" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline @error('rating') border-red-500 @enderror" placeholder="Değerlendirme" value="{{ old('rating') }}" min="0" max="5">
                        @error('rating')
                            <p class="text-red-500 text-xs italic">{{ $message }}</p>
                        @enderror
                    </div>

                    <div class="mb-4">
                        <label for="label" class="block text-gray-700 text-sm font-bold mb-2">Etiket (Örn. Yeni, Popüler)</label>
                        <input type="text" name="label" id="label" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline @error('label') border-red-500 @enderror" placeholder="Etiket" value="{{ old('label') }}">
                        @error('label')
                            <p class="text-red-500 text-xs italic">{{ $message }}</p>
                        @enderror
                    </div>

                    <div class="mb-4">
                        <label for="preparation_time" class="block text-gray-700 text-sm font-bold mb-2">Hazırlık Süresi (Dakika)</label>
                        <input type="number" name="preparation_time" id="preparation_time" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline @error('preparation_time') border-red-500 @enderror" placeholder="Hazırlık Süresi" value="{{ old('preparation_time') }}">
                        @error('preparation_time')
                            <p class="text-red-500 text-xs italic">{{ $message }}</p>
                        @enderror
                    </div>

                    <div class="mb-4">
                        <label for="extra_condition" class="block text-gray-700 text-sm font-bold mb-2">Ek Koşullar/Notlar</label>
                        <textarea name="extra_condition" id="extra_condition" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline @error('extra_condition') border-red-500 @enderror" placeholder="Ek Koşullar/Notlar">{{ old('extra_condition') }}</textarea>
                        @error('extra_condition')
                            <p class="text-red-500 text-xs italic">{{ $message }}</p>
                        @enderror
                    </div>

                    <div class="flex items-center justify-between">
                        <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">
                            <i class="ri-save-line align-middle"></i> Kaydet
                        </button>
                        <a href="{{ route('menu-items.index') }}" class="inline-block align-baseline font-bold text-sm text-blue-500 hover:text-blue-800">
                            İptal
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
