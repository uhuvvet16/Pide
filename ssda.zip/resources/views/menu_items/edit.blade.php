@extends('back.layouts.master')

@section('title', 'Menü Öğesi Düzenle')
@section('title_header', 'Menü Öğesi Düzenle')

@section('section')
    <form action="{{ route('menu-items.update', $menuItem) }}" method="POST" enctype="multipart/form-data"
        class="max-w-md mx-auto bg-white p-6 rounded shadow-md">
        @csrf
        @method('PUT') {{-- HTTP PUT metodu --}}

        <div class="mb-4">
            <label for="name" class="block text-gray-700 text-sm font-bold mb-2">Ürün Adı:</label>
            <input type="text" id="name" name="name" value="{{ $menuItem->name }}"
                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                required>
            @error('name')
                <p class="text-red-500 text-xs italic">{{ $message }}</p>
            @enderror
        </div>

        <div class="mb-4">
            <label for="price" class="block text-gray-700 text-sm font-bold mb-2">Fiyat:</label>
            <input type="number" id="price" name="price" step="0.01" value="{{ $menuItem->price }}"
                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                required>
            @error('price')
                <p class="text-red-500 text-xs italic">{{ $message }}</p>
            @enderror
        </div>

        <div class="mb-4">
            <label for="order" class="block text-gray-700 text-sm font-bold mb-2">Sıra (İsteğe Bağlı):</label>
            <input type="number" id="order" name="order" value="{{ $menuItem->order }}"
                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
            @error('order')
                <p class="text-red-500 text-xs italic">{{ $message }}</p>
            @enderror
        </div>

        <div class="mb-4">
            <label for="is_active" class="block text-gray-700 text-sm font-bold mb-2">Aktif mi?:</label>
            <input type="checkbox" id="is_active" name="is_active"
                class="form-checkbox h-5 w-5 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                {{ $menuItem->is_active ? 'checked' : '' }}>
            <span class="ml-2 text-gray-700 text-sm">Aktif</span>
        </div>

        <div class="mb-6">
            <label for="description" class="block text-gray-700 text-sm font-bold mb-2">Açıklama (İsteğe Bağlı):</label>
            <textarea id="description" name="description"
                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">{{ $menuItem->description }}</textarea>
            @error('description')
                <p class="text-red-500 text-xs italic">{{ $message }}</p>
            @enderror
        </div>

        <div class="mb-6">
            <label for="menu_category_id" class="block text-gray-700 text-sm font-bold mb-2">Kategori Seçin:</label>
            <select id="menu_category_id" name="menu_category_id"
                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                required>
                <option value="">Kategori Seçin</option>
                @foreach ($menuCategories as $id => $name)
                    <option value="{{ $id }}" {{ $menuItem->menu_category_id == $id ? 'selected' : '' }}>
                        {{ $name }}</option>
                @endforeach
            </select>
            @error('menu_category_id')
                <p class="text-red-500 text-xs italic">{{ $message }}</p>
            @enderror
        </div>

        <div class="mb-6">
            <label for="image" class="block text-gray-700 text-sm font-bold mb-2">Görsel (İsteğe Bağlı):</label>
            <input type="file" id="image" name="image"
                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
            @if ($menuItem->image)
                <div class="mt-2">
                    <img src="{{ asset('storage/' . $menuItem->image) }}" alt="{{ $menuItem->name }}" class="h-20 w-auto">
                </div>
            @endif
            @error('image')
                <p class="text-red-500 text-xs italic">{{ $message }}</p>
            @enderror
        </div>

        <div class="flex items-center justify-between">
            <button
                class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                type="submit">
                Güncelle
            </button>
            <a href="{{ route('menu-items.index') }}"
                class="inline-block align-baseline font-bold text-sm text-blue-500 hover:text-blue-800">
                İptal
            </a>
        </div>
    </form>
@endsection
