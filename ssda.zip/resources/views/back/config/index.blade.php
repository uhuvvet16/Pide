@extends('back.layouts.master')
@section('section')
    
    <div>
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">@yield('title')
                </h6>
            </div>
            <div class="card-body">
                <form method="POST" action="{{route('admin.config.update')}}" enctype="multipart/form-data">
                    @csrf
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Site Başlığı</label>
                                <input class="form-control" type="text" name="title" id="" value="{{$config->title}}">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Site Aktiflik Durumu</label>
                                <select class="form-control" name="active" id="">
                                    <option @if($config->active==1) selected @endif value="1">Açık</option>
                                    <option @if($config->active==0) selected @endif value="0">Kapalı</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label>Site Açıklaması</label>
                                <textarea class="form-control" name="content" id="" cols="30" rows="5">
                                    {{$config->content}}
                                </textarea>
                            </div>
                        </div>

                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Site Logo</label>
                                <input class="form-control" type="file" name="logo">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Site Favicon</label>
                                <img src="{{ asset($config->favicon) ?? null }}" alt="">
                                <input class="form-control" type="file" name="favicon">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Telefon</label>
                                <input class="form-control" type="text" name="telefon" value="{{$config->telefon}}">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Mail</label>
                                <input class="form-control" type="mail" name="mail" value="{{$config->mail}}">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Facebook</label>
                                <input class="form-control" type="text" name="facebook" value="{{$config->facebook}}">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Instagram</label>
                                <input class="form-control" type="text" name="instagram" value="{{$config->instagram}}">
                            </div>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-block btn-md btn-success">Güncelle</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

    </div>

    @push('css')
        <link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
        <style>
            .form-label {
                color: #fff !important;
            }
        </style>
    @endpush
    @push('scripts')
        <script>
            $(document).ready(function() {
                $('#table-products').DataTable();
            });
        </script>
    @endpush
    @endsection
