@extends('back.layouts.master')
@section('section')
    

    <div>
    
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">{{ $articles->count() }} Makale Bulundu
    
                    {{-- <a href="{{ route('trashed.article') }}" class="col-md-4 btn btn-block btn-warning"><i
                            class="fa fa-trash"></i></a> --}}
                </h6>
            </div>
            <div class="col-md-4">
    
            </div>
            <div class="card-body"> 
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Fotoğraf</th>
                                <th>Makale Başlığı</th>
                                <th>Kategori</th>
                                <th>Hit</th>
                                <th>Oluşturma Tarihi</th>
                                <th>Durum</th>
                                <th>İşlemler</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($articles as $article)
                                <tr>
                                    <td><img src="{{ asset($article->image) }}" width="120"></td>
                                    <td>{{ $article->title }}</td>
                                    <td>{{ $article->getCategory->name ?? null }}</td>
                                    <td>{{ $article->hit }}</td>
                                    <td>{{ $article->created_at->diffForHumans() }}</td>
                                    <td><input class="switch" article-id="{{ $article->id }}" type="checkbox" data-on="Aktif"
                                            data-onstyle="success" data-offstyle="danger" data-off="Pasif"
                                            @if ($article->status == 1) checked @endif data-toggle="toggle"></td>
                                    <td>
                                        {{-- <a target="_blank"
                                            href="{{ route('single', [$article->getCategory->slug, $article->slug]) }}"
                                            class="btn btn-sm btn-success" title="Görüntüle"><i class="fa fa-eye"></i></a> --}}
                                        <a href="{{ route('admin.bloglar.edit', $article->id) }}" class="btn btn-sm btn-primary"
                                            title="Düzenle"><i class="uil uil-pen"></i></a>
                                        <a href="{{ route('admin.delete.article', $article->id) }}" class="btn btn-sm btn-danger"
                                            title="Sil"><i class="uil uil-times"></i></a>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    
    </div>

    @push('css')
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
        <link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
        <style>
            .form-label {
                color: #fff !important;
            }
        </style>
    @endpush
    @push('scripts')
        <script>
            $(document).ready(function() {
                $('#table-products').DataTable();
            });
        </script>
    @endpush
    @endsection
