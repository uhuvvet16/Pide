@extends('back.layouts.master')
@section('section')

{{-- <div class="container">
    <div class="row">
      <div class="col-md-8">
        <table class="table">
          <thead>
            <tr>
              <th>Gün</th>
              <th>Ziyaretçi Sayısı</th>
              <th>Sayfa Görüntüleme Sayısı</th>
            </tr>
          </thead>
          <tbody>
            @foreach ($analyticsData as $dateRange => $data)
            <tr>
              <td>{{ $dateRange }}</td>
              <td>{{ $data['visitors'] }}</td>
              <td>{{ $data['pageViews'] }}</td>
            </tr>
            @endforeach
          </tbody>
        </table>
      </div>
    </div>
  </div> --}}

    <br>
    <br>
    {{-- <p>Şu anda {{ $currentVisitors }} kişi sitede</p> --}}

    <br>
    <br>
    {{-- <div class="container">
        <div class="row">
            <div class="col">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Ülke</th>
                            <th>Oturum Sayısı</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($countries as $country => $sessions)
                            <tr>
                                <td>{{ $country }}</td>
                                <td>{{ $sessions }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <br><br>
    <canvas id="visitors-chart"></canvas> --}}


@endsection

@section('css')
    <!-- Fonts -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

    <!-- Styles -->


    <style>
        body {
            font-family: 'Nunito', sans-serif;
        }

        #visitors-chart {
            max-height: 500px;
            /* istediğiniz maksimum yükseklik değeri */
        }
    </style>
@endsection

@section('js')
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    {{-- <script>
        var visitorsChart = new Chart(document.getElementById('visitors-chart'), {
            type: 'line',
            data: {
                labels: {!! json_encode($dates) !!},
                datasets: [{
                    label: 'Ziyaretçi Sayısı',
                    data: {!! json_encode($visitors) !!},
                    borderColor: 'blue',
                    borderWidth: 2,
                    fill: false
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
    </script> --}}
@endsection
