@extends('back.layouts.master')
@section('section')

<div>
    <div class="container mt-5">
        <div class="card bg-dark shadow mb-4 mt-5">
            <div class="card-header py-3 bg-dark">
                <h6 class="m-0 font-weight-bold text-primary">

                    {{-- <a href="{{ route('customer.create') }}" class="btn btn-block btn-warning float-end">Müşteri Oluştur</a> --}}
                </h6>
            </div>
            <div class="col-md-4">

            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-dark" id="table-customer" width="100%" cellspacing="0">
                        <thead>
                            <tr>

                                <th>Müsteri Adı</th>
                                {{-- <th>Durum</th>
                                <th>İşlemler</th> --}}
                            </tr>
                        </thead>
                        <tbody>

                            @foreach ($users as $user)
                                <tr>


                                    <td>{{ $user->name }}</td>

                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</div>

@push('css')

<link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
<style>
    .form-label {
        color: #fff !important;
    }

    .card .card-header {
        border-bottom: 2px solid #f5f5fa;
    }
</style>
@endpush
@push('scripts')
<script>
    $(document).ready(function() {
        $('#table-customer').DataTable();
    });
</script>
@endpush
@endsection
