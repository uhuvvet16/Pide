@extends('back.layouts.master')
@section('section')
    <div>
        <section id="update_product">
            <div class="container mt-5">
                <div class="card shadow mb-4 mt-5">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">@yield('title')</h6>
                    </div>
                    <div class="card-body">
                        @if ($errors->any())
                            <div class="alert alert-danger">
                                @foreach ($errors->all() as $error)
                                    <li> {{ $error }}</li>
                                @endforeach
                            </div>
                        @endif
                        <form method="POST" action="{{ route('admin.product.edit.post', $product->id) }}"
                            enctype="multipart/form-data">
                            @csrf
                            <div class="form-group">
                                <label>Ürün Başlığı</label>
                                <input type="text" name="name" class="form-control" value="{{ $product->name }}">
                            </div>
                            <div class="form-group">
                                <label>Stok Kodu</label>
                                <input type="text" name="stock_code" class="form-control" value="{{ $product->stock_code ?? null }}">
                            </div>
                            <div class="form-group">
                                <label>Ürün Fiyatı</label>
                                <input type="text" name="price" class="form-control" value="{{ $product->price }}">
                            </div>
                            <div class="form-group">
                                <label>Ürün Açıklaması</label>

                                <textarea id="editor" class="form-control" name="content" id="" cols="30" rows="5">{{ $product->content }}</textarea>
                            </div>
                            {{-- <div id="orderSuccess" style="display: none" class="alert alert-success">
                                Sıralama Başarıyla Güncellendi
                            </div> --}}
                            <div class="form-group">
                                <label>Resmi Güncelle</label><br>
                                @foreach ($product->productImages as $image)
                                    @if ($loop->first)
                                    <img src="{{ asset($image->image) ?? null }}" class="rounded img-thumbnail " alt=""
                                    width="150">
                                    @endif
                                @endforeach
                                
                                <input type="file" name="image[]" class="form-control mt-3">
                            </div>
                            
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary btn-block">Ürünü Güncelle</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>


            {{-- <div class="container mt-5">
                <img width="200px" id="image">
    
                <form data-action="{{ route('image-upload.post') }}" method="POST" enctype="multipart/form-data" id="laravel-image-upload">
                    @csrf
                    <div class="row">
            
                        <div class="col-md-6">
                            <input type="file" name="image" class="form-control">
                        </div>
             
                        <div class="col-md-6">
                            <button type="submit" class="btn btn-success">Upload</button>
                        </div>
             
                    </div>
                </form>
            </div> --}}

        </section>
    </div>

    @push('css')
        <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
        <link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
        <style>
            .form-label {
                color: #fff !important;
            }
        </style>
        
        <style type="text/css">
            .error {
                color: red;
            }

            #image {
                display: none;
            }
        </style>
    @endpush
    @push('scripts')
        <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>
        <script>
            $(document).ready(function() {
                $('#editor').summernote({
                    'height': 300
                });

            });
        </script>
         <script type="text/javascript">
            $(document).ready(function(){
              $('#laravel-image-upload').on('submit', function(event){
                    event.preventDefault();

                    var url = $('#laravel-image-upload').attr('data-action');

                    $.ajax({
                        url: url,
                        method: 'POST',
                        data: new FormData(this),
                        dataType: 'JSON',
                        contentType: false,
                        cache: false,
                        processData: false,
                        success:function(response)
                        {
                            $('#image').attr('src', response.image).show();

                            alert(response.message)
                        },
                        error: function(response) {
                            $('.error').remove();
                            $.each(response.responseJSON.errors, function(k, v) {
                                $('[name=\"image\"]').after('<p class="error">'+v[0]+'</p>');
                            });
                        }
                    });
                });

            });
        </script>
    @endpush
    @endsection
