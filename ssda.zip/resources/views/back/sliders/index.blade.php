@extends('back.layouts.master')
@section('section')
    <div>
        <div class="container mt-5">
            <div class="card bg-dark shadow mb-4 mt-5">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">
    
                        <a href="{{ route('admin.slider.create') }}" class="float-end btn btn-block btn-warning">Slider Oluştur</a>
                    </h6>
                </div>
                <div class="col-md-4">

                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-dark" id="table-products" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>Fotoğraf</th>
                                    <th>Slider Başlığı</th>
                                    <th>Açıklama</th>
                                    <th>Yönlendirme Linki</th>
                                    {{-- <th>Durum</th> --}}
                                    <th>İşlemler</th>
                                </tr>
                            </thead>
                            <tbody>

                                @foreach ($sliders as $slider)
                                    <tr>
                                        {{-- <img onclick="changeImage(this)" src="{{  asset(''.$image->image) ?? null }}" width="70" /> --}}
                                        <td>
                                            <img src="{{ asset($slider->image) }}" width="120">
                                        </td>

                                        <td>{{ $slider->title }}</td>
                                        <td>{{ $slider->content ?? null }}</td>
                                        <td>{{ $slider->link }}</td>
                                        {{-- <td>{{ $slider->created_at->diffForHumans() }}</td> --}}
                                        {{-- <td><input class="switch" product-id="{{ $product->id }}" type="checkbox"
                                                data-on="Aktif" data-onstyle="success" data-offstyle="danger"
                                                data-off="Pasif" @if ($product->status == 1) checked @endif
                                                data-toggle="toggle">
                                            </td>--}}
                                        <td> 

                                            {{-- <a target="_blank"
                                                href="{{ route('single.product', [$product->getProductCategory->slug, $product->slug]) }}"
                                                class="btn btn-sm btn-success" title="Görüntüle"><i class="mdi mdi-eye"></i></a> --}}
                                            {{-- <a href="{{ route('admin.product.edit', $product->id) }}"
                                                class="btn btn-sm btn-primary" title="Düzenle"><i class="uil uil-pen"></i></a> --}}
                                            {{-- <a product-id="{{ $product->id }}" product-name="{{ $product->name }}"
                                                class="btn btn-sm btn-danger remove-click" title="Sil"><i
                                                    class="mdi mdi-close-box-outline"></i>
                                      </a> --}}
                                            {{-- <a href="{{ route('admin.product.delete.product', $product->id) }}" class="btn btn-sm btn-danger" title="Sil"><i class="fa fa-times"></i></a> --}}

                                            {{-- <a href="{{ route('admin.product.destroy', $product->id) }}"
                                                class="btn btn-sm btn-danger" title="Sil"><i class="uil uil-times"></i></a> --}}
                                                <a href="{{ route('admin.slider.destroy', $slider->id) }}"
                                                    class="btn btn-sm btn-danger" title="Sil"><i class="uil uil-times"></i></a>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>

    @push('css')
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
        <link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
        <style>
            .form-label {
                color: #fff !important;
            }
        </style>
    @endpush
    @push('scripts')
        <script>
            $(document).ready(function() {
                $('#table-products').DataTable();
            });
        </script>
    @endpush
    @endsection
