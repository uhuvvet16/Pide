@include('back.layouts.header')
@yield('section')
@include('back.layouts.footer')
