@extends('back.layouts.master')
@section('section')
    <div>
        <div class="container mt-5">
            <div class="card shadow mb-4 mt-5">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">@yield('title')</h6>
                </div>
                <div class="card-body">
                    @if ($errors->any())
                        <div class="alert alert-danger">
                            @foreach ($errors->all() as $error)
                                <li> {{ $error }}</li>
                            @endforeach
                        </div>
                    @endif
                    <form method="POST" action="{{ route('admin.product.categories.update.post', $category->id) }}"
                        enctype="multipart/form-data">
                        @csrf
                        <div class="form-group">
                            <label>Kategori Adı</label>
                            <input type="text" name="name" class="form-control" value="{{ $category->name }}">
                        </div>
                        
                        <div class="form-group">
                            <label>Kategori Açıklaması</label>
                            {{-- <input type="text" name="content" class="form-control" value="{{ $category->content }}"> --}}
                            <textarea name="content" class="form-control" id="" cols="30" rows="5">{{ $category->content }}</textarea>
    
                        </div>
       
    
                        <div class="form-group">
                            <label>Kategori Resmi</label><br>
                            <img src="{{ asset($category->image) }}" class="rounded img-thumbnail " alt="{{ $category->name }}"
                                width="150">
                            <input type="file" name="image" class="form-control mt-3">
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary btn-block">Kategoriyi Güncelle</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

    </div>

    @push('css')
    @endpush
    @push('scripts')


    @endpush
    @endsection
