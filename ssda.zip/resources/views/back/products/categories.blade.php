@extends('back.layouts.master')
@section('section')
    <div>
        <div class="container mt-5">
            <div class="card shadow mb-4 mt-5">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Ana Kategoriler


                    </h6>
                </div>
                <div class="col-md-4">

                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="table-categories" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>Kategori Resmi</th>
                                    <th>Kategori Adı</th>
                                    <th>Kategori Açıklaması</th>
                                    <th>Oluşturma Tarihi</th>
                                    {{-- <th>Durum</th> --}}
                                    <th>İşlemler</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($categories as $category)
                                    <tr>
                                        <td><img src="{{ asset($category->image) }}" width="120"></td>
                                        <td>{{ $category->name }}</td>
                                        <td>{{ $category->content }}</td>
                                        {{-- <td>{{ $category->getCategory->name ?? null }}</td> --}}
                                        <td>{{ $category->created_at->diffForHumans() }}</td>
                                        {{-- <td><input class="switch" category-id="{{ $category->id }}" type="checkbox"
                                                data-on="Aktif" data-onstyle="success" data-offstyle="danger"
                                                data-off="Pasif" @if ($category->status == 1) checked @endif
                                                data-toggle="toggle"></td> --}}
                                        <td>
                                            {{-- <a target="_blank"
                                                href="{{ route('admin.product.single', [$category->getCategory->slug, $category->slug]) }}"
                                                class="btn btn-sm btn-success" title="Görüntüle"><i class="fa fa-eye"></i></a> --}}
                                            <a href="{{ route('admin.product.categories.update', $category->id) }}"
                                                class="btn btn-sm btn-primary" title="Düzenle"><i
                                                    class="uil uil-pen"></i></a>

                                                    <a href="{{ route('admin.product.category.destroy', $category->id) }}"
                                                        class="btn btn-sm btn-danger" title="Sil"><i
                                                            class="uil uil-times"></i></a>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="container mt-5">
            <div class="card shadow mb-4 mt-5">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Alt Kategoriler
                    </h6>
                </div>
                <div class="col-md-4">

                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="table-categories" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>Kategori Resmi</th>
                                    <th>Kategori Adı</th>
                                    <th>Kategori Açıklaması</th>
                                    <th>Oluşturma Tarihi</th>
                                    {{-- <th>Durum</th> --}}
                                    <th>İşlemler</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($categories as $category)
                                    @foreach ($category->subCategories as $childCategory)
                                        <tr>
                                            <td><img src="{{ asset($childCategory->image) }}" width="120"></td>
                                            <td>{{ $childCategory->name }}</td>
                                            <td>{{ $childCategory->content }}</td>
                                            {{-- <td>{{ $childCategory->getCategory->name ?? null }}</td> --}}
                                            <td>{{ $childCategory->created_at->diffForHumans() }}</td>
                                            {{-- <td><input class="switch" category-id="{{ $childCategory->id }}" type="checkbox"
                                                data-on="Aktif" data-onstyle="success" data-offstyle="danger"
                                                data-off="Pasif" @if ($childCategory->status == 1) checked @endif
                                                data-toggle="toggle"></td>
                                                --}}
                                            <td>
                                                {{-- <a target="_blank"
                                                href="{{ route('admin.product.single', [$childCategory->getCategory->slug, $childCategory->slug]) }}"
                                                class="btn btn-sm btn-success" title="Görüntüle"><i class="fa fa-eye"></i></a> --}}
                                                <a href="{{ route('admin.product.subcategories.update', $childCategory->id) }}"
                                                    class="btn btn-sm btn-primary" title="Düzenle"><i
                                                        class="uil uil-pen"></i></a>

                                                <a href="{{ route('admin.product.subcategory.destroy', $childCategory->id) }}"
                                                    class="btn btn-sm btn-danger" title="Sil"><i
                                                        class="uil uil-times"></i></a>
                                            </td>
                                        </tr>
                                    @endforeach
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @push('css')
        <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
        <link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
        <style>
            .form-label {
                color: #fff !important;
            }
        </style>
    @endpush
    @push('scripts')
        <script>
            $(document).ready(function() {
                $('#table-categories').DataTable();
            });
        </script>
    @endpush
@endsection
