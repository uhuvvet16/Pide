@extends('back.layouts.master')
@section('section')
    <div>
        <section id="update_product">
            <div class="container mt-5">
                <div class="card shadow mb-4 mt-5">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">@yield('title')</h6>
                    </div>
                    <div class="card-body">
                        @if ($errors->any())
                            <div class="alert alert-danger">
                                @foreach ($errors->all() as $error)
                                    <li> {{ $error }}</li>
                                @endforeach
                            </div>
                        @endif
                        @if (session('success'))
    <div class="alert alert-success">
        {{ session('success') }}
    </div>
@endif

                        <form method="POST" action="{{ route('admin.product.edit.post', $product->id) }}"
                            enctype="multipart/form-data">
                            @csrf
                            <div class="form-group">
                                <label>Ürün Başlığı</label>
                                <input type="text" name="name" class="form-control" value="{{ $product->name }}">
                            </div>
                            <div class="form-group mb-3">
                                <label>Ürün Fiyatı</label>
                                <input type="text" name="price" class="form-control" value="{{ $product->price }}">
                            </div>
                            <div class="form-group">
                                <label for="discount_percentage">İndirim Yüzdesi</label>
                                <input type="text" class="form-control" name="discount_percentage"
                                    value="{{ $product->discount ? $product->discount->percentage : '' }}">
                            </div>

                            <div class="form-group mt-3">
                                <label for="discount_valid_until">İndirim Ne zamana Kadar Geçerli</label>
                                <input type="date" class="form-control" name="discount_valid_until"
                                    value="{{ $product->discount ? $product->discount->valid_until : '' }}">
                            </div>
                            {{-- <div class="form-group mb-3">
                                <label>Ürün Ana Kategorisi</label>
                                <select id="country-dropdown" name="product_category" class="form-control">
                                    <option value="">-- Kategoriyi Seç --</option>
                                    @foreach ($product_categories as $data)
                                        <option @if ($product->product_category_id == $data->id) selected @endif
                                            value="{{ $data->id }}">
                                            {{ $data->name }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group mb-3">
                                <label>Ürün Alt Kategorisi</label>
                                <select id="state-dropdown" name="product_subcategory" class="form-control">
                                </select>
                            </div> --}}
                            <div class="form-group">
                                <label>Ürün Açıklaması</label>

                                <textarea id="editor" class="form-control" name="content" id="" cols="30" rows="5">{{ $product->content }}</textarea>
                            </div>

                            <div class="form-group">
                                <label>Resim Yükleme</label><br>

                                <input type="file" name="image[]" class="form-control mt-3" multiple>
                            </div>

                            {{-- <div class="form-group mb-2">
                                <label>Ürün Videosu 'Zorunlu Değil'</label>
                                <input type="file" name="video" class="form-control">
                            </div> --}}


                            <div class="form-group">
                                <button type="submit" class="btn btn-primary btn-block">Ürünü Güncelle</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>


            <div class="mt-5">
                <div id="orderSuccess" style="display: none" class="alert alert-success text-dark">
                    Sıralama Başarıyla Güncellendi
                <div class="mb-2 mt-2">
                    <h3>Resim işlemleri</h3>
                </div>
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">First</th>
                            <th scope="col">Last</th>
                            <th scope="col">Handle</th>
                        </tr>
                    </thead>
                    <tbody id="orders">
                        @foreach ($product->productImages as $image)
                            <tr id="image_{{ $image->id }}">
                                <td id="image_{{ $image->id }}"><img src="{{ asset($image->image) }}"
                                        alt="{{ $image->id }}" style="width:80px; height:80px;">
                                    <button id="delete-image-button-{{ $image->id }}" data-id="{{ $image->id }}"
                                        class="btn btn-sm btn-danger btn-image-del" title="Sil"><i
                                            class="uil uil-times"></i>
                                    </button>
                                </td>
                            </tr>
                        @endforeach

                    </tbody>
                </table>
            </div>



            {{-- <div class="container mt-5">
                <img width="200px" id="image">

                <form data-action="{{ route('image-upload.post') }}" method="POST" enctype="multipart/form-data" id="laravel-image-upload">
                    @csrf
                    <div class="row">

                        <div class="col-md-6">
                            <input type="file" name="image" class="form-control">
                        </div>

                        <div class="col-md-6">
                            <button type="submit" class="btn btn-success">Upload</button>
                        </div>

                    </div>
                </form>
            </div> --}}

        </section>

        {{-- @foreach ($product->productImages as $image)
        <img src="{{ asset($image->image) ?? null }}" class="rounded img-thumbnail "
            alt="" width="150">
        <button class="btn btn-danger btn-delete" data-id="{{ $image->id }}">
            <i class="uil uil-times"></i>
        </button>
    @endforeach --}}
    </div>



    @push('css')
        <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">

        <style>
            .form-label {
                color: #fff !important;
            }
        </style>

        <style type="text/css">
            .error {
                color: red;
            }

            #image {
                display: none;
            }
        </style>
    @endpush
    @push('scripts')
        <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>

        <script>
            $('#orders').sortable({
                update: function() {
                    var siralama = $('#orders').sortable('serialize');
                    // console.log(siralama);
                    $.get("{{ route('image.orders') }}?" + siralama, function(data, status) {
                        $("#orderSuccess").show().delay(2000).fadeOut();

                    });
                }
            });


            $(document).ready(function() {
                //  /------------------------------------------
                // Country Dropdown Change Event
                // -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --/
                $('#country-dropdown').on('change', function() {
                    var selectedValue = $(this).val();
                    console.log(selectedValue);
                    var idCountry = this.value;
                    $("#state-dropdown").html('');
                    $.ajax({
                        url: "{{ url('api/fetch-states') }}",
                        type: "POST",
                        data: {
                            category_id: idCountry,
                            _token: '{{ csrf_token() }}'
                        },
                        dataType: 'json',
                        success: function(result) {
                            $('#state-dropdown').html(
                                '<option value="">-- Alt Kategoriyi Seç --</option>');
                            $.each(result.states, function(key, state) {
                                var $option = $("<option />").val(state.id).text(state
                                .name);
                                if (selectedValue == state.id) {
                                    $option.attr("selected", "selected");
                                }
                                $("#state-dropdown").append($option);
                            });

                        }
                    });
                });

                var selectedValue = $('#country-dropdown').val();
                if (selectedValue) {
                    $('#country-dropdown').trigger('change');
                }
            });
        </script>
        <script>
            $(document).ready(function() {
                $('#editor').summernote({
                    'height': 300
                });

            });
        </script>
        <script>
            $(document).ready(function() {
                $('.btn-image-del').on('click', function() {
                    var id = $(this).data('id');
                    $.ajax({
                        data: {

                            _token: '{{ csrf_token() }}'
                        },
                        url: '/admin/products/edit/image/delete/' + id,
                        type: 'DELETE',
                        success: function(result) {
                            if (result.success === true) {
                                $('#image_' + id).remove();
                            } else {
                                console.error(result.message);
                            }
                        },
                        error: function(error) {
                            console.error(error);
                        }
                    });
                });
            });
        </script>
    @endpush
@endsection
