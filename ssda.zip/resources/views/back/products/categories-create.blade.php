@extends('back.layouts.master')
@section('section')
    <div>
        <div class="container mt-5">

            <div class="container bg-dark">
                <section class="addProductCategories py-4 px-3">
                    <form method="POST" action="{{ route('admin.product.categories.create') }}"
                        enctype="multipart/form-data">
                        @csrf
                        <div class="mb-3">
                            <label class="form-label">Kategori Adı</label>
                            <input type="text" name="name" class="form-control" placeholder="Kategori Adı" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Kategori Açıklaması</label>
                            <input type="text" name="content" class="form-control" placeholder="Kategori Açıklaması">

                        </div>
                        <div class="mb-3">
                            <label class="form-label">Kategori Resmi</label>
                            <input type="file" name="image" class="form-control">
                        </div>
                        <button type="submit" class="btn btn-primary btn-block mt-2">Kategori Ekle</button>
                    </form>
                </section>
            </div>
        </div>

        <div class="card shadow mb-4 mt-5">
            <div class="card-header py-3">
            </div>
            <div class="col-md-4">

            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Kategori Resmi</th>
                                <th>Kategori Adı</th>
                                <th>Kategori Açıklaması</th>
                                <th>Oluşturma Tarihi</th>
                            </tr>
                        </thead>
                        <tbody>
                            {{-- @foreach ($subcategories as $subcategory)
                                <tr>
                                    <td><img src="{{ $subcategory->image }}" width="120"></td>
                                    <td>{{ $subcategory->name }}</td>
                                    <td>{{ $subcategory->content }}</td>
                                    <td>{{ $subcategory->created_at->diffForHumans() }}</td>
                                </tr>
                            @endforeach --}}
                            {{-- @foreach ($categories as $category)
                                @foreach ($category->subCategory as $childCategory)
                                    <tr>
                                        <td><img src="{{ $childCategory->image }}" width="120"></td>
                                        <td>{{ $childCategory->name }}</td>
                                        <td>{{ $childCategory->content }}</td>
                                        <td>{{ $childCategory->created_at->diffForHumans() }}</td>
                                    </tr>
                                @endforeach
                            @endforeach --}}

                        </tbody>
                    </table>
                </div>
            </div>
        </div>


        <div class="row mt-5 ps-5 row__subcategory">
            <div class="col-md-12 form__subcategory">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">Alt Kategori Oluştur</h3>
                    </div>

                    <form method="POST" action="{{ route('admin.product.subcategories') }}">
                        @csrf
                        <div class="box-body">
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label>Kategori İsmi</label>
                                        <input type="text" name="name" class="form-control"
                                            placeholder="Kategori Adı" value="{{ old('name') }}" required />
                                    </div>
                                </div>

                            {{-- <div class="col-sm-12">
                                <div class="form-group">
                                    <label>Category Slug*</label>
                                    <input type="text" name="slug" class="form-control" placeholder="Category name" value="{{old('slug')}}" required />
                                </div>
                            </div> --}}

                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label>Üst Kategori Seçin</label>
                                        <select type="text" name="category_id" class="form-control" required>
                                            <option value="" disabled>Kategori Seçin</option>
                                            @if ($categories)
                                                @foreach ($categories as $category)
                                                    <?php $dash = ''; ?>
                                                    <option value="{{ $category->id }}">{{ $category->name }}</option>
                                                @endforeach
                                            @endif
                                        </select>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary mt-3">Oluştur</button>

                        </div>
                    </form>

                    @if ($errors->any())
                        <div>
                            @foreach ($errors->all() as $error)
                                <li class="alert alert-danger">{{ $error }}</li>
                            @endforeach
                        </div>
                    @endif

                    @if (\Session::has('error'))
                        <div>
                            <li class="alert alert-danger">{!! \Session::get('error') !!}</li>
                        </div>
                    @endif

                    @if (\Session::has('success'))
                        <div>
                            <li class="alert alert-success">{!! \Session::get('success') !!}</li>
                        </div>
                    @endif
                </div>
            </div>
        </div>
        </section>

        <ul>
            @foreach ($categories as $category)
                <li>{{ $category->name }}</li>
                <ul>
                    @foreach ($category->subCategories as $childCategory)
                        <li>{{ $childCategory->name }}</li>
                    @endforeach
                </ul>
            @endforeach
        </ul>


        {{-- <form>
            <div class="form-group mb-3">
                <select id="country-dropdown" class="form-control">
                    <option value="">-- Kategoriyi Seç --</option>
                    @foreach ($product_categories as $data)
                        <option value="{{ $data->id }}">
                            {{ $data->name }}
                        </option>
                    @endforeach
                </select>
            </div>
            <div class="form-group mb-3">
                <select id="state-dropdown" class="form-control">
                </select>
            </div>
        </form> --}}

    </div>

    @push('css')
    @endpush
    @push('scripts')


    @endpush
    @endsection
