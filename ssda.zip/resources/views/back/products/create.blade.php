@extends('back.layouts.master')
@section('section')
    <div>

        <div class="container mt-5">
            <div class="card shadow mb-4 mt-5">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">@yield('title')</h6>
                </div>
                <div class="card-body">
                    @if ($errors->any())
                        <div class="alert alert-danger">
                            @foreach ($errors->all() as $error)
                                <li> {{ $error }}</li>
                            @endforeach
                        </div>
                    @endif
                    <form method="POST" action="{{ route('admin.product.create.post') }}" enctype="multipart/form-data"
                        {{-- id="image-upload" class="dropzone" --}}>
                        @csrf
                        <div class="form-group mb-2">
                            <label>Ürün İsmi </label>
                            <input type="text" name="name" class="form-control" required>
                        </div>
                        <div class="form-group mb-2">
                            <label>Ürün Fiyatı </label>
                            <input type="text" name="price" class="form-control">
                        </div>
                        <div class="form-group mb-2">
                            <label>Ürün Açıklaması</label>

                            <textarea id="product__create" class="form-control" name="content" id="" cols="30" rows="5"></textarea>
                        </div>
                        {{-- <div class="form-group">
                            <label>Ürün Kategorisi</label>
                            <select class="form-control" name="product_category" id="">
                                <option value=""> Seçim Yapınız </option>
                                @foreach ($categories as $category)
                                    <option value="{{ $category->id }}">{{ $category->name }}</option>
                                @endforeach
                            </select>
                        </div> --}}

                        {{-- <div class="form-group mb-3">
                            <select id="country-dropdown" name="product_category" class="form-control">
                                <option value="">-- Kategoriyi Seç --</option>
                                @foreach ($product_categories as $category)
                                <option value="{{ $category->id }}">{{ $category->name }}</option>
                                @endforeach
                            </select>
                        </div> --}}

                        {{-- <div class="form-group mb-3">
                            <select id="country-dropdown" name="product_category" class="form-control">
                                <option value="">-- Kategoriyi Seç --</option>
                                @foreach ($product_categories as $data)
                                    <option value="{{ $data->id }}">
                                        {{ $data->name }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group mb-3">
                            <select id="state-dropdown" name="product_subcategory" class="form-control">
                            </select>
                        </div> --}}
                        {{-- <div class="form-group mb-3">
                            <select id="state-dropdown" name="product_category" class="form-control">
                            </select>
                        </div> --}}

                        <div class="form-group mb-2">
                            <label>Ürün Resmi</label>
                            <input type="file" name="image[]" class="form-control" multiple>
                        </div>

                        {{-- <div class="form-group mb-2">
                            <label>Ürün Videosu 'Zorunlu Değil'</label>
                            <input type="file" name="video" class="form-control">
                        </div> --}}


                        <div class="form-group">
                            <button type="submit" class="btn btn-primary btn-block">Ürünü Oluştur</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    @push('css')
    <link href="//cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
        @endpush

    @push('scripts')
    <script src="//cdn.quilljs.com/1.3.6/quill.min.js"></script>

        <script>
            $(document).ready(function () {

                /*------------------------------------------
                --------------------------------------------
                Country Dropdown Change Event
                --------------------------------------------
                --------------------------------------------*/
                $('#country-dropdown').on('change', function () {
                    var idCountry = this.value;
                    $("#state-dropdown").html('');
                    $.ajax({
                        url: "{{url('api/fetch-states')}}",
                        type: "POST",
                        data: {
                            category_id: idCountry,
                            _token: '{{csrf_token()}}'
                        },
                        dataType: 'json',
                        success: function (result) {
                            $('#state-dropdown').html('<option value="">-- Alt Kategoriyi Seç --</option>');
                            $.each(result.states, function (key, value) {
                                $("#state-dropdown").append('<option value="' + value
                                    .id + '">' + value.name + '</option>');
                            });
                            $('#city-dropdown').html('<option value="">-- Select City --</option>');
                        }
                    });
                });

                /*------------------------------------------
                --------------------------------------------
                State Dropdown Change Event
                --------------------------------------------
                --------------------------------------------*/
                $('#state-dropdown').on('change', function () {
                    var idState = this.value;
                    $("#city-dropdown").html('');
                    $.ajax({
                        url: "{{url('api/fetch-cities')}}",
                        type: "POST",
                        data: {
                            state_id: idState,
                            _token: '{{csrf_token()}}'
                        },
                        dataType: 'json',
                        success: function (res) {
                            $('#city-dropdown').html('<option value="">-- Select City --</option>');
                            $.each(res.cities, function (key, value) {
                                $("#city-dropdown").append('<option value="' + value
                                    .id + '">' + value.name + '</option>');
                            });
                        }
                    });
                });

            });
        </script>

<script>
    var quill = new Quill('#product__create', {
      theme: 'snow'
    });
  </script>

    @endpush
    @endsection
