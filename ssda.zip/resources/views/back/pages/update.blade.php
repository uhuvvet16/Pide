@extends('back.layouts.master')
@section('section')
    <div>

        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">@yield('title')</h6>
            </div>
            <div class="card-body">
                @if ($errors->any())
                    <div class="alert alert-danger">
                        @foreach ($errors->all() as $error)
                           <li> {{ $error }}</li>
                        @endforeach
                    </div>
                @endif
                <form method="POST" action="{{route('admin.page.update.post', $page->id)}}" enctype="multipart/form-data">
                    @csrf
                    <div class="form-group">
                        <label>Sayfa Başlığı</label>
                        <input type="text" name="title" class="form-control" value="{{ $page->title }}" required>
                    </div>


                    <div class="form-group">
                        <label>Sayfa Resmi</label>
                        <input type="file" name="image" class="form-control">
                    </div>

                    <br>
                    <div class="d-flex justify-content-center">
                        <img src="{{ asset($page->image) }}" alt="{{ $page->title }}" width="200">
                    </div>
                    <br>

                    <div class="form-group">
                        <label>Sayfa Açıklaması</label>

                        <textarea id="editor" name="content" class="form-control" cols="30" rows="10">{{ $page->content }} </textarea>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary btn-block">Sayfayı Güncelle</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    @push('css')
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
    @endpush

    @push('scripts')
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#editor').summernote({
                'height': 300
            });

        });
    </script>

    @endpush
    @endsection

