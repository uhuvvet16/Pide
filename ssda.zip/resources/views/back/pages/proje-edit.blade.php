<x-app-layout :assets="$assets ?? []">
    <div>

       

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">@yield('title')</h6>
        </div>
        <div class="card-body">
            @if ($errors->any())
                <div class="alert alert-danger">
                    @foreach ($errors->all() as $error)
                       <li> {{ $error }}</li>
                    @endforeach
                </div>
            @endif
            <form method="POST" action="{{ route('admin.proje.update.post', $proje->id) }}" enctype="multipart/form-data">
                @csrf
                <div class="form-group">
                    <label>Proje İsmi</label>
                    <input type="text" name="name" class="form-control" value="{{$proje->name}}">
                </div>
                <div class="form-group">
                    <label>Proje Kategori</label>
                    <select class="form-control" name="category" id="">
                        <option value=""> Seçim Yapınız </option>
                            @foreach ($categories as $category)
                                <option @if ($proje->category_id == $category->id) selected @endif value="{{ $category->id }}">
                                    {{ $category->name }}</option>
                            @endforeach
                    </select>
                </div>

                <div class="form-group">
                    <label>Proje Resmi</label>
                    <input type="file" name="image" class="form-control" value="{{$proje->image}}">
                </div>

                <div class="form-group">
                    <label>Proje İçeriği</label>

                    <textarea id="editor" name="content" class="form-control" cols="30" rows="5"> </textarea>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary btn-block">Projeyi Güncelle</button>
                </div>
            </form>
        </div>
    </div>

    @push('css')
    @endpush

    @push('scripts')


    @endpush
</x-app-layout>

