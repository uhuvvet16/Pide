@extends('back.layouts.master')
@section('section')
  


    <div>

        <div class="container mt-5">
            <div class="card shadow mb-4 mt-5">
                <div class="card-header py-3">
                    {{-- <h6 class="m-0 font-weight-bold text-primary">{{ $products->count() }} Makale Bulundu
    
                    <a href="{{ route('admin.blog.trashed.article') }}" class="col-md-4 btn btn-block btn-warning"><i
                            class="fa fa-trash"></i></a>
                </h6> --}}
                </div>
                <div class="col-md-4">

                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="table-categories" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    {{-- <th>Kategori Sıralama</th> --}}
                                    <th>Kategori Adı</th>
                                    <th>Oluşturma Tarihi</th>
                                    {{-- <th>Durum</th> --}}
                                    <th>İşlemler</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($categories as $category)
                                    <tr>
                                        {{-- <td><img src="{{ asset($category->image) }}" width="120"></td> --}}
                                        <td>{{ $category->name }}</td>
                                        {{-- <td>{{ $category->getCategory->name ?? null }}</td> --}}
                                        <td>{{ $category->created_at->diffForHumans() }}</td>
                                        {{-- <td><input class="switch" category-id="{{ $category->id }}" type="checkbox"
                                                data-on="Aktif" data-onstyle="success" data-offstyle="danger"
                                                data-off="Pasif" @if ($category->status == 1) checked @endif
                                                data-toggle="toggle"></td> --}}
                                        <td>
                                            {{-- <a target="_blank"
                                                href="{{ route('admin.product.single', [$category->getCategory->slug, $category->slug]) }}"
                                                class="btn btn-sm btn-success" title="Görüntüle"><i class="fa fa-eye"></i></a> --}}
                                            {{-- <a href="{{ route('admin.product.categories.update', $category->id) }}"
                                                class="btn btn-sm btn-primary" title="Düzenle"><i class="uil uil-pen"></i></a>

                                            <a product-category-id="{{ $category->id }}"
                                                product-category-name="{{ $category->name }}"
                                                class="btn btn-sm btn-danger remove-click" title="Sil"><i class="uil uil-times"></i>
                                            </a> --}}
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="container mt-5">

            <div class="container bg-dark">
                <section class="addProductCategories py-4 px-3">
                    <form method="POST" action="{{ route('admin.proje.categories.getcreate') }}"
                        enctype="multipart/form-data">
                        @csrf
                        <div class="mb-3">
                            <label class="form-label">Kategori Adı</label>
                            <input type="text" name="name" class="form-control" placeholder="Kategori Adı" required>
                        </div>
                        
                        <button type="submit" class="btn btn-primary btn-block mt-2">Kategori Ekle</button>
                    </form>
                </section>
            </div>
        </div>



    </div>
    

    @push('css')
    @endpush

    @push('scripts')
   
        
    @endpush
</x-app-layout>

