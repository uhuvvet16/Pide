@extends('back.layouts.master')
@section('section')
    <div>

        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">{{ $pages->count() }} Sayfa Bulundu

                    {{-- <a href="{{route('trashed.page')}}" class="col-md-4 btn btn-block btn-warning"><i class="fa fa-trash"></i></a> --}}
                </h6>
            </div>
            <div class="col-md-4">

            </div>
            <div class="card-body">
                <div id="orderSuccess" style="display: none" class="alert alert-success">
                    Sıralama Başarıyla Güncellendi
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Sıralama</th>
                                <th>Fotoğraf</th>
                                <th>Sayfa Başlığı</th>
                                <th>Durum</th>
                                <th>İşlemler</th>
                            </tr>
                        </thead>
                        <tbody id="orders">
                            @foreach ($pages as $page)
                                <tr id="page_{{$page->id}}">
                                    <td class="w-2"><i class="fa fa-arrows-alt-v fa-2x handle d-flex justify-content-center" style="cursor: move;"></i></td>
                                    <td><img src="{{ asset($page->image) }}" width="120"></td>
                                    <td>{{ $page->title }}</td>
                                    <td><input class="switch" page-id="{{ $page->id }}" type="checkbox" data-on="Aktif"
                                            data-onstyle="success" data-offstyle="danger" data-off="Pasif"
                                            @if ($page->status == 1) checked @endif data-toggle="toggle"></td>
                                    <td>
                                        <td>


                                            <a href="{{ route('admin.page.update', $page->id) }}"
                                                class="btn btn-sm btn-primary" title="Düzenle"><i
                                                    class="uil uil-pen"></i></a>

                                            <a href="{{ route('admin.delete.page', $page->id) }}"
                                                class="btn btn-sm btn-danger" title="Sil"><i
                                                    class="uil uil-times"></i></a>

                                        </td>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    @push('css')
    @endpush

    @push('scripts')


    @endpush
    @endsection

