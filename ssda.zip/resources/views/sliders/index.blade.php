@extends('back.layouts.master') {{-- Admin layout'unuza göre düzenleyin --}}

@section('section')
    <div class="container">
        <h1 class="text-2xl font-bold mb-4">Slider Yönetimi</h1>

        <div class="mb-4">
            <a href="{{ route('sliders.create') }}" class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
                Yeni Slider Ekle
            </a>
        </div>

        @if(session('success'))
            <div class="bg-green-200 text-green-800 p-3 rounded mb-4">{{ session('success') }}</div>
        @endif

        <div class="shadow overflow-hidden border-b border-gray-200 sm:rounded-lg">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Başlık</th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Resim</th>
                        <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">İşlemler</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    @foreach($sliders as $slider)
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap">{{ $slider->title }}</td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <img src="{{ asset($slider->image) }}" class="h-10 w-auto" />
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-right">
                                <a href="{{ route('sliders.edit', $slider->id) }}" class="text-indigo-600 hover:text-indigo-900 mr-2">Düzenle</a>
                                <form action="{{ route('sliders.destroy', $slider->id) }}" method="POST" class="inline-block">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="text-red-600 hover:text-red-900" onclick="return confirm('Slider silinsin mi?')">Sil</button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
