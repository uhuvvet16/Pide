<?php

if (!function_exists('public_path')) {
    function public_path($path = '')
    {
        return '/home/onatpidecomtr/public_html/onatpide'.($path ? DIRECTORY_SEPARATOR.ltrim($path, DIRECTORY_SEPARATOR) : $path);
    }
}


if (!function_exists('formatPrice')) {
    function formatPrice($price)
    {
        // Burada fiyat formatlama işlemi yapabilirsiniz
        // Örneğin, sayı formatlama:
        return '₺ ' . number_format($price, 2, ',', '.');
    }
}

