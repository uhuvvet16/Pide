<?php

namespace App\Providers;

use Illuminate\Support\Facades\URL;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\ServiceProvider;


class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Schema::defaultStringLength(191);
        Paginator::useBootstrap();

        // View::composer('*', function ($view) {
        //     $view->with('activeRoute', request()->route()->getName());
        // });

        // URL::forceRootUrl(config('app.url'));
        // if (str_starts_with(config('app.url'), 'https://')) {
        //     URL::forceScheme('https');
        // }
    }
}
