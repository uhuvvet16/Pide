<?php

namespace App\Providers;

use Automattic\WooCommerce\Client;
use App\Services\WooCommerceBarcodeService;
use Illuminate\Support\ServiceProvider;

class WooCommerceServiceProvider extends ServiceProvider
{
    public function register()
    {
        $this->app->singleton(Client::class, function () {
            return new Client(
                config('woocommerce.store_url'),
                config('woocommerce.consumer_key'),
                config('woocommerce.consumer_secret'),
                ['version' => 'wc/v3']
            );
        });

        $this->app->singleton(WooCommerceBarcodeService::class, function ($app) {
            return new WooCommerceBarcodeService($app->make(Client::class));
        });
    }
}

