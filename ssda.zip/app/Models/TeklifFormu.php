<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TeklifFormu extends Model
{
    use HasFactory;

    protected $table = 'teklif_formlari';

    protected $fillable = [
        'etkinlik_turu',
        'etkinlik_tarihi',
        'etkinlik_saati',
        'kisi_sayisi',
        'ad_soyad',
        'email',
        'telefon',
        'ek_istekler',
        'butce_araligi_min',
        'butce_araligi_max',
    ];
}
