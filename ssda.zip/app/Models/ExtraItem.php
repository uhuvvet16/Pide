<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ExtraItem extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'type',
        'price',
        'is_available',
    ];

    public function orderItems()
    {
        return $this->hasMany(OrderItem::class, 'extra_item_id');
    }
}
