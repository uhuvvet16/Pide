<?php

namespace App\Imports;

use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\ToCollection;

class ProductsImport implements ToCollection
{
    public function collection(Collection $rows)
    {
        $products = [];
        foreach ($rows as $key => $row) {
            if ($key === 0) continue; // İlk satır başlık olduğu için atla

            $products[] = [
                'barkod' => $row[0],
                'urun_adi' => $row[1],
                'marka' => $row[2],
            ];
        }

        return $products;
    }
}
