<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;

class CheckUserActivity
{
    public function handle($request, Closure $next)
    {
        if (Auth::check()) {
            $user = Auth::user();
            $currentTime = time();
            $lastActivityTime = session('last_activity_time', 0);

            // Örneğin, 30 dakika boyunca işlem yapılmadıysa logout yap
            if ($currentTime - $lastActivityTime > 30 * 60) {
                Auth::logout();
                $request->session()->invalidate();
                $request->session()->regenerateToken();
                return redirect()->route('login')->with('message', 'Oturum süreniz doldu. Lütfen tekrar giriş yapın.');
            }

            // Kullanıcının son aktivite zamanını güncelle
            session(['last_activity_time' => $currentTime]);
        }

        return $next($request);
    }
}
