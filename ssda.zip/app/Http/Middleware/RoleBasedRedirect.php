<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class RoleBasedRedirect
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        // Kullanıcı giriş yapmış mı kontrol et
        if (Auth::check()) {
            $user = Auth::user();

            // Kullanıcı tipine göre yönlendirme yap
            if ($user->type === 'admin') {
                return redirect()->route('admin.index'); // Admin paneline yönlendirme
            }

            return redirect()->route('anasayfa'); // Normal kullanıcılar için anasayfaya yönlendirme
        }

        return $next($request); // Eğer giriş yapmamışsa, isteği normal akışına devam ettir
    }
}
