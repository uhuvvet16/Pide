<?php

namespace App\Http\Controllers;

use App\Models\TeklifFormu;
use Illuminate\Http\Request;

class TeklifFormuController extends Controller
{
    public function teklifFormuGoster()
    {
        return view('teklif-formu');
    }

    public function teklifFormunuKaydet(Request $request)
    {
        $validatedData = $request->validate([
            'etkinlik_turu' => 'required|string',
            'etkinlik_tarihi' => 'required|date',
            'etkinlik_saati' => 'nullable|date_format:H:i',
            'kisi_sayisi' => 'required|integer|min:1',
            'ad_soyad' => 'required|string',
            'email' => 'required|email',
            'telefon' => 'required|string',
            'ek_istekler' => 'nullable|string',
            'butce_araligi_min' => 'nullable|numeric|min:0',
            'butce_araligi_max' => 'nullable|numeric|min:0|gte:butce_araligi_min',
        ]);

        TeklifFormu::create($validatedData);

        // İsteğe bağlı: E-posta bildirimi gönderme
        // ... Mail::to(...)->send(new TeklifFormuBildirimi(...)); ...

        return redirect()->route('teklif.formu.basarili')->with('success', 'Teklif formunuz başarıyla gönderilmiştir!');
    }

    public function teklifFormuBasarili()
    {
        return view('teklif-formu-basarili');
    }

    // Yönetim Paneli Metotları

    public function yönetimPaneli()
    {
        $teklifFormlari = TeklifFormu::latest()->paginate(10); // Örnek: Sayfalama ile son 10 teklifi al
        return view('teklif-formlari.index', compact('teklifFormlari'));
    }

    public function teklifFormuDetay($id)
    {
        $teklifFormu = TeklifFormu::findOrFail($id);
        return view('teklif-formlari.detay', compact('teklifFormu'));
    }

    // İsteğe bağlı: Teklif Formunu Silme (Dikkatli Kullanılmalı)
    // public function teklifFormuSil($id)
    // {
    //     $teklifFormu = TeklifFormu::findOrFail($id);
    //     $teklifFormu->delete();
    //     return redirect()->route('teklif.formlari')->with('success', 'Teklif formu başarıyla silinmiştir.');
    // }
}
