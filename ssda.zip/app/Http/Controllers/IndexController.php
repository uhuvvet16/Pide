<?php

namespace App\Http\Controllers;

use App\Models\Task;
use App\Models\Section;
use App\Models\MenuItem;
use App\Models\Operation;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\Models\OperationStatus;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;


class IndexController extends Controller
{
    public function getMenuItemsByCategory(Request $request)
    {
        $categoryId = $request->input('category_id');
        $page = $request->input('page', 1); // Sayfa numarasını al
        $perPage = 12;

        $query = MenuItem::with('category')->latest();

        if ($categoryId && $categoryId !== 'all') {
            $query->where('menu_category_id', $categoryId);
        }

        $menuItems = $query->paginate($perPage);

        return response()->json($menuItems);
    }
    public function index()
    {
        return view('back.dashboard');

    }
    public function generatePDF(Request $request)
    {
        $data = $request->validate([
            'musteri' => 'required',
            'bloom' => 'required',
            'tane_boyutu' => 'required',
            'onatpide_miktari' => 'required',
            'tarih' => 'required|date',
            'aciklama' => 'nullable',
        ]);

        $pdf = PDF::loadView('onatpide_talep_formu', $data);

        return $pdf->download('onatpide_talep_formu.pdf');
    }


    // public function generateAndSavePDF(Request $request)
    // {
    //     $data = $request->validate([
    //         'operasyon_basligi' => 'required|string|max:255',
    //         'musteri' => 'required|string|max:255',
    //         'sektor' => 'nullable|string|max:255',
    //         'bloom' => 'required|string|max:255',
    //         'tane_boyutu' => 'required|string|max:255',
    //         'onatpide_miktari' => 'required|numeric|min:0',
    //         'onatpide_miktari_birim' => 'required|in:g,kg',
    //         'tarih' => 'required|date',
    //         'aciklama' => 'nullable|string',
    //         'yetkili_id' => 'nullable|exists:yetkililer,id',
    //     ]);

    //     // PDF oluştur
    //     $pdf = PDF::loadView('onatpide_talep_formu', $data);

    //     // Operasyon başlığını dosya adı için uygun hale getir
    //     $safeOperationTitle = Str::slug($data['operasyon_basligi']);

    //     // Benzersiz bir dosya adı oluştur
    //     $fileName = $safeOperationTitle . '_' . time() . '.pdf';

    //     // PDF'i sunucuda sakla
    //     // $pdfPath = 'onatpide_talep_formlari/' . $fileName;
    //     // Storage::put($pdfPath, $pdf->output());

    //     // PDF'i public/assets/onatpide_talep_formlari dizinine kaydet
    //     $pdfPath = public_path('assets/onatpide_talep_formlari/' . $fileName);

    //     // Dizin yoksa oluştur
    //     File::ensureDirectoryExists(dirname($pdfPath));

    //     $yetkili = Auth::user()->yetkili;

    //     if (!$yetkili) {
    //         return redirect()->back()->with('error', 'Yetkili bulunamadı.');
    //     }
    //     // Yeni bir Operation kaydı oluştur
    //     $operation = Operation::create([
    //         'operasyon_basligi' => $data['operasyon_basligi'],
    //         'customer' => $data['musteri'],
    //         'sector' => $data['sektor'],
    //         'bloom' => $data['bloom'],
    //         'particle_size_mesh' => $data['tane_boyutu'],
    //         'sample_quantity' => $data['onatpide_miktari'],
    //         'sample_quantity_unit' => $data['onatpide_miktari_birim'],
    //         'onatpide_talep_formu' => $pdfPath,
    //         'operasyon_aciklamasi' => $data['aciklama'],
    //         'yetkili_id' => $yetkili->id, // Set the dynamic yetkili_id
    //     ]);

    //     $depoSection = Section::where('name', 'Depo')->first();

    //     if ($depoSection) {
    //         // Depo section'ı için OperationStatus oluştur
    //         OperationStatus::create([
    //             'operation_id' => $operation->id,
    //             'section_id' => $depoSection->id,
    //             'task_id' => 25,
    //             'status' => 'onay_bekliyor',
    //         ]);
    //     }

    //     // return response()->json([
    //     //     'message' => 'onatpide talep formu başarıyla oluşturuldu ve kaydedildi.',
    //     //     'operation_id' => $operation->id,
    //     //     'pdf_path' => $pdfPath
    //     // ], 201);

    //     return redirect()->back()->with('basarili', "Talep Oluşturuldu");
    // }
    public function generateAndSavePDF(Request $request)
{
    $data = $request->validate([
        'operasyon_basligi' => 'required|string|max:255',
        'musteri' => 'required|string|max:255',
        'sektor' => 'nullable|string|max:255',
        'country' => 'required|string|max:2', // Add validation for country
        'bloom' => 'required|string|max:255',
        'tane_boyutu' => 'required|string|max:255',
        'onatpide_miktari' => 'required|numeric|min:0',
        'onatpide_miktari_birim' => 'required|in:g,kg',
        'tarih' => 'required|date',
        'aciklama' => 'nullable|string',
        'yetkili_id' => 'nullable|exists:yetkililer,id',
    ]);

    // PDF oluştur
    $pdf = PDF::loadView('onatpide_talep_formu', $data);

    // Operasyon başlığını dosya adı için uygun hale getir
    $safeOperationTitle = Str::slug($data['operasyon_basligi']);

    // Benzersiz bir dosya adı oluştur
    $fileName = $safeOperationTitle . '_' . time() . '.pdf';

    // PDF'i public/assets/onatpide_talep_formlari dizinine kaydet
    $pdfPath = public_path('assets/onatpide_talep_formlari/' . $fileName);

    // Dizin yoksa oluştur
    File::ensureDirectoryExists(dirname($pdfPath));

    $yetkili = Auth::user()->yetkili;

    if (!$yetkili) {
        return redirect()->back()->with('error', 'Yetkili bulunamadı.');
    }

    // Yeni bir Operation kaydı oluştur
    $operation = Operation::create([
        'operasyon_basligi' => $data['operasyon_basligi'],
        'customer' => $data['musteri'],
        'sector' => $data['sektor'],
        'country' => $data['country'], // Add country field
        'bloom' => $data['bloom'],
        'particle_size_mesh' => $data['tane_boyutu'],
        'sample_quantity' => $data['onatpide_miktari'],
        'sample_quantity_unit' => $data['onatpide_miktari_birim'],
        'onatpide_talep_formu' => $pdfPath,
        'operasyon_aciklamasi' => $data['aciklama'],
        'yetkili_id' => $yetkili->id,
    ]);

    $depoSection = Section::where('name', 'Depo')->first();

    if ($depoSection) {
        // Depo section'ı için OperationStatus oluştur
        OperationStatus::create([
            'operation_id' => $operation->id,
            'section_id' => $depoSection->id,
            'task_id' => 25,
            'status' => 'onay_bekliyor',
        ]);
    }

    return redirect()->back()->with('basarili', "Talep Oluşturuldu");
}
}
