<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Automattic\WooCommerce\Client;
use Milon\Barcode\DNS1D;

class TestController extends Controller
{
    private Client $woocommerce;
    private const COUNTRY_CODE = '869';
    private const COMPANY_CODE = '01';

    public function __construct()
    {
        $this->initializeWooCommerceClient();
    }

    private function initializeWooCommerceClient(): void
    {
        $this->woocommerce = new Client(
            config('woocommerce.mocan_store_url'),
            config('woocommerce.mocan_consumer_key'),
            config('woocommerce.mocan_consumer_secret'),
            [
                'version' => 'wc/v3',
                'verify_ssl' => false,
                'wp_api' => true,
                'timeout' => 120
            ]
        );
    }

    // Barkod oluşturma sayfası
    public function index()
    {
        // WooCommerce'dan ürünleri çek
        $products = $this->getAllProducts();
        return view('testmocan', compact('products'));
    }
    private function getAllProducts(): array
{
    $allProducts = [];
    $page = 1;
    $perPage = 100; // Her sayfada 100 ürün çek

    do {
        // WooCommerce API'den sadece gerekli alanları çek
        $products = $this->woocommerce->get('products', [
            'per_page' => $perPage,
            'page' => $page,
            'fields' => 'id,sku,name,attributes,variations', // Sadece bu alanları çek
        ]);

        // Çekilen ürünleri tüm ürünler dizisine ekle
        $allProducts = array_merge($allProducts, $products);

        // Eğer çekilen ürün sayısı $perPage'den az ise, döngüyü sonlandır
        if (count($products) < $perPage) {
            break;
        }

        // Sonraki sayfaya geç
        $page++;
    } while (true);

    return $allProducts;
}

    public function getProductSizes($productId)
    {
        // Ürün varyasyonlarını çek
        $variations = $this->woocommerce->get("products/{$productId}/variations");

        // Bedenleri topla
        $sizes = [];
        foreach ($variations as $variation) {
            foreach ($variation->attributes as $attribute) {
                if ($attribute->name === 'Beden' || $attribute->name === 'Size') {
                    $sizes[] = $attribute->option;
                }
            }
        }

        // Eğer varyasyon yoksa, özelliklerden (attributes) bedenleri çek
        if (empty($sizes)) {
            $product = $this->woocommerce->get("products/{$productId}");
            foreach ($product->attributes as $attribute) {
                if ($attribute->name === 'Beden' || $attribute->name === 'Size') {
                    $sizes = $attribute->options;
                    break;
                }
            }
        }

        return response()->json(array_unique($sizes));
    }

    // Barkod oluşturma veya güncelleme işlemi
    public function generateBarcode(Request $request)
{
    $productId = $request->input('product_id');
    $sizeCode = $request->input('size_code');

    // Barkod oluştur
    $barcode = $this->generateEAN13Barcode($productId, $sizeCode);

    // Barkodu SKU'ya kaydet
    $this->woocommerce->put("products/{$productId}", [
        'sku' => $barcode, // Barkodu SKU'ya kaydet
    ]);

    return redirect()->route('products.barcode.index')->with('success', 'Barkod başarıyla oluşturuldu ve SKU\'ya kaydedildi: ' . $barcode);
}

    // EAN13 barkodu oluşturma fonksiyonu
    private function generateEAN13Barcode($productId, $sizeCode): string
{
    // Sabit kısım
    $fixedPart = self::COUNTRY_CODE . self::COMPANY_CODE;

    // Ürün ID'sini 5 haneye tamamla
    $productIdPart = str_pad($productId, 5, '0', STR_PAD_LEFT);

    // Beden kodunu belirle
    $sizePart = $this->getSizeCode($sizeCode);

    // İlk 12 rakamı birleştir
    $barcodeWithoutCheckDigit = $fixedPart . $productIdPart . $sizePart;

    // Kontrol kodunu hesapla
    $checkDigit = $this->calculateCheckDigit($barcodeWithoutCheckDigit);

    // Barkodu oluştur
    return $barcodeWithoutCheckDigit . $checkDigit;
}

// Beden kodunu belirleme fonksiyonu
private function getSizeCode($sizeCode): string
{
    // Sayısal beden kodlarını dinamik olarak tanımla (1'den 99'a kadar)
    $numericSizeMappings = [];
    for ($i = 1; $i <= 99; $i++) {
        $numericSizeMappings[(string)$i] = str_pad((string)$i, 2, '0', STR_PAD_LEFT);
    }

    // Harfli beden kodlarını tanımla (XS'den başlayarak)
    $letterSizeMappings = [
        'XS' => '01',
        'S'  => '02',
        'M'  => '03',
        'L'  => '04',
        'XL' => '05',
        'XXL' => '06',
        '3XL' => '07',
    ];

    // Tüm eşlemeleri birleştir
    $sizeMappings = array_merge($numericSizeMappings, $letterSizeMappings);

    // Eğer beden kodu tanımlıysa, karşılık gelen kodu döndür
    if (isset($sizeMappings[$sizeCode])) {
        return $sizeMappings[$sizeCode];
    }

    // Eğer beden kodu tanımlı değilse, varsayılan olarak '00' döndür
    return '00';
}



    // Kontrol kodu hesaplama fonksiyonu
    private function calculateCheckDigit($barcode): int
    {
        $sum = 0;
        for ($i = 0; $i < 12; $i++) {
            $digit = (int)$barcode[$i];
            $sum += ($i % 2 === 0) ? $digit : $digit * 3;
        }
        return (10 - ($sum % 10)) % 10;
    }

    public function generateBulkBarcodes(Request $request)
{
    $productId = $request->input('product_id');

    try {
        // Ürün varyasyonlarını çek
        $variations = $this->woocommerce->get("products/{$productId}/variations");

        // Barkodları saklamak için bir dizi oluştur
        $barcodes = [];

        foreach ($variations as $variation) {
            // Beden bilgisini bul
            $sizeCode = null;
            foreach ($variation->attributes as $attribute) {
                if ($attribute->name === 'Beden' || $attribute->name === 'Size') {
                    $sizeCode = $attribute->option;
                    break;
                }
            }

            if ($sizeCode) {
                // Barkod oluştur
                $barcode = $this->generateEAN13Barcode($productId, $sizeCode);

                // Varyasyonu güncellemek için doğru endpoint'i kullan
                $response = $this->woocommerce->put("products/{$productId}/variations/{$variation->id}", [
                    'sku' => $barcode, // Barkodu SKU'ya kaydet
                ]);

                // Eğer güncelleme başarılıysa
                if (isset($response->id)) {
                    // Barkodları diziye ekle
                    $barcodes[] = [
                        'variation_id' => $variation->id,
                        'size' => $sizeCode,
                        'barcode' => $barcode,
                    ];
                } else {
                    throw new \Exception("Varyasyon güncellenirken bir hata oluştu: {$variation->id}");
                }
            }
        }

        // Barkodları session'a kaydet
        session()->flash('barcodes', $barcodes);

        return redirect()->route('products.barcode.index')->with('success', 'Tüm bedenler için barkodlar başarıyla oluşturuldu ve SKU\'ya kaydedildi.');
    } catch (\Exception $e) {
        // Hata durumunda kullanıcıya geri bildirim ver
        return redirect()->route('products.barcode.index')->with('error', 'Barkod oluşturulurken bir hata oluştu: ' . $e->getMessage());
    }
}
}
