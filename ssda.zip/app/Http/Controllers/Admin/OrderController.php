<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class OrderController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $pendingOrders = Order::where('status', 'pending')->latest()->get();
        $processingOrders = Order::whereIn('status', ['confirmed', 'preparing', 'out_for_delivery'])->latest()->get();
        $completedOrders = Order::where('status', 'delivered')->latest()->take(50)->get();
        $cancelledOrders = Order::where('status', 'cancelled')->latest()->take(50)->get();

        return view('admin.orders.index', compact(
            'pendingOrders',
            'processingOrders',
            'completedOrders',
            'cancelledOrders'
        ));
    }

    public function show($id)
    {
        $order = Order::findOrFail($id);
        return view('admin.orders.show', compact('order'));
    }

    public function updateStatus(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'status' => 'required|in:pending,confirmed,preparing,out_for_delivery,delivered,cancelled',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $order = Order::findOrFail($id);
        $order->status = $request->status;

        if ($request->status === 'out_for_delivery') {
            $order->estimated_delivery_time = now()->addMinutes(30);
        }

        $order->save();

        // Here you would trigger notifications to the customer

        return response()->json([
            'message' => 'Order status updated successfully',
            'order' => $order
        ]);
    }
}
