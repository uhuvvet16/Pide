<?php

namespace App\Http\Controllers;

use App\Models\Gallery;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File; // File facade'i ekleyin

class GalleryController extends Controller
{
    protected $uploadImagePath = 'front/uploads/gallery_image/';

    /**
     * Galeri listesini göster.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $galleries = Gallery::orderBy('order')->get();
        return view('gallery.index', compact('galleries'));
    }

    /**
     * Yeni galeri öğesi oluşturma formu.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('gallery.create');
    }

    /**
     * Yeni galeri öğesini kaydet.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'type' => 'required|in:image,video',
            'files' => 'required_if:type,image',
            'files.*' => 'image|mimes:jpeg,png,jpg,gif,svg|max:16000',
            'video_path' => 'required_if:type,video',
        ]);

         $uploadImagePath = 'front/uploads/gallery_images/';

    // if ($request->hasFile('image')) {
    //     $imageName = Str::slug($request->title) . '.' . $request->image->getClientOriginalExtension();
    //     $request->image->move($uploadImagePath, $imageName);
    //     $imagePath = $uploadImagePath . $imageName;
    // }

        if ($request->type == 'image' && $request->hasFile('files')) {
            foreach ($request->file('files') as $file) {
                $filename = uniqid() . '_' . $file->getClientOriginalName(); // Benzersiz isim oluştur
                $file->move($uploadImagePath, $filename);

                Gallery::create([
                    'type' => 'image',
                    'path' => '/' . $uploadImagePath . $filename,  // Veritabanına public URL'i kaydet
                ]);
            }
        } elseif ($request->type == 'video') {
            Gallery::create([
                'type' => 'video',
                'path' => $request->video_path,
            ]);
        }

        return redirect()->route('gallery.index')->with('success', 'Galeri öğesi başarıyla eklendi.');
    }

    /**
     * Belirli galeri öğesini göster. (Şimdilik kullanmayacağız, gerekirse eklenebilir)
     *
     * @param  \App\Models\Gallery  $gallery
     * @return \Illuminate\Http\Response
     */
    public function show(Gallery $gallery)
    {
        //
    }

    /**
     * Belirli galeri öğesini düzenleme formu. **Silindi**
     *
     * @param  \App\Models\Gallery  $gallery
     * @return \Illuminate\Http\Response
     */
    // public function edit(Gallery $gallery) { ... } **Silindi**


    /**
     * Belirli galeri öğesini güncelle. **Silindi**
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Gallery  $gallery
     * @return \Illuminate\Http\Response
     */
    // public function update(Request $request, Gallery $gallery) { ... } **Silindi**


    /**
     * Belirli galeri öğesini sil.
     *
     * @param  \App\Models\Gallery  $gallery
     * @return \Illuminate\Http\Response
     */
    public function destroy(Gallery $gallery)
    {
        // Resim dosyası ise storage'dan sil
        if ($gallery->type == 'image') {
            $filePath = public_path($gallery->path);
            if (File::exists($filePath)) {
                File::delete($filePath);
            }
        }

        $gallery->delete();
        return redirect()->route('gallery.index')->with('success', 'Galeri öğesi başarıyla silindi.');
    }

    /**
     * Galeri öğelerinin sıralamasını güncelle.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function sort(Request $request)
    {
        $request->validate([
            'order' => 'required|array',
        ]);

        foreach ($request->order as $index => $galleryId) {
            Gallery::where('id', $galleryId)->update(['order' => $index]);
        }

        return response()->json(['success' => true]);
    }
}
