<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Address;
use App\Models\OrderItem;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Support\Facades\Validator;

class CheckoutController extends Controller
{
    private function getCart()
    {
        $cart = json_decode(request()->cookie('cart'), true);
        return $cart ? $cart : ['items' => [], 'total' => 0];
    }

    public function index()
    {
        $cart = $this->getCart();

        if (empty($cart['items'])) {
            return redirect()->route('menu.index')->with('error', 'Your cart is empty');
        }

        $addresses = [];

        if (Auth::check()) {
            $addresses = Auth::user()->addresses;
        }

        return view('checkout.index', compact('cart', 'addresses'));
    }

    public function processCheckout(Request $request)
    {
        $cart = $this->getCart();

        if (empty($cart['items'])) {
            return redirect()->route('menu.index')->with('error', 'Your cart is empty');
        }

        // Validate minimum order amount
        $minimumOrderAmount = 50; // Set your minimum order amount
        if ($cart['total'] < $minimumOrderAmount) {
            return back()->with('error', "Minimum order amount is ₺{$minimumOrderAmount}");
        }

        // Validate the request
        $rules = [
            'payment_method' => 'required|in:cash_on_delivery',
            'notes' => 'nullable|string|max:500',
        ];

        // Different validation rules based on user authentication status
        if (Auth::check()) {
            $rules['address_id'] = 'required|exists:addresses,id,user_id,' . Auth::id();
        } else {
            $rules = array_merge($rules, [
                'contact_name' => 'required|string|max:255',
                'contact_phone' => 'required|string|max:20',
                'address_line' => 'required|string|max:255',
                'city' => 'required|string|max:100',
                'postal_code' => 'required|string|max:20',
                'latitude' => 'required|numeric',
                'longitude' => 'required|numeric',
                'email' => 'required|email|max:255',
            ]);
        }

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }

        // Check delivery radius
        $restaurantLat = 41.0082; // Replace with your restaurant's latitude
        $restaurantLng = 28.9784; // Replace with your restaurant's longitude
        $maxDeliveryRadius = 3; // 3 km

        $addressLat = 0;
        $addressLng = 0;

        if (Auth::check()) {
            $address = Address::where('id', $request->address_id)
                ->where('user_id', Auth::id())
                ->firstOrFail();

            $addressLat = $address->latitude;
            $addressLng = $address->longitude;
        } else {
            $addressLat = $request->latitude;
            $addressLng = $request->longitude;
        }

        // Calculate distance using Haversine formula
        $distance = $this->calculateDistance(
            $restaurantLat,
            $restaurantLng,
            $addressLat,
            $addressLng
        );

        if ($distance > $maxDeliveryRadius) {
            return back()->with('error', 'Sorry, your address is outside our delivery area');
        }

        // Create or get address
        if (Auth::check()) {
            $addressId = $request->address_id;
        } else {
            // Create a new address for guest
            $address = Address::create([
                'user_id' => null,
                'address_line' => $request->address_line,
                'city' => $request->city,
                'postal_code' => $request->postal_code,
                'country' => 'Turkey',
                'latitude' => $request->latitude,
                'longitude' => $request->longitude,
                'contact_name' => $request->contact_name,
                'contact_phone' => $request->contact_phone,
            ]);

            $addressId = $address->id;
        }

        // Calculate delivery fee based on distance
        $deliveryFee = $this->calculateDeliveryFee($distance);

        // Create order
        $order = Order::create([
            'user_id' => Auth::check() ? Auth::id() : null,
            'address_id' => $addressId,
            'subtotal' => $cart['total'],
            'delivery_fee' => $deliveryFee,
            'total' => $cart['total'] + $deliveryFee,
            'status' => 'pending',
            'notes' => $request->notes,
            'payment_method' => $request->payment_method,
            'payment_status' => 'pending',
            'guest_email' => Auth::check() ? null : $request->email,
            'guest_phone' => Auth::check() ? null : $request->contact_phone,
        ]);

        // Create order items
        foreach ($cart['items'] as $item) {
            $orderItem = OrderItem::create([
                'order_id' => $order->id,
                'menu_item_id' => $item['menu_item_id'],
                'name' => $item['name'],
                'quantity' => $item['quantity'],
                'unit_price' => $item['price'],
                'subtotal' => $item['subtotal'],
                'special_instructions' => $item['special_instructions'] ?? null,
            ]);

            // Add extra items if any
            if (!empty($item['extra_items'])) {
                foreach ($item['extra_items'] as $extraItem) {
                    OrderItem::create([
                        'order_id' => $order->id,
                        'extra_item_id' => $extraItem['id'],
                        'name' => $extraItem['name'],
                        'quantity' => $item['quantity'],
                        'unit_price' => $extraItem['price'],
                        'subtotal' => $extraItem['price'] * $item['quantity'],
                    ]);
                }
            }
        }

        // Clear the cart
        Cookie::queue(Cookie::forget('cart'));

        return redirect()->route('orders.confirmation', ['order_code' => $order->order_code]);
    }

    private function calculateDistance($lat1, $lng1, $lat2, $lng2)
    {
        $earthRadius = 6371; // Radius of the earth in km

        $latDelta = deg2rad($lat2 - $lat1);
        $lngDelta = deg2rad($lng2 - $lng1);

        $a = sin($latDelta/2) * sin($latDelta/2) +
            cos(deg2rad($lat1)) * cos(deg2rad($lat2)) *
            sin($lngDelta/2) * sin($lngDelta/2);

        $c = 2 * atan2(sqrt($a), sqrt(1-$a));
        $distance = $earthRadius * $c;

        return $distance;
    }

    private function calculateDeliveryFee($distance)
    {
        // Example delivery fee calculation
        $baseFee = 10;
        $feePerKm = 5;

        return $baseFee + ($distance * $feePerKm);
    }
}
