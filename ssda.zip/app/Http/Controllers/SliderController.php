<?php

namespace App\Http\Controllers;

use App\Models\Slider;
use Illuminate\Support\Str;
use Illuminate\Http\Request;

class SliderController extends Controller
{
    /**
     * Slider listesini göster.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $sliders = Slider::all();
        return view('sliders.index', compact('sliders'));
    }

    /**
     * Yeni slider oluşturma formunu göster.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('sliders.create');
    }

    /**
     * Yeni slider'ı kaydet.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
{
    $request->validate([
        'title' => 'required|string|max:255',
        'description' => 'nullable|string',
        'image' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
        'button_text' => 'nullable|string|max:255',
        'button_url' => 'nullable|string|url|max:255',
    ]);

    // Görsel yükleme yolu
    $uploadImagePath = 'front/uploads/slider_images/';

    if ($request->hasFile('image')) {
        $imageName = Str::slug($request->title) . '.' . $request->image->getClientOriginalExtension();
        $request->image->move($uploadImagePath, $imageName);
        $imagePath = $uploadImagePath . $imageName;
    }

    // Slider kaydı oluştur
    Slider::create([
        'title' => $request->title,
        'description' => $request->description,
        'image' => $imagePath ?? null,
        'button_text' => $request->button_text,
        'button_url' => $request->button_url,
    ]);

    return redirect()->route('sliders.index')
        ->with('success', 'Slider başarıyla oluşturuldu.');
}

    public function update(Request $request, Slider $slider)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
            'button_text' => 'nullable|string|max:255',
            'button_url' => 'nullable|string|url|max:255',
        ]);

        $data = $request->except('image');

        if ($request->hasFile('image')) {
            // Eski resmi sil
            if ($slider->image && Storage::disk('public')->exists($slider->image)) {
                Storage::disk('public')->delete($slider->image);
            }
            $data['image'] = $request->file('image')->store('sliders', 'public');
        }

        $slider->update($data);

        return redirect()->route('sliders.index')
            ->with('success', 'Slider başarıyla güncellendi.');
    }
    /**
     * Belirli bir slider'ı göster. (Gerekli olmayabilir, opsiyonel)
     *
     * @param  \App\Models\Slider  $slider
     * @return \Illuminate\Http\Response
     */
    public function show(Slider $slider)
    {
        // Opsiyonel olarak detay sayfası gösterebilirsiniz
        return view('sliders.show', compact('slider'));
    }

    /**
     * Belirli bir slider'ı düzenleme formunu göster.
     *
     * @param  \App\Models\Slider  $slider
     * @return \Illuminate\Http\Response
     */
    public function edit(Slider $slider)
    {
        return view('sliders.edit', compact('slider'));
    }

    /**
     * Belirli bir slider'ı güncelle.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Slider  $slider
     * @return \Illuminate\Http\Response
     */
    // public function update(Request $request, Slider $slider)
    // {
    //     $request->validate([
    //         'title' => 'required|string|max:255',
    //         'image_url' => 'required|url',
    //         // Diğer validasyon kurallarını ekleyebilirsiniz
    //     ]);

    //     $slider->update($request->all());

    //     return redirect()->route('sliders.index')->with('success', 'Slider başarıyla güncellendi.');
    // }

    /**
     * Belirli bir slider'ı sil.
     *
     * @param  \App\Models\Slider  $slider
     * @return \Illuminate\Http\Response
     */
    public function destroy(Slider $slider)
    {
        $slider->delete();
        return redirect()->route('sliders.index')->with('success', 'Slider başarıyla silindi.');
    }

    /**
     * Frontend için slider verilerini API endpoint olarak döndür.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function getSliders()
    {
        $sliders = Slider::all();
        return response()->json($sliders);
    }
}
