<?php

namespace App\Http\Controllers;

use App\Models\MenuCategory;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class MenuCategoryController extends Controller
{
    /**
     * Menü kategori listeleme sayfası.
     */
    public function index()
    {
        $menuCategories = MenuCategory::orderBy('sort_order')->get(); // Sıralamaya göre getir
        return view('menu_categories.index', compact('menuCategories'));
    }

    /**
     * Yeni menü kategori oluşturma formu.
     */
    public function create()
    {
        return view('menu_categories.create');
    }

    /**
     * Yeni menü kategori kaydetme.
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|unique:menu_categories|max:255',
            'description' => 'nullable|string',
            'order' => 'nullable|integer|min:1', // Sıra zorunlu olmasa da integer ve min 1 olsun
        ]);

        $uploadImagePath = 'front/uploads/menu_categories_images/';

        if ($request->hasFile('image_path')) {
            $imageName = Str::slug($request->title) . '.' . $request->image->getClientOriginalExtension();
            $request->image->move($uploadImagePath, $imageName);
            $imagePath = $uploadImagePath . $imageName;
        }

        MenuCategory::create([
            'name' => $request->name,
            'slug' => Str::slug($request->name),
            'description' => $request->description,
            'order' => $request->order ?? 1, // Sıra değeri yoksa varsayılan 1
        ]);

        return redirect()->route('menu-categories.index')->with('success', 'Menü kategorisi başarıyla oluşturuldu.');
    }

    /**
     * Menü kategorisini düzenleme formu.
     */
    public function edit(MenuCategory $menuCategory)
    {
        return view('menu_categories.edit', compact('menuCategory'));
    }

    /**
     * Menü kategorisini güncelleme.
     */
    public function update(Request $request, MenuCategory $menuCategory)
    {
        $request->validate([
            'name' => 'required|unique:menu_categories,name,' . $menuCategory->id . '|max:255',
            'description' => 'nullable|string',
            'order' => 'nullable|integer|min:1',
        ]);

        $uploadImagePath = 'front/uploads/menu_categories_images/';

        if ($request->hasFile('image_path')) {
            // Eski resmi sil
            if ($menuCategory->image_path && file_exists(public_path($menuCategory->image_path))) {
                unlink(public_path($menuCategory->image_path));
            }

            // Yeni resmi kaydet
            $imageName = Str::slug($request->name) . '.' . $request->image_path->getClientOriginalExtension();
            $request->image_path->move(public_path($uploadImagePath), $imageName);
            $imagePath = $uploadImagePath . $imageName;

            // Yeni resim yolunu güncelle
            $menuCategory->image_path = $imagePath;
        }

        // Veriyi güncelle
        $menuCategory->update([
            'name' => $request->name,
            'slug' => Str::slug($request->name),
            'description' => $request->description,
            'order' => $request->order ?? 1,
        ]);

        return redirect()->route('menu-categories.index')->with('success', 'Menü kategorisi başarıyla güncellendi.');
    }


    /**
     * Menü kategorisini silme.
     */
    public function destroy(MenuCategory $menuCategory)
    {
        $menuCategory->delete();
        return redirect()->route('menu-categories.index')->with('success', 'Menü kategorisi başarıyla silindi.');
    }
}
