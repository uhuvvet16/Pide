<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class ProductController extends Controller
{
    /**
     * Ürün listeleme sayfası.
     */
    public function index()
    {
        $products = Product::latest()->get();
        return view('products.index', compact('products'));
    }

    /**
     * Yeni ürün oluşturma formu.
     */
    public function create()
    {
        $categories = Category::pluck('name', 'id'); // Kategori seçenekleri için
        return view('products.create', compact('categories'));
    }

    /**
     * Yeni ürün kaydetme.
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|unique:products|max:255',
            'description' => 'nullable|string',
            'price' => 'required|numeric|min:0',
            'stock' => 'required|integer|min:0',
            'category_id' => 'required|exists:categories,id',
        ]);

        Product::create([
            'name' => $request->name,
            'slug' => Str::slug($request->name),
            'description' => $request->description,
            'price' => $request->price,
            'stock' => $request->stock,
            'category_id' => $request->category_id,
        ]);

        return redirect()->route('products.index')->with('success', 'Ürün başarıyla oluşturuldu.');
    }

    /**
     * Belirli bir ürünü gösterme. (İhtiyaç olmayabilir, düzenleme için kullanacağız)
     */
    public function show(Product $product)
    {
        return view('products.show', compact('product'));
    }

    /**
     * Ürünü düzenleme formu.
     */
    public function edit(Product $product)
    {
        $categories = Category::pluck('name', 'id'); // Kategori seçenekleri için
        return view('products.edit', compact('product', 'categories'));
    }

    /**
     * Ürünü güncelleme.
     */
    public function update(Request $request, Product $product)
    {
        $request->validate([
            'name' => 'required|unique:products,name,' . $product->id . '|max:255',
            'description' => 'nullable|string',
            'price' => 'required|numeric|min:0',
            'stock' => 'required|integer|min:0',
            'category_id' => 'required|exists:categories,id',
        ]);

        $product->update([
            'name' => $request->name,
            'slug' => Str::slug($request->name),
            'description' => $request->description,
            'price' => $request->price,
            'stock' => $request->stock,
            'category_id' => $request->category_id,
        ]);

        return redirect()->route('products.index')->with('success', 'Ürün başarıyla güncellendi.');
    }

    /**
     * Ürünü silme.
     */
    public function destroy(Product $product)
    {
        $product->delete();
        return redirect()->route('products.index')->with('success', 'Ürün başarıyla silindi.');
    }
}
