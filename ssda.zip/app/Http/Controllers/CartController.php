<?php

namespace App\Http\Controllers;

use App\Models\MenuItem;
use App\Models\ExtraItem;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Support\Facades\Validator;

class CartController extends Controller
{
    private function getCart()
    {
        $cart = json_decode(request()->cookie('cart'), true);
        return $cart ? $cart : ['items' => [], 'total' => 0];
    }

    private function saveCart($cart)
    {
        return Cookie::queue('cart', json_encode($cart), 60 * 24 * 7); // 1 week
    }

    public function index()
    {
        $cart = $this->getCart();
        return response()->json($cart);
    }

    public function add(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'menu_item_id' => 'required|exists:menu_items,id',
            'quantity' => 'required|integer|min:1',
            'extra_items' => 'nullable|array',
            'extra_items.*' => 'exists:extra_items,id',
            'special_instructions' => 'nullable|string|max:255',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $menuItem = MenuItem::findOrFail($request->menu_item_id);

        if (!$menuItem->is_available) {
            return response()->json(['error' => 'This item is currently unavailable'], 400);
        }

        $cart = $this->getCart();

        $itemId = uniqid();
        $extraItems = [];
        $extraItemsTotal = 0;

        if ($request->has('extra_items') && !empty($request->extra_items)) {
            $extraItemsData = ExtraItem::whereIn('id', $request->extra_items)
                ->where('is_available', true)
                ->get();

            foreach ($extraItemsData as $extra) {
                $extraItems[] = [
                    'id' => $extra->id,
                    'name' => $extra->name,
                    'price' => $extra->price,
                ];
                $extraItemsTotal += $extra->price;
            }
        }

        $itemTotal = ($menuItem->price + $extraItemsTotal) * $request->quantity;

        $cart['items'][$itemId] = [
            'id' => $itemId,
            'menu_item_id' => $menuItem->id,
            'name' => $menuItem->name,
            'price' => $menuItem->price,
            'quantity' => $request->quantity,
            'extra_items' => $extraItems,
            'special_instructions' => $request->special_instructions ?? '',
            'subtotal' => $itemTotal,
        ];

        $cart['total'] = 0;
        foreach ($cart['items'] as $item) {
            $cart['total'] += $item['subtotal'];
        }

        $this->saveCart($cart);

        return response()->json([
            'message' => 'Item added to cart',
            'cart' => $cart
        ]);
    }

    public function update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'item_id' => 'required|string',
            'quantity' => 'required|integer|min:1',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $cart = $this->getCart();

        if (!isset($cart['items'][$request->item_id])) {
            return response()->json(['error' => 'Item not found in cart'], 404);
        }

        $item = &$cart['items'][$request->item_id];
        $item['quantity'] = $request->quantity;

        // Calculate extra items total
        $extraItemsTotal = 0;
        foreach ($item['extra_items'] as $extraItem) {
            $extraItemsTotal += $extraItem['price'];
        }

        $item['subtotal'] = ($item['price'] + $extraItemsTotal) * $item['quantity'];

        // Recalculate cart total
        $cart['total'] = 0;
        foreach ($cart['items'] as $cartItem) {
            $cart['total'] += $cartItem['subtotal'];
        }

        $this->saveCart($cart);

        return response()->json([
            'message' => 'Cart updated',
            'cart' => $cart
        ]);
    }

    public function remove(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'item_id' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $cart = $this->getCart();

        if (!isset($cart['items'][$request->item_id])) {
            return response()->json(['error' => 'Item not found in cart'], 404);
        }

        $itemTotal = $cart['items'][$request->item_id]['subtotal'];
        unset($cart['items'][$request->item_id]);

        $cart['total'] -= $itemTotal;

        $this->saveCart($cart);

        return response()->json([
            'message' => 'Item removed from cart',
            'cart' => $cart
        ]);
    }

    public function clear()
    {
        $emptyCart = ['items' => [], 'total' => 0];
        $this->saveCart($emptyCart);

        return response()->json([
            'message' => 'Cart cleared',
            'cart' => $emptyCart
        ]);
    }
}
