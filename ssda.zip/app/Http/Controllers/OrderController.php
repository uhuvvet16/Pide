<?php

namespace App\Http\Controllers;

use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class OrderController extends Controller
{
    public function index()
    {
        $orders = Auth::check()
            ? Auth::user()->orders()->latest()->get()
            : collect();

        return view('orders.index', compact('orders'));
    }

    public function show($orderCode)
    {
        $order = Order::where('order_code', $orderCode)->firstOrFail();

        // Check if user is authorized to view this order
        if (Auth::check()) {
            if ($order->user_id !== Auth::id()) {
                abort(403, 'Unauthorized');
            }
        } else {
            // For guest users, they need to provide email to view order
            if (!session()->has('guest_order_' . $orderCode)) {
                return redirect()->route('orders.verify', ['order_code' => $orderCode]);
            }
        }

        return view('orders.show', compact('order'));
    }

    public function verify($orderCode)
    {
        return view('orders.verify', compact('orderCode'));
    }

    public function processVerify(Request $request, $orderCode)
    {
        $request->validate([
            'email' => 'required|email',
        ]);

        $order = Order::where('order_code', $orderCode)
            ->where('guest_email', $request->email)
            ->first();

        if (!$order) {
            return back()->with('error', 'Invalid email or order code');
        }

        // Store in session that this guest is verified for this order
        session()->put('guest_order_' . $orderCode, true);

        return redirect()->route('orders.show', ['order_code' => $orderCode]);
    }

    public function confirmation($orderCode)
    {
        $order = Order::where('order_code', $orderCode)->firstOrFail();

        return view('orders.confirmation', compact('order'));
    }
}
