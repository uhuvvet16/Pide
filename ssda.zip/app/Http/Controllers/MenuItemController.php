<?php

namespace App\Http\Controllers;

use App\Models\MenuItem;
use Illuminate\Support\Str;
use App\Models\MenuCategory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;

class MenuItemController extends Controller
{
    /**
     * Menü öğesi listeleme sayfası.
     */
    public function index()
    {
        $menuItems = MenuItem::with('category')->latest()->paginate(10);
        return view('menu_items.index', compact('menuItems'));
    }

    /**
     * Yeni menü öğesi oluşturma formu.
     */
    public function create()
    {
        $categories = MenuCategory::all();
        return view('menu_items.create', compact('categories'));
    }

    /**
     * Yeni menü öğesi kaydetme.
     */
    public function store(Request $request)
    {
        try {
            $validated = $request->validate([
                'name' => 'required|unique:menu_items|max:255',
                'description' => 'nullable|string',
                'price' => 'required',  // Minimum değeri 0.01 yaptık
                'is_active' => 'nullable|boolean',
                'menu_category_id' => 'required|exists:menu_categories,id',
                'image' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:4096',
                'order' => 'nullable|integer|min:1',
            ], [
                'price.required' => 'Fiyat alanı zorunludur.',
                'price.min' => 'Fiyat en az 0.01 olmalıdır.',
            ]);

            // Debug için gelen değeri loglayalım
            Log::info('Price value:', ['price' => $request->price]);

            $uploadImagePath = 'front/uploads/menu_items_images/';

            if ($request->hasFile('image')) {
                $imageName = Str::slug($request->title) . '.' . $request->image->getClientOriginalExtension();
                $request->image->move($uploadImagePath, $imageName);
                $imagePath = $uploadImagePath . $imageName;
            }


            $menuItem = MenuItem::create([
                'name' => $request->name,
                'slug' => Str::slug($request->name),
                'description' => $request->description,
                'price' => floatval($request->price),  // float'a çeviriyoruz
                'is_active' => $request->boolean('is_active', true),
                'menu_category_id' => $request->menu_category_id,
                'image' => $imagePath,
                'order' => $request->order ?? 1,
            ]);

            return redirect()
                ->route('menu-items.index')
                ->with('success', 'Menü öğesi başarıyla oluşturuldu.');
        } catch (\Exception $e) {
            Log::error('Menu item creation failed:', [
                'message' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
                'request_data' => $request->all()  // Tüm form verilerini loglayalım
            ]);

            return back()
                ->withInput()
                ->withErrors(['error' => 'Menü öğesi oluşturulurken bir hata oluştu: ' . $e->getMessage()]);
        }
    }

    /**
     * Menü öğesini düzenleme formu.
     */
    public function edit(MenuItem $menuItem)
    {
        $menuCategories = MenuCategory::pluck('name', 'id'); // Kategori seçenekleri
        return view('menu_items.edit', compact('menuItem', 'menuCategories'));
    }

    /**
     * Menü öğesini güncelleme.
     */
    public function update(Request $request, MenuItem $menuItem)
{
    try {
        $validated = $request->validate([
            'name' => 'required|unique:menu_items,name,' . $menuItem->id . '|max:255',
            'description' => 'nullable|string',
            'price' => 'required|numeric',
            'is_active' => 'sometimes|boolean', // Burada boolean olarak doğrulama ekledik
            'menu_category_id' => 'required|exists:menu_categories,id',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:4096',
            'order' => 'nullable|integer|min:1',
        ], [
            'price.required' => 'Fiyat alanı zorunludur.',
        ]);

        // Debug için gelen değeri loglayalım
        Log::info('Updating MenuItem:', ['id' => $menuItem->id, 'price' => $request->price]);

        $uploadImagePath = 'front/uploads/menu_items_images/';
        $imagePath = $menuItem->image; // Varsayılan olarak mevcut resmi koru

        if ($request->hasFile('image')) {
            $imageName = Str::slug($request->name) . '.' . $request->image->getClientOriginalExtension();
            $request->image->move($uploadImagePath, $imageName);
            $imagePath = $uploadImagePath . $imageName;
        }

        $menuItem->update([
            'name' => $request->name,
            'slug' => Str::slug($request->name),
            'description' => $request->description,
            'price' => floatval($request->price),
            'is_active' => $request->boolean('is_active', true),
            'menu_category_id' => $request->menu_category_id,
            'image' => $imagePath,
            'order' => $request->order ?? 1,
        ]);

        return redirect()
            ->route('menu-items.index')
            ->with('success', 'Menü öğesi başarıyla güncellendi.');
    } catch (\Exception $e) {
        Log::error('Menu item update failed:', [
            'message' => $e->getMessage(),
            'trace' => $e->getTraceAsString(),
            'request_data' => $request->all()
        ]);

        return back()
            ->withInput()
            ->withErrors(['error' => 'Menü öğesi güncellenirken bir hata oluştu: ' . $e->getMessage()]);
    }
}


    /**
     * Menü öğesini silme.
     */
    public function destroy(MenuItem $menuItem)
    {
        // Görseli sil (isteğe bağlı)
        if ($menuItem->image) {
            Storage::disk('public')->delete($menuItem->image);
        }
        $menuItem->delete();
        return redirect()->route('menu-items.index')->with('success', 'Menü öğesi başarıyla silindi.');
    }

    /**
     * Menüyü ön yüzde görüntüleme sayfası.
     */
    public function showMenu()
    {
        $menuCategories = MenuCategory::with('menuItems.menuCategory')->orderBy('sort_order')->get(); // Kategorileri ve öğeleri getir
        $menuItems = MenuItem::with('category')->latest()->paginate(12); // paginate() kullanın
        return view('menu.index', compact('menuCategories', 'menuItems'));
    }
}
