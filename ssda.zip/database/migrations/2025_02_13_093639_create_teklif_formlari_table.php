<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('teklif_formlari', function (Blueprint $table) {
            $table->id();
            $table->string('etkinlik_turu');
            $table->date('etkinlik_tarihi');
            $table->time('etkinlik_saati')->nullable();
            $table->integer('kisi_sayisi');
            $table->string('ad_soyad');
            $table->string('email');
            $table->string('telefon');
            $table->text('ek_istekler')->nullable();
            $table->decimal('butce_araligi_min')->nullable();
            $table->decimal('butce_araligi_max')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('teklif_formlari');
    }
};
