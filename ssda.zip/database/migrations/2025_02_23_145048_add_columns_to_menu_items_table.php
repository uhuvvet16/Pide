<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddColumnsToMenuItemsTable extends Migration
{
    public function up()
    {
        Schema::table('menu_items', function (Blueprint $table) {
            // Değerlendirme Puanı
            $table->decimal('rating', 2, 1)->nullable();

            // Etiket
            $table->string('label')->nullable(); // Örnek: Yeni veya Popüler

            // Hazırlık Süresi
            $table->integer('preparation_time')->nullable(); // Dakika cinsinden

            // Ek Durum
            $table->enum('extra_condition', ['Acılı', 'Acısız', 'Taze', 'Baharatlı'])->nullable();
        });
    }

    public function down()
    {
        Schema::table('menu_items', function (Blueprint $table) {
            $table->dropColumn('rating');
            $table->dropColumn('label');
            $table->dropColumn('preparation_time');
            $table->dropColumn('extra_condition');
        });
    }
}
