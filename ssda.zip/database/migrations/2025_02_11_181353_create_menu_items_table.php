<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('menu_items', function (Blueprint $table) {
            $table->id();
            $table->string('name'); // Ürün Adı (Örn: Kıymalı Pide, Ayran)
            $table->string('slug')->unique(); // URL dostu isim
            $table->text('description')->nullable(); // Ürün Açıklaması (isteğe bağlı)
            $table->decimal('price', 10, 2); // Fiyat
            $table->boolean('is_active')->default(true); // Aktif/Pasif durumu
            $table->foreignId('menu_category_id')->constrained()->onDelete('cascade'); // Kategori İlişkisi
            $table->string('image')->nullable(); // Ürün Görseli (isteğe bağlı)
            $table->integer('order')->default(1); // Ürün Sırası (varsayılan 1)
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('menu_items');
    }
};
