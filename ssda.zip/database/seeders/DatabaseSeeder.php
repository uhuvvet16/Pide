<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {

         $password = Hash::make('Query16');

        \App\Models\User::insert([
            'name'=>'Ahmet Yavuz Topal',
            'email' => 'admin@querierteam.com.tr',
            'type' => 'admin',
            'password' => $password,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        // $this->call(CreateUsersForYetkililerSeeder::class);
        // $this->call(SectionsAndTasksSeeder::class);
        // $this->call(YetkiliSectionSeeder::class);

        // \App\Models\User::factory(10)->create();
    }
}
